//
//  RoiCarStatus.h
//  RoilandBox
//
//  Created by AndyChang.zhang on 15/3/24.
//  Copyright (c) 2015年 Roiland. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    
    ControlCommStateUnknow = 9999,
    ControlCommStateOff = 0,
    ControlCommStateOn  = 1,
    ControlCommStateUnsupport = 10000,
    
} ControlCommState;


@interface RoiCarStatus : NSObject

@property(nonatomic,assign)ControlCommState boot;    //启动状态0:熄火,1:启动
@property(nonatomic,assign)ControlCommState powerStatus; //电源状态  上电是0 下电是1
@property(nonatomic,copy)NSString *remainingBattery; //电动车的剩余电量百分比
@property(nonatomic,assign)double lng;               //Gps经度
@property(nonatomic,assign)double lat;              //Gps纬度
@property(nonatomic,copy)NSString *totalMileage;    //总里程(米)
@property(nonatomic,copy)NSString *oil;            //油位(升)
@property(nonatomic,copy)NSString *cruisingRange;    //续航里程(公里)
@property(nonatomic,copy)NSString *batteryVoltage;    //车辆蓄电池电压

@property(nonatomic,assign)ControlCommState doorfl;    //门状态（左前门）0:关闭,1:打开，>1或者null为不支持
@property(nonatomic,assign)ControlCommState doorfr;    //门状态（右前门） 0:关闭,1:打开，>2或者null为不支持
@property(nonatomic,assign)ControlCommState doorbl;    //门状态（左后门） 0:关闭,1:打开，>3或者null为不支持
@property(nonatomic,assign)ControlCommState doorbr;    //门状态（右后门） 0:关闭,1:打开，>4或者null为不支持
@property(nonatomic,assign)ControlCommState hood;    //发动机舱盖0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState highbeam;    //灯状态(远光灯)0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState lowbeam;    //灯状态(近光灯)0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState widthlamp;    //灯状态(示宽灯)0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState trunk;    //后备箱门状态0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState doorLockfl;    //左前门锁状态 0:解锁,1:上锁,>1或者null为不支持
@property(nonatomic,assign)ControlCommState doorLockfr;    //右前门锁状态0:解锁,1:上锁,>1或者null为不支持
@property(nonatomic,assign)ControlCommState doorLockbl;    //左后门锁状态 0:解锁,1:上锁,>1或者null为不支持
@property(nonatomic,assign)ControlCommState doorLockbr;    //右后门锁状态0:解锁,1:上锁,>1或者null为不支持
@property(nonatomic,assign)ControlCommState windowfl;    //窗状态(左前窗)0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState windowfr;    //窗状态(右前窗)0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState windowbl;   //窗状态(左后窗)0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState windowbr;    //窗状态(右后窗）0:关闭,1:打开,>1或者null为不支持
@property(nonatomic,assign)ControlCommState windowtop;    //窗状态(天窗)0:关闭,1:打开,>1或者null为不支持

- (void)parseCarStatusWithModels:(NSArray *)statusModelList;

@end
