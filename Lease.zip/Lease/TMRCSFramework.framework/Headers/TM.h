//
//  TM.h
//  test
//
//  Created by 占 on 2018/3/1.
//  Copyright © 2018年 tima. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TM : NSObject

//获取用户信息  ---需登录后才可获取用户数据
+ (NSDictionary *)getUserInfo;

@end
