//
//  testFram.h
//  testFram
//
//  Created by 占 on 2018/2/1.
//  Copyright © 2018年 tima. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <TMRCSFramework/TMZAppDelegate.h>
#import <TMRCSFramework/TMSetting.h>


//! Project version number for testFram.
FOUNDATION_EXPORT double testFramVersionNumber;

//! Project version string for testFram.
FOUNDATION_EXPORT const unsigned char testFramVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <testFram/PublicHeader.h>




