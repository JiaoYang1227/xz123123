//
//  RCBaseModel.h
//  FFS_New
//
//  Created by 占 on 2017/10/28.
//  Copyright © 2017年 tjtech. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface RCBaseModel : JSONModel



@end
