//
//  UserAccountManager.h
//  Carpool
//
//  Created by 占 on 2017/6/20.
//  Copyright © 2017年 tjtech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCLoginModel.h"
#import "RCUserInfoModel.h"
//#import "RCOrderModel.h"

//#import <AMapSearchKit/AMapSearchKit.h>

@interface UserAccountManager : NSObject
/**存储session*/
@property (nonatomic, copy) NSString *sessionString;
/**存储已经获取的验证码*/
@property (nonatomic, copy) NSString *verificationCode;

//@property (nonatomic, copy) NSString *token;
/**登录成功之后返回的模型*/
@property (nonatomic, strong) RCLoginModel *loginModel;

/**详细的用户信息*/
@property (nonatomic, strong) RCUserInfoModel *userInfoModel;

/**当前订单*/
//@property (nonatomic, strong) RCOrderModel *orderModel;



+ (UserAccountManager *)shareInstance;

/**获取当前订单 并保存起来*/
+ (void)request_getCurrentOrderWithObject:(void (^)(BOOL success))response;
/**获取当前用户信息并保存起来*/
+ (void)request_getUserInfo:(void (^)(BOOL success))response;


/**
 跳到登陆界面进行登陆
 */
+ (void)toLoginVCWithTitle:(NSString *)titleString;


/**
 退出登录
 */
+ (void)logout;


/**
 开始倒计时
 */
- (void)startTime;


/**
 每隔10秒钟刷新一次order
 */
- (void)zcl_loadData;

/**
 退出登录

 @param isCleanData 是否清楚数据
 */
//- (void)logoutWithCleanUserData:(BOOL)isCleanData;
//
//
//- (void)loginEaseMob:(NSString *)easemobUsername andPassword:(NSString *)easemobPassword;


@end
