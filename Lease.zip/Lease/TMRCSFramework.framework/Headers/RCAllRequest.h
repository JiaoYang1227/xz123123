//
//  RCAllRequest.h
//  FFS_New
//
//  Created by 占 on 2017/10/27.
//  Copyright © 2017年 tjtech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCLoginModel.h"
#import "RCUserInfoModel.h"
//#import "RCPayModel.h"
//#import "RCAliPayModel.h"
//#import "RCLocationModel.h"
//#import "RCCarListModel.h"
//#import "RCOrderModel.h"
//#import "RCJourneyModel.h"
//#import "TScostDetailsModel.h"
//#import "RCCouponCardsModel.h"
//#import "RCBillHistoryModel.h"
//#import "RCBillHistoryDetailModel.h"
//#import "RCWalletDetailModel.h"
//#import "RCActionModel.h"
//#import "RCHistoryTrackModel.h"
//#import "RCCompanyListModel.h"

// ** 获取验证码
#define Password @"/m/password"
// ** 注册
#define kRegist @"/m/regist"
// ** 修改密码
#define kresetForgetPassword @"/m/resetPassword"
// ** 验证手机验证面  （修改密码）
#define kCheckVerificationCode @"/m/password/checkVerifCode"
// ** 登录
#define Login @"/m/login"
// ** 获取个人信息 & 修改个人信息 & 提交审核接口
#define UserInfo @"/m/enrollees"
// ** 上传图片
#define kUploadImage @"/upload"
// ** 修改密码
#define kUpdatePassword @"/m/password/updatePassword"
// ** 微信 充值余额
#define kWeixinSubmit @"/m/accounts/wxPay"
// ** 支付宝 充值余额
#define kAliPaySubmit @"/m/accounts/alipay"

// ** 微信 order(充值押金)
#define kWeixinOrder @"/m/foregiftAccounts/wxPay"
// ** 支付宝 order（充值押金）
#define kAliPayOrder @"/m/foregiftAccounts/alipay"

// ** 获取场站列表
#define kLocationResources @"/m/locationResources"

#define kSuccessStatus @"success"
// ** 创建订单
#define kReservationOrders @"/m/reservationOrders"


// ** 获取订单详情
#define kOrderDetail @"/m/reservationOrders/process"

// ** 获取行程列表
#define kJourneyList @"/m/reservationOrders/journeyList"

///m/invoiceIssueRecords/journeyList
// ** 获取开始开发票的行程列表
#define kBillJourneyList @"/m/invoiceIssueRecords/journeyList"
// ** 车况检查
//#define kCheckCondition @"/m/reservationOrders/%@/condition"
// ** 优惠券列表
#define kCouponCards @"/m/cards/getCards/"
// ** 申请发票
#define kGetBill @"/m/invoiceIssueRecords"
// ** 发票历史
#define kGetBillHistory @"/m/invoiceIssueRecords/historyList"

///m/invoiceIssueRecords/{id}
// ** 发票详情
#define kGetBillHistoryDetail @"/m/invoiceIssueRecords/"
// ** 退押金 退款
#define kGiveBackDeposit @"/m/userCalls/refund"

///m/reservationOrders/hasProcess
// ** 检验当前是否有订单
//#define kHasProcess @"/m/reservationOrders/hasProcess"
//
// ** 获取优惠券
#define kGetCoupon @"/m/cards/exchangeCard/"
// ** 费用明细
#define kGetInfoPaymentDetail @"/m/flowInfo"
// ** 活动列表
#define kGetActionTivities @"/m/activities"
// ** 行程轨迹
//#define kGetHistoryTrack @"/m/activities"

// *********
// ** 获取公司列表
#define kGetCompanyList @"/m/company/list"
// ** 验证公司域账号
#define kVerifyCompany @"/m/enrollees/domain"
// ** 修改手机号
#define kResetPhoneNum @"/m/enrollees/username"
// ** 评论反馈
#define kFeedback @"/m/feedback"



@interface RCAllRequest : NSObject

//+ (void)saveUserInfoDataWithBlock:(void (^)(BOOL success))response;

/**获取图片URl*/
+ (NSString *)getImageURLWithString:(NSString *)string;

+ (NSString *)getUrlStringWithTailString:(NSString *)tailString;


+ (void)request_getVerifierWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

+ (void)request_loginWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCLoginModel *responseObject, NSError *error))response;

+ (void)request_getUserInforeturnWithObject:(void (^)(RCUserInfoModel *responseObject, NSError *error))response;

+ (void)request_putUserInforeturnWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCUserInfoModel *responseObject, NSError *error))response;

+ (void)request_updatePasswordWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
/**
 评论反馈
 */
+ (void)request_feedbackWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
/**
 忘记密码
 */
+ (void)request_forgetPasswordWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
/**
 修改手机号
 */
+ (void)request_resetPhoneNumWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

//+ (void)request_weixinWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCPayModel *responseObject, NSError *error))response;
//
//+ (void)request_alipayWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCAliPayModel *responseObject, NSError *error))response;
//
//+ (void)request_weixinOrderWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCPayModel *responseObject, NSError *error))response;
//
//+ (void)request_alipayOrderWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCAliPayModel *responseObject, NSError *error))response;
//
//+ (void)request_locationListWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCLocationModel *responseObject, NSError *error))response;
//
//+ (void)request_carListWithString:(NSString *)string returnWithObject:(void (^)(RCCarListModel *responseObject, NSError *error))response;

/**
 创建订单
 */
//+ (void)request_creatOrderWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

/**
 取消订单
 */
//+ (void)request_cancelOrderWithString:(NSString *)string returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
//+ (void)request_getCurrentOrderWithObject:(void (^)(RCOrderModel *responseObject, NSError *error))response;

///**
// 鸣笛
// */
//+ (void)request_blastWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
///**
// 去电子钥匙
// */
//+ (void)request_pickupWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
///**
// 开车门
// */
//+ (void)request_openCarDoorWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
///**
// 开车门 （寻车界面)
// */
//+ (void)request_masterOpenCarDoorWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

///**
// 关车门
// */
//+ (void)request_closeCarDoorWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

///**
// 还车
// */
//+ (void)request_returnCarWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
//+ (void)request_weixinPaymentOrderWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(RCPayModel *responseObject, NSError *error))response;
//
//+ (void)request_alipayPaymentOrderOrderWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(RCAliPayModel *responseObject, NSError *error))response;
//
//+ (void)request_walletPaymentOrderOrderWithString:(NSString *)string returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
//
//+ (void)request_paymentPayIdWithString:(NSString *)string returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
///**新用的钱包支付接口*/
//+ (void)request_walletPaymentOrderOrderWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

///**
// 行程列表
// */
//+ (void)request_getJourneyListWithBill:(BOOL)canBill WithObject:(void (^)(RCJourneyModel *responseObject, NSError *error))response;
///**
// 行程详情
// */
//+ (void)request_getJourneyDetailWithString:(NSString *)string returnWithObject:(void (^)(RCOrderModel *responseObject, NSError *error))response;
//
///**
// 评论
// */
//+ (void)request_commentWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
///**
// 获取付费详情
// */
//+ (void)request_paymentDetailWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(TScostDetailsModel *responseObject, NSError *error))response;

///**
// 保存图片
// */
//+ (void)request_saveImage:(UIImage *)image withFileName:(NSString *)fileName withBlock:(void (^)(BOOL success,NSDictionary *data))response;
//
///**
// 获取付费详情
// */
//+ (void)request_checkComditionWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
//
///**
// 获取行程路线
// */
//+ (void)getJourneyTrajectory :(NSString *)Jid andMapZoom :(int)zoom response:(void (^)(NSDictionary *responseObject, NSError *error))response;


/**
 验证验证码
 */
+ (void)request_checkVerificationCodeWithString:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

///**
// 获取优惠券列表
// */
//+ (void)request_couponListWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(RCCouponCardsModel *responseObject, NSError *error))response;
//
///**
// 申请发票
// */
//+ (void)request_getBillWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
///**
// 发票历史
// */
//+ (void)request_getBillHistoryWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCBillHistoryModel *responseObject, NSError *error))response;
///**
// 发票详情
// */
//+ (void)request_getBillHistoryDetailWithDic:(NSDictionary *)dic returnWithObject:(void (^)(RCBillHistoryDetailData *responseObject, NSError *error))response;
//
///**
// 退款
// */
//+ (void)request_giveBackDepositWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;
//
///**
// 获取优惠券
// */
//+ (void)request_getCouponWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

///**
// 获取用户费用明细 (列表)
// */
//+ (void)request_getInfoPaymentDetailWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(RCWalletDetailModel *responseObject, NSError *error))response;
//
///**
// 获取用户费用明细 (列表)
// */
//+ (void)request_getActionTivitiesWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(RCActionModel *responseObject, NSError *error))response;
//
///**
// 获取历史轨迹
// */
//+ (void)request_getHistoryTrackWithString:(NSString *)string withDic:(NSDictionary *)dic returnWithObject:(void (^)(RCHistoryTrackModel *responseObject, NSError *error))response;

/**
 注册页面
 */
+ (void)request_registWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;

// ***********
/**
 公司列表
 */
+ (void)request_companyListWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSArray *responseObject, NSError *error))response;
/**
 验证公司域账号
 */
+ (void)request_verifyCompanyWithDic:(NSDictionary *)dic returnWithObject:(void (^)(NSDictionary *responseObject, NSError *error))response;


@end
