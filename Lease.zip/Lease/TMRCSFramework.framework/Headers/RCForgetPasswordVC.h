//
//  RCForgetPasswordVC.h
//  FFS_New
//
//  Created by 占 on 2018/2/7.
//  Copyright © 2018年 tjtech. All rights reserved.
//

#import "RCBaseViewController.h"

@interface RCForgetPasswordVC : RCBaseViewController

@end
