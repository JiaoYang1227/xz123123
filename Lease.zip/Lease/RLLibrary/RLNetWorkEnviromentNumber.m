//
//  RLNetWorkEnviromentNumber.m
//  RLLibrary
//
//  Created by Cluy on 2018/6/5.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLNetWorkEnviromentNumber.h"
#import "RLAPIManager.h"

static RLNetWorkEnviromentNumber *sharedManager = nil;
@implementation RLNetWorkEnviromentNumber
+ (RLNetWorkEnviromentNumber *)sharedManager {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[self alloc] init];
    });
    return sharedManager;
    
}
-(void)setNetWorkEnviromentNumber:(NSInteger)netWorkEnviromentNumber{
    _netWorkEnviromentNumber = netWorkEnviromentNumber;
    [RLAPIManager reset];
}
+(NSString*)getRoot{
    NSInteger netWorkEnviromentNumber = [RLNetWorkEnviromentNumber sharedManager].netWorkEnviromentNumber;
    
    if(netWorkEnviromentNumber == RLNetWorkEnviromentUAT){
        return  @"https://rltuat.mobje.faw-vw.com";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentPROD){
        return  @"https://rltpro.mobje.faw-vw.com";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentPRE){
        return  @"https://rltpre.mobje.faw-vw.com";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentTUAT){
        return  @"http://rltcuat.mobje.faw-vw.com";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentTPRO){
        return  @"http://rltcpro.mobje.faw-vw.com";
    }else{
        //都没有走uat
        return  @"https://rltuat.mobje.faw-vw.com/";
    }
}

+(NSString*)getPassword{
    NSInteger netWorkEnviromentNumber = [RLNetWorkEnviromentNumber sharedManager].netWorkEnviromentNumber;
    
    if(netWorkEnviromentNumber == RLNetWorkEnviromentUAT){
        return  @"63629f9e687a433aae42c125ec323e5e";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentPROD){
        return  @"85ece5e6e7604e7eab008ab84b696d01";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentPRE){
        return  @"10ebd5e6c8601e7fab008ab84b678d68";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentTUAT){
        return  @"63629f9e687a433aae42c125ec323e5e";
    }else if(netWorkEnviromentNumber == RLNetWorkEnviromentTPRO){
        return  @"85ece5e6e7604e7eab008ab84b696d01";
    }else{
        //都没有走uat
        return  @"63629f9e687a433aae42c125ec323e5e";
    }
}

@end
