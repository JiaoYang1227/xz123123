//
//  RLMicro.h
//  Lease
//
//  Created by Jakey on 2019/12/26.
//  Copyright © 2019 sun. All rights reserved.
//

#ifndef RLMicro_h
#define RLMicro_h

#ifdef DEBUG
//#define RLLog(fmt, ...) RLLog((fmt), ##__VA_ARGS__);
#define RLLog(...);
#else
#define RLLog(...);
#endif

#endif /* RLMicro_h */
