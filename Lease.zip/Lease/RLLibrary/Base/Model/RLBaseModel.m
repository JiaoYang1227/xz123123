//
//  RLBaseModel.m
//  RLLibrary
//
//  Created by sun on 2018/3/8.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"

@implementation RLBaseModel
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    return YES;
}
-(NSString *)description{
    return [self toJSONString];
}

+(id)objectFromDictionary:(NSDictionary*)dict{
    return  [[self alloc] initWithDictionary:dict error:nil];
}
@end
