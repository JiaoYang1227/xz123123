//
//  LogWriter.h
//  DSPA2015
//
//  Created by runlin on 16/4/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LogWriter : NSObject
+ (void)writeLog:(NSString*)opration
        detail:(NSString*)detail
        inParams:(NSDictionary*)inParams
       outParams:(NSDictionary*)outParams;
+ (NSString*)readAll;
+ (void)uploadLog;
 @end
