//
//  RLNetWorkEnviromentNumber.h
//  RLLibrary
//
//  Created by Cluy on 2018/6/5.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_OPTIONS(NSUInteger, RLNetWorkEnviroment) {
    RLNetWorkEnviromentUAT = 0, //uat
    RLNetWorkEnviromentPROD =1, //生产
    RLNetWorkEnviromentPRE = 2, //预生产
    RLNetWorkEnviromentTUAT = 3, // 腾讯uat
    RLNetWorkEnviromentTPRO = 4// 腾讯生产
};
@interface RLNetWorkEnviromentNumber : NSObject
+ (RLNetWorkEnviromentNumber *)sharedManager;

// 设置网络环境 0 uat 1 生产 2 预生产 3腾讯uat 4.腾讯生产
@property (nonatomic) NSInteger netWorkEnviromentNumber;
////是否调试模式 调试模式c输出所有log
//@property (nonatomic,strong) BOOL debug;

+(NSString*)getRoot;
+(NSString*)getPassword;
@end
