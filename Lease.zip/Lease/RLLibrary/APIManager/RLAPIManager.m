//
//  APIManager.m
//  AudiTraining
//
//  Created by Jakey on 16/4/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "RLAPIManager.h"
//#import "AFSecurityPolicy.h"
//#import "AFNetworkActivityIndicatorManager.h"

#import "NSDictionary+JSONString.h"
#import "NSString+Hash.h"
#import "RLConstant.h"
#import "NSDictionary+JKSafeAccess.h"
#import "RLMicro.h"
static dispatch_once_t onceToken;
static RLAPIManager *_sharedManager = nil;

@implementation RLAPIManager
+(void)reset{
    _sharedManager = nil;
    onceToken = 0;
}
+ (instancetype)sharedManager {

    dispatch_once(&onceToken, ^{
        //设置服务器根地址
        _sharedManager = [[RLAPIManager alloc] initWithBaseURL:[NSURL URLWithString:[URI_SERVER_ADDRESS stringByAppendingString:URI_INTERFACE_ROOT]]];
        [_sharedManager setSecurityPolicy:[AFSecurityPolicy policyWithPinningMode:AFSSLPinningModePublicKey]];
        //发送数据
        _sharedManager.requestSerializer = [AFHTTPRequestSerializer serializer];
        //响应数据
        _sharedManager.responseSerializer  = [AFJSONResponseSerializer serializer];
//        [[AFNetworkActivityIndicatorManager sharedManager] setEnabled:YES];
        _sharedManager.responseSerializer.acceptableContentTypes =  [_sharedManager.responseSerializer.acceptableContentTypes setByAddingObjectsFromSet:[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", @"text/plain",@"application/atom+xml",@"application/xml",@"text/xml",nil]];
        
//        _sharedManager.securityPolicy.allowInvalidCertificates = YES;

    });

    return _sharedManager;
}

+(NSString *)getSignCheckContentV1:(NSDictionary *)params withURL:(NSString *)URLString{
    NSMutableString *content = [NSMutableString string];
    NSMutableDictionary *param = [(params?:@{}) mutableCopy];
    [param setObject:URI_INTERFACE_KEY forKey:@"rl_key"];
    NSStringCompareOptions comparisonOptions = NSCaseInsensitiveSearch|NSNumericSearch|
    NSWidthInsensitiveSearch|NSForcedOrderingSearch;
    NSComparator sort = ^(NSString *obj1,NSString *obj2){
        NSRange range = NSMakeRange(0,obj1.length);
        return [obj1 compare:obj2 options:comparisonOptions range:range];
        
    };
    NSArray *resultArray = [[param allKeys] sortedArrayUsingComparator:sort];
    for (NSString *key in resultArray) {
        NSString *value = [param jk_stringForKey:key];
        [content appendString:[NSString stringWithFormat:@"%@-%@",key,value]];
    }
    NSString *signStr =[NSString stringWithFormat:@"%@/%@%@" ,URI_INTERFACE_ROOT,URLString,content];
    return [[signStr md5String]lowercaseString];
}
+ (NSURLSessionDataTask *)SafePOST:(NSString *)URLString
                        parameters:(id)parameters
                           success:(void (^)(NSURLSessionDataTask * task, id responseObject))success
                           failure:(void (^)(NSURLSessionDataTask * task, NSError *error))failure{
    RLAPIManager *manager = [RLAPIManager sharedManager];
    //todo 统一封装请求参数
    RLLog(@"client request POST interface:%@",URLString);
    RLLog(@"client request POST JSON:\n%@",[parameters?:@{} JSONStringValue]);
    NSString *urlWithSign = [NSString stringWithFormat:@"%@?sign=%@",URLString,[RLAPIManager getSignCheckContentV1:parameters withURL:URLString]];
    return [manager POST:urlWithSign parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        RLLog(@"server respone  JSON:\n%@",[responseObject JSONStringValue]);

        //todo 统一处理响应数据
        success(task,responseObject);

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        RLLog(@"error respone :\n%@",[error debugDescription]);
         if(error.code == NSURLErrorCancelled)
        {
            RLLog(@"请求被取消");
        }
        //todo 统一处理错误
        failure(task,error);
    }];
}
+ (NSURLSessionDataTask *)SafeGET:(NSString *)URLString
                       parameters:(id)parameters
                          success:(void (^)(NSURLSessionDataTask * task, id responseObject))success
                          failure:(void (^)(NSURLSessionDataTask * task, NSError *error))failure{
    RLAPIManager *manager = [RLAPIManager sharedManager];
    //todo 统一封装请求参数
    RLLog(@"client request POST interface:%@",URLString);
    RLLog(@"client request POST JSON:\n%@",[parameters?:@{} JSONStringValue]);
    NSString *urlWithSign = [NSString stringWithFormat:@"%@?sign=%@",URLString,[RLAPIManager getSignCheckContentV1:parameters withURL:URLString]];

    return [manager GET:urlWithSign parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        RLLog(@"server respone  JSON:\n%@",[responseObject JSONStringValue]);
        //todo
        success(task,responseObject);

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //todo
        if(error.code == NSURLErrorCancelled)
        {
            RLLog(@"请求被取消");
        }
        failure(task,error);
    }];
}

@end
