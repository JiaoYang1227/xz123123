//
//  RLFileManager.h
//  RLLibrary
//
//  Created by sun on 2018/10/17.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RLFileManager : NSFileManager
//添加
//+(void)addplist:(id)arr;
//读plist文件
+ (id)fetchPlist;
//删除
+ (void)deletePlist;

@end
