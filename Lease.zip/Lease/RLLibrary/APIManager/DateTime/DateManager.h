//
//  DateManager.h
//  DSPA2015
//
//  Created by Jakey on 15/7/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
//typedef NS_ENUM(NSUInteger, FormatType) {
//    FormatType_YMD,
//    FormatType_YMDHM,
//    FormatType_YMDHMD,
//};
@interface DateManager : NSObject


+ (DateManager *) sharedManager;
#pragma mark-- data to formater string
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *  @param format 待转换NSDate格式 比如yyyy-MM-dd
 *
 *  @return 转换 后的NSString
 */
- (NSString *)stringConvertFromDate:(NSDate *)date format:(NSString *)format;
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy-MM-dd NSString
 */
+ (NSString *)stringConvert_YMD_FromDate:(NSDate *)date;
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的MM/dd/yyyy NSString
 */
+ (NSString *)stringConvert_MDY_FromDate:(NSDate *)date;
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy年MM月dd日 NSString
 */
+ (NSString *)stringConvert_ChineseYMD_FromDate:(NSDate *)date;

/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy-MM-dd HH:mm NSString
 */
+ (NSString *)stringConvert_YMDHM_FromDate:(NSDate *)date;
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy-MM-dd HH:mm:ss NSString
 */
+ (NSString *)stringConvert_YMDHMS_FromDate:(NSDate *)date;
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的 HH:mm NSString
 */
+ (NSString *)stringConvert_HM_FromDate:(NSDate *)date;

#pragma mark-- string to formater data
/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换NSString
 *  @param format 待转换NSDate格式 比如yyyy-MM-dd
 *
 *  @return 转换 后的NSDate
 */

- (NSDate *)dateConvertFromString:(NSString *)string format:(NSString *)format;
/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换yyyy-MM-dd NSString
 *
 *  @return 转换 后的NSDate
 */
+ (NSDate *)dateConvertFrom_YMD_String:(NSString *)string;
/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换yyyy-MM-dd HH:mm NSString
 *
 *  @return 转换 后的NSDate
 */
+ (NSDate *)dateConvertFrom_YMDHM_String:(NSString *)string;
/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换yyyy-MM-dd HH:mm:ss NSString
 *
 *  @return 转换 后的NSDate
 */
/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数字符串
 *
 *  @return 格式后时间yyyy-MM-dd字符串
 */
+ (NSString *)date_MD_WithTimeIntervalStringSince1970:(NSString*)secsString;
+ (NSDate *)dateConvertFrom_YMDHMS_String:(NSString *)string;
+ (NSString *)date_YMD2_WithTimeIntervalStringSince1970:(NSString*)secsString;
+ (NSString *)date_YMD3_WithTimeIntervalStringSince1970:(NSString*)secsString;
/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数字符串
 *
 *  @return 格式后时间yyyy年MM月dd日 时:分字符串
 */
+ (NSString *)date_YMDHM_WithTimeIntervalStringSince1970:(NSString*)secsString;
/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数字符串
 *
 *  @return 格式后时间yyyy年MM月dd日
 */
+ (NSString *)date_YMDC_WithTimeIntervalStringSince1970:(NSString*)secsString;
#pragma mark-- timeStamp to string date
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *  @param format 格式
 *
 *  @return 格式后时间字符串
 */
- (NSString *)dateWithTimeIntervalSince1970:(NSTimeInterval)secs format:(NSString *)format;
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间yyyy-MM-dd字符串
 */
+ (NSString *)date_YMD_WithTimeIntervalSince1970:(NSTimeInterval)secs;
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间HH:mm:ss字符串
 */
+ (NSString *)date_HMS_WithTimeIntervalSince1970:(NSTimeInterval)secs;
/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数
 *
 *  @return 格式后时间yyyy-MM-dd字符串
 */
+ (NSString *)date_YMD_WithTimeIntervalStringSince1970:(NSString*)secsString;
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间yyyy-MM-dd HH:mm字符串
 */
+ (NSString *)date_YMDHM_WithTimeIntervalSince1970:(NSTimeInterval)secs;
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间yyyy-MM-dd HH:mm:ss字符串
 */
+ (NSString *)date_YMDHMS_WithTimeIntervalSince1970:(NSTimeInterval)secs;

#pragma mark-- timeStamp
/**
 *  时间转时间戳字符串
 *
 *  @param date NSDate 时间
 *
 *  @return 时间戳字符串
 */
+(NSString *)timeStampStringWithDate:(NSDate*)date;
/**
 *  时间戳转NSDate
 *
 *  @param interval 时间戳
 *
 *  @return 时间NSDate
 */
+ (NSDate*)dateWithTimeStamp:(long long)interval;

/**
 *  时间转时间戳long long
 *
 *  @param date NSDate 时间
 *
 *  @return 时间戳long long
 */
+(long long)timeIntervalWithDate:(NSDate*)date;
/**
 *  当前时间时间戳字符串
 *
 *  @return 当前时间时间戳字符串
 */
+(NSString*)nowTimeStampString;
/**
 *  当前时间时间YMD字符串
 *
 *  @return 当前时间ymd字符串
 */
+(NSString*)nowYMDString;
/**
 *  当前时间时间YMDHmS字符串
 *
 *  @return 当前时间YMDHmS字符串
 */
+(NSString*)nowYMDHMSString;
#pragma mark --
/**
 *  @author Jakey, 15-10-10 16:10:40
 *
 *  @brief  一周第一天
 *
 *  @return 一周第一天
 */
+(long long)weakFirstDay;
/**
 *  @author Jakey, 15-10-10 16:10:52
 *
 *  @brief  一月第一天
 *
 *  @return 一月第一天
 */
+(long long)monthFirstDay;
/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  格式化秒成 天 时 分 秒
 *
 *  @param seconds 秒时间段
 *
 *  @return 天 时 分 秒
 */
+(NSString*)formaterTimeRangeToDHMS:(NSTimeInterval)seconds;
/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  格式化分钟成  时:分
 *
 *  @param minus 秒时间段
 *
 *  @return  时 分
 */
+(NSString*)formaterTimeRangeToHM:(NSTimeInterval)minus;
/**
 *  @author Jakey, 15-12-10 16:12:19
 *
 *  @brief  录音
 *
 *  @param seconds <#seconds description#>
 *
 *  @return <#return value description#>
 */
+(NSString*)formaterRecordTimeRangeToDHMS:(NSTimeInterval)seconds;
/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  获取当前周的周一日期
 *
 *
 *  @return 时 分
 */
+ (NSArray *)getWeekBeginAndEndWith:(NSDate *)newDate;

/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  获取当前月的 一号日期
 *
 *
 *  @return 时 分
 */
+ (NSArray *)getMonthBeginAndEndWith:(NSDate *)newDate;
//计算到现在时间间隔
+ (NSInteger)computeDaysStartDate:(NSDate *)startDate forDate:(NSDate *)forDate;
/**
 *
 *  @param seconds 秒时间段
 *
 *  @return 几天前
 */
+(NSString*)formaterTimeToD:(NSTimeInterval)seconds;
/**
 *
 *  @param n 几天前
 *
 *  @return n天前日期
 */
+(NSDate *)getNDay:(NSInteger)n;
//返回MMDD星期
+ (NSString*)MDweekdayStringFromDate:(NSDate*)inputDate;

/**
 *  @author Sun, 18-02-11 15:01:00
 *
 *  @brief  获取一天第一秒
 *
 *  @return  一天第一秒
 */
+ (NSDate *)zero0000Date:(NSDate*)date;

/**
 *  @author Sun, 18-02-11 15:02:00
 *
 *  @brief  获取一天最后秒
 *
 *  @return  一天最后秒
 */
+ (NSDate *)zero2400Date:(NSDate*)date;
@end
