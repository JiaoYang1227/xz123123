//
//  DateManager.m
//  DSPA2015
//
//  Created by Jakey on 15/7/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//
#define FORMATER_YYMMDD
#import "DateManager.h"
@interface DateManager ()
@property (nonatomic, strong) NSDateFormatter *dateForrmatter;
@end
@implementation DateManager
+ (DateManager *) sharedManager
{
    static DateManager *dateManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dateManager = [[self alloc] init];
    });
    return dateManager;
}
- (id)init
{
    self = [super init];
    if (self) {
        _dateForrmatter = [[NSDateFormatter alloc] init];
        [_dateForrmatter setLocale:[NSLocale currentLocale]];
//       [_dateForrmatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
//        [_dateForrmatter setTimeZone:[NSTimeZone localTimeZone]];
       [_dateForrmatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:3600*8]];
//       [_dateForrmatter setTimeZone:[NSTimeZone timeZoneWithName:@"Asia/Shanghai"]];

    }
    return self;
}
#pragma mark--
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *  @param format 待转换NSDate格式 比如yyyy-MM-dd
 *
 *  @return 转换 后的NSString
 */
- (NSString *)stringConvertFromDate:(NSDate *)date format:(NSString *)format
{
    [_dateForrmatter setDateFormat:format];
    NSString *dateString = [_dateForrmatter stringFromDate:date];
    return dateString;
}
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy-MM-dd NSString
 */
+ (NSString *)stringConvert_YMD_FromDate:(NSDate *)date{
    return [[DateManager sharedManager] stringConvertFromDate:date format:@"yyyy-MM-dd"];
}/**
  *  NSDate 转换 NSString
  *
  *  @param date   待转换NSDate
  *
  *  @return 转换 后的MM/dd/yyyy NSString
  */
+ (NSString *)stringConvert_MDY_FromDate:(NSDate *)date{
    return [[DateManager sharedManager] stringConvertFromDate:date format:@"MM/dd/yyyy"];
}
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy年MM月dd日 NSString
 */
+ (NSString *)stringConvert_ChineseYMD_FromDate:(NSDate *)date{
    return [[DateManager sharedManager] stringConvertFromDate:date format:@"yyyy年MM月dd日"];
}

/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy-MM-dd HH:mm NSString
 */
+ (NSString *)stringConvert_YMDHM_FromDate:(NSDate *)date{
    return [[DateManager sharedManager] stringConvertFromDate:date format:@"yyyy-MM-dd HH:mm"];

}
/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的yyyy-MM-dd HH:mm:ss NSString
 */
+ (NSString *)stringConvert_YMDHMS_FromDate:(NSDate *)date{
    return [[DateManager sharedManager] stringConvertFromDate:date format:@"yyyy-MM-dd HH:mm:ss"];

}

/**
 *  NSDate 转换 NSString
 *
 *  @param date   待转换NSDate
 *
 *  @return 转换 后的 HH:mm NSString
 */
+ (NSString *)stringConvert_HM_FromDate:(NSDate *)date{
    return [[DateManager sharedManager] stringConvertFromDate:date format:@"HH:mm"];
    
}

#pragma mark-- string to formater data

/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换NSString
 *  @param format 待转换NSDate格式 比如yyyy-MM-dd
 *
 *  @return 转换 后的NSDate
 */
- (NSDate *)dateConvertFromString:(NSString *)string format:(NSString *)format
{
    [_dateForrmatter setDateFormat:format];
    NSDate *date = [_dateForrmatter dateFromString:string];
    return date;
}
/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换yyyy-MM-dd NSString
 *
 *  @return 转换 后的NSDate
 */
+ (NSDate *)dateConvertFrom_YMD_String:(NSString *)string{
    return [[DateManager sharedManager] dateConvertFromString:string format:@"yyyy-MM-dd"];
}
/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换yyyy-MM-dd HH:mm NSString
 *
 *  @return 转换 后的NSDate
 */
+ (NSDate *)dateConvertFrom_YMDHM_String:(NSString *)string{
    return [[DateManager sharedManager] dateConvertFromString:string format:@"yyyy-MM-dd HH:mm"];
}
/**
 *  NSString 转换 NSDate
 *
 *  @param string 待转换yyyy-MM-dd HH:mm:ss NSString
 *
 *  @return 转换 后的NSDate
 */
+ (NSDate *)dateConvertFrom_YMDHMS_String:(NSString *)string{
    return [[DateManager sharedManager] dateConvertFromString:string format:@"yyyy-MM-dd HH:mm:ss"];
}

#pragma mark-- timeStamp to string date
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *  @param format 格式
 *
 *  @return 格式后时间字符串
 */
- (NSString *)dateWithTimeIntervalSince1970:(NSTimeInterval)secs format:(NSString *)format
{
    if (secs==0) {
        return @"";
    }
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:secs/1000];
    return [self stringConvertFromDate:date format:format];
}
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间yyyy-MM-dd字符串
 */
+ (NSString *)date_YMD_WithTimeIntervalSince1970:(NSTimeInterval)secs{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:secs format:@"yyyy-MM-dd"];
}
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间HH:mm:ss字符串
 */
+ (NSString *)date_HMS_WithTimeIntervalSince1970:(NSTimeInterval)secs{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:secs format:@"HH:mm:ss"];
}

/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数字符串
 *
 *  @return 格式后时间yyyy-MM-dd字符串
 */
+ (NSString *)date_YMD_WithTimeIntervalStringSince1970:(NSString*)secsString{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:[secsString longLongValue] format:@"yyyy-MM-dd"];
}
/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数字符串
 *
 *  @return 格式后时间yyyy-MM-dd字符串
 */
+ (NSString *)date_MD_WithTimeIntervalStringSince1970:(NSString*)secsString{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:[secsString longLongValue] format:@"MM月dd日"];
}
+ (NSString *)date_YMD2_WithTimeIntervalStringSince1970:(NSString*)secsString{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:[secsString longLongValue] format:@"yyyy.MM.dd"];
}
+ (NSString *)date_YMD3_WithTimeIntervalStringSince1970:(NSString*)secsString{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:[secsString longLongValue] format:@"yyyy-MM-dd HH:mm:ss"];
}
/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数字符串
 *
 *  @return 格式后时间yyyy年MM月dd日 时:分字符串
 */
+ (NSString *)date_YMDHM_WithTimeIntervalStringSince1970:(NSString*)secsString{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:[secsString longLongValue] format:@"yyyy年MM月dd日 HH:mm分"];
}
/**
 *  时间戳根据格式转字符串
 *
 *  @param secsString   秒数字符串
 *
 *  @return 格式后时间yyyy年MM月dd日 
 */
+ (NSString *)date_YMDC_WithTimeIntervalStringSince1970:(NSString*)secsString{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:[secsString longLongValue] format:@"yyyy年MM月dd日"];
}
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间yyyy-MM-dd HH:mm字符串
 */
+ (NSString *)date_YMDHM_WithTimeIntervalSince1970:(NSTimeInterval)secs{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:secs format:@"yyyy-MM-dd HH:mm"];
}
/**
 *  时间戳根据格式转字符串
 *
 *  @param secs   秒数
 *
 *  @return 格式后时间yyyy-MM-dd HH:mm:ss字符串
 */
+ (NSString *)date_YMDHMS_WithTimeIntervalSince1970:(NSTimeInterval)secs{
    return [[DateManager sharedManager] dateWithTimeIntervalSince1970:secs format:@"yyyy-MM-dd HH:mm:ss"];
}


#pragma mark-- timeStamp
/**
 *  时间转时间戳long long
 *
 *  @param date NSDate 时间
 *
 *  @return 时间戳long long
 */
+(long long)timeIntervalWithDate:(NSDate*)date
{
    long long interval = 0;
    if (date == nil)
    {
        return interval;
    }
    
    NSTimeInterval tmp = [date timeIntervalSince1970];
    interval = [[NSNumber numberWithDouble:tmp] longLongValue];
    
    //changge to million second
    return interval * 1000;
}
/**
 *  时间戳转NSDate
 *
 *  @param interval 时间戳
 *
 *  @return 时间NSDate
 */
+ (NSDate*)dateWithTimeStamp:(long long)interval
{
    if (interval != 0) {
        return [NSDate dateWithTimeIntervalSince1970:(NSTimeInterval)interval/1000];
    } else {
        return 0;
    }
}
/**
 *  时间转时间戳long long
 *
 *  @param date NSDate 时间
 *
 *  @return 时间戳long long
 */
+(NSString *)timeStampStringWithDate:(NSDate*)date{
    long long  tmp = [self timeIntervalWithDate:date];
    return [[NSNumber numberWithLongLong:tmp] stringValue];
}
/**
 *  当前时间时间戳字符串
 *
 *  @return 当前时间时间戳字符串
 */
+(NSString *)nowTimeStampString{
     return  [[NSNumber numberWithLongLong:[[NSDate date] timeIntervalSince1970]*1000] stringValue];
}
/**
 *  当前时间时间YMD字符串
 *
 *  @return 当前时间ymd字符串
 */
+(NSString*)nowYMDString{
     return [[DateManager sharedManager] stringConvertFromDate:[NSDate date] format:@"yyyy-MM-dd"];
}
/**
 *  当前时间时间YMDHmS字符串
 *
 *  @return 当前时间YMDHmS字符串
 */
+(NSString*)nowYMDHMSString{
    return [[DateManager sharedManager] stringConvertFromDate:[NSDate date] format:@"yyyy-MM-dd HH:mm:ss"];
}
#pragma mark--
/**
 *  @author Jakey, 15-10-10 16:10:40
 *
 *  @brief  一周第一天
 *
 *  @return 一周第一天
 */
+(long long)weakFirstDay{
    NSDate *now = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    [calendar setFirstWeekday:2];
    
    NSDateComponents *comp = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay|NSCalendarUnitWeekday|NSCalendarUnitDay
                                         fromDate:now];
    
    // 得到星期几
    // 1(星期天) 2(星期二) 3(星期三) 4(星期四) 5(星期五) 6(星期六) 7(星期天)
    NSInteger weekDay = [comp weekday];
    // 得到几号
    NSInteger day = [comp day];
    
    // 计算当前日期和这周的星期一和星期天差的天数
    long firstDiff;
    __unused long lastDiff;
    if (weekDay == 1) {
        firstDiff = -6;
        lastDiff = 0;
    }else{
        firstDiff = [calendar firstWeekday] - weekDay;
        lastDiff = 9 - weekDay;
    }
    
    // 在当前日期(去掉了时分秒)基础上加上差的天数
    NSDateComponents *firstDayComp = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:now];
    [firstDayComp setDay:day + firstDiff];
    NSDate *firstDayOfWeek= [calendar dateFromComponents:firstDayComp];
    
    return [DateManager timeIntervalWithDate:firstDayOfWeek];
}
/**
 *  @author Jakey, 15-10-10 16:10:52
 *
 *  @brief  一月第一天
 *
 *  @return 一月第一天
 */
+(long long)monthFirstDay{
    NSDate *now = [NSDate date];
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *comps = [cal
                               components:NSCalendarUnitYear | NSCalendarUnitMonth
                               fromDate:now];
    comps.day = 1;
    NSDate *firstDay = [cal dateFromComponents:comps];
    return [DateManager timeIntervalWithDate:firstDay];
}
/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  格式化秒成 天 时 分 秒
 *
 *  @param seconds 秒时间段
 *
 *  @return 天 时 分 秒
 */
+(NSString*)formaterTimeRangeToDHMS:(NSTimeInterval)seconds{
    NSInteger day = seconds/86400;
    NSInteger hour = (seconds-(day*86400))/3600;
    NSInteger minus = (seconds-(day*86400)-(hour*3600))/60;
    NSInteger second = (seconds-(day*86400)-(hour*3600)-minus*60);
    
    return [NSString stringWithFormat:@"%zd天%zd时%zd分%zd秒", day,hour,minus,second];
}
/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  格式化秒成 天 时 分 秒
 *
 *  @param seconds 秒时间段
 *
 *  @return 时 分
 */
+(NSString*)formaterTimeRangeToHM:(NSTimeInterval)minus{
    if (minus<=0) {
        return @"0:0";
    }
    NSInteger hour = minus/60;
    NSInteger minusLeft = (minus-(hour*60));
    return [NSString stringWithFormat:@"%zd:%zd", hour,minusLeft];
}

+(NSString*)formaterRecordTimeRangeToDHMS:(NSTimeInterval)seconds;
{
    if (seconds<0) {
        seconds = 0;
    }
    NSInteger s = (int)seconds;
    NSInteger m = s / 60;
    NSInteger h = m / 60;
    
    s = s % 60;
    m = m % 60;
    return [NSString stringWithFormat:@"%0.2ld:%0.2ld:%0.2ld", (long)h,(long)m,(long)s];

}

/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  获取当前周的周一日期
 *
 *
 *  @return 时 分
 */
+ (NSArray *)getWeekBeginAndEndWith:(NSDate *)newDate{
    if (newDate == nil) {
        newDate = [NSDate date];
    }
    double interval = 0;
    NSDate *beginDate = nil;
    NSDate *endDate = nil;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    [calendar setFirstWeekday:2];//设定周一为周首日
    BOOL ok = [calendar rangeOfUnit:NSCalendarUnitWeekOfMonth startDate:&beginDate interval:&interval forDate:newDate];
    //分别修改为 NSDayCalendarUnit NSWeekCalendarUnit NSYearCalendarUnit
    if (ok) {
        endDate = [beginDate dateByAddingTimeInterval:interval-1];
    }else {
        return nil;
    }
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *beginString = [myDateFormatter stringFromDate:beginDate];
    NSString *endString = [myDateFormatter stringFromDate:endDate];
    
    NSArray *begin_end = @[beginString?:@"" , endString?:@""];
    
    return begin_end;
}
/**
 *  @author Jakey, 15-12-02 13:12:32
 *
 *  @brief  获取当前月的 一号日期
 *
 *
 *  @return 时 分
 */
+ (NSArray *)getMonthBeginAndEndWith:(NSDate *)newDate{
    if (newDate == nil) {
        newDate = [NSDate date];
    }
    double interval = 0;
    NSDate *beginDate = nil;
    NSDate *endDate = nil;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    [calendar setFirstWeekday:1];//设定周日为周首日
    BOOL ok = [calendar rangeOfUnit:NSCalendarUnitMonth startDate:&beginDate interval:&interval forDate:newDate];
    //分别修改为 NSDayCalendarUnit NSWeekCalendarUnit NSYearCalendarUnit
    if (ok) {
        endDate = [beginDate dateByAddingTimeInterval:interval-1];
    }else {
        return nil;
    }
    NSDateFormatter *myDateFormatter = [[NSDateFormatter alloc] init];
    [myDateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *beginString = [myDateFormatter stringFromDate:beginDate];
    NSString *endString = [myDateFormatter stringFromDate:endDate];
    
    NSArray *begin_end = @[beginString?:@"" , endString?:@""];
    
    return begin_end;
}
//startDate 到fordate的天间隔
+ (NSInteger)computeDaysStartDate:(NSDate *)startDate forDate:(NSDate *)forDate
{
    if(!startDate || !forDate){
        return 0;
    }
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    [gregorian setFirstWeekday:2];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *fromDate;
    NSDate *toDate;
    [gregorian rangeOfUnit:NSCalendarUnitDay startDate:&fromDate interval:NULL forDate:startDate];
    [gregorian rangeOfUnit:NSCalendarUnitDay startDate:&toDate interval:NULL forDate:forDate];
    if(!fromDate || !toDate){
        return 0;
    }
    NSDateComponents *dayComponents = [gregorian components:NSCalendarUnitDay fromDate:fromDate toDate:toDate options:0];
    
    return dayComponents.day;
}
+(NSString*)formaterTimeToD:(NSTimeInterval)seconds{
    NSTimeInterval currentTime = [[NSDate date] timeIntervalSince1970];
    NSTimeInterval createTime = seconds/1000;
    // 时间差
    NSTimeInterval time = currentTime - createTime;
    return [NSString stringWithFormat:@"%d天前发布",(int)time/3600/24];
}

+(NSDate *)getNDay:(NSInteger)n{
    NSDate*nowDate = [NSDate date];
    NSDate* theDate;
    if(n!=0){
        NSTimeInterval  oneDay = -24*60*60*1;  //1天的长度
        theDate = [nowDate initWithTimeIntervalSinceNow: oneDay*n ];//initWithTimeIntervalSinceNow是从现在往前后推的秒数
        }else{
            theDate = nowDate;
        }

        return theDate;
}
//返回星期几
+ (NSString*)MDweekdayStringFromDate:(NSDate*)inputDate {
    
    NSArray *weekdays = [NSArray arrayWithObjects: [NSNull null], @"星期日", @"星期一", @"星期二", @"星期三", @"星期四", @"星期五", @"星期六", nil];
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSCalendarUnit calendarUnit = NSCalendarUnitWeekday;
    NSDateComponents *theComponents = [calendar components:calendarUnit fromDate:inputDate];
    NSString *date = [[DateManager sharedManager] stringConvertFromDate:inputDate format:@"MM月dd日"];
    return [NSString stringWithFormat:@"%@ %@",date,[weekdays objectAtIndex:theComponents.weekday]];
}
+ (NSDate *)zero0000Date:(NSDate*)date
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSUIntegerMax fromDate:date];
    components.hour = 0;
    components.minute = 0;
    components.second = 0;
    return [calendar dateFromComponents:components];
}

+ (NSDate *)zero2400Date:(NSDate*)date
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSUIntegerMax fromDate:date];
    components.hour = 23;
    components.minute = 59;
    components.second = 0;
    return [calendar dateFromComponents:components];
}
@end
