//
//  RLFileManager.m
//  RLLibrary
//
//  Created by sun on 2018/10/17.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLFileManager.h"
#import "RLOperationModel.h"
#define  CONTROL_CAR_FILENAME @"Controlcarname.plist"
@implementation RLFileManager
+(void)addplist:(id)arr {
//    RLLog(@"写入plist=%@=",arr);
    
    //1. 创建一个plist文件
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *path=[paths objectAtIndex:0];
    NSString *filename=[path stringByAppendingPathComponent:CONTROL_CAR_FILENAME];
    NSFileManager* fm = [NSFileManager defaultManager];
    if ([[[RLFileManager alloc] init] isPlistFileExists:CONTROL_CAR_FILENAME]==YES) {
//        RLLog(@"存在");
        // 获取旧数据新数据组合写入
        NSMutableArray *farr =[NSMutableArray arrayWithContentsOfFile:filename];
//        RLLog(@"保存前查询=%ld=%@",farr.count,farr);
        if (farr.count !=0) {

            NSString *str = [NSString stringWithFormat:@"%@",arr];
            [farr addObject:str];
//            RLLog(@"添加后数据=%@=",farr);
            
        }else{
//            RLLog(@"保存前查询为空");
            
        }
        [farr writeToFile:filename atomically:YES];
        NSMutableArray * newarr = [NSMutableArray arrayWithContentsOfFile:filename];
//        RLLog(@"保存后的数据=%@",newarr);
        
    }else{
//        RLLog(@"不存在");
        [fm createFileAtPath:filename contents:nil attributes:nil];
        //创建一个arr，写到plist文件里
        NSMutableArray *arrxin = [NSMutableArray arrayWithObject:arr];
        [arrxin writeToFile:filename atomically:YES];
        NSMutableArray * newarr = [NSMutableArray arrayWithContentsOfFile:filename];
//        RLLog(@"保存后的数据=%@",newarr);
        
    }
    
}



//判断沙盒中名为plistname的文件是否存在

- (BOOL) isPlistFileExists:(NSString *)name{
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *path=[paths objectAtIndex:0];
    NSString *filename=[path stringByAppendingPathComponent:name];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if( [fileManager fileExistsAtPath:filename]== NO ) {
//        RLLog(@"not exists");
        return NO;
        
    }else{
        return YES;
    }
}

/**

 *      //读plist文件

 */

+ (id)fetchPlist {
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *path=[paths objectAtIndex:0];
//    RLLog(@"path = %@",path);
    NSString *filename=[path stringByAppendingPathComponent:CONTROL_CAR_FILENAME];
    id arr = [NSMutableArray arrayWithContentsOfFile:filename];
//    RLLog(@"查询结果=%@=",arr);
    return arr;
}



+ (void)deletePlist {
    //清除plist文件，可以根据我上面讲的方式进去本地查看plist文件是否被清除
    NSFileManager *fileMger = [NSFileManager defaultManager];
    NSString *xiaoXiPath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)objectAtIndex:0]stringByAppendingPathComponent:CONTROL_CAR_FILENAME];
    //如果文件路径存在的话
    BOOL bRet = [fileMger fileExistsAtPath:xiaoXiPath];
    if (bRet) {
//        RLLog(@"清空了");
        NSError *err;
        [fileMger removeItemAtPath:xiaoXiPath error:&err];
        
    }
}

///**
// 创建文件夹
//
// @param dirName 文件夹名称
// @param dirPath 文件夹所在路径
// @return 创建结果YES/NO
// */
//+ (BOOL)creatDir:(NSString *)dirName dirPath:(NSString *)dirPath {
//
//    dirPath = [dirPath stringByAppendingPathComponent:dirName];
//    if ([NSFileManager fileExistsAtPath:dirPath]) {
//        RLLog(@"创建失败，目录已存在");
//    } else {
//        BOOL isCreat = [RLFileManager createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil error:nil];
//        if (isCreat) {
//            RLLog(@"创建成功");
//            return YES;
//        } else {
//            RLLog(@"创建失败,请检查路径");
//            return NO;
//        }
//    }
//    return NO;
//}
///**
// 创建文件
//
// @param fileName 文件名称
// @param dirPath 文件所在的文件夹路径
// @return 创建结果YES/NO
// */
//+ (BOOL)creatFile:(NSString *)fileName dirPath:(NSString *)dirPath {
//
//    NSString *filePath = [dirPath stringByAppendingPathComponent:fileName];
//    BOOL isDir = NO;
//    BOOL isFileExist = [RLFileManager fileExistsAtPath:filePath isDirectory:&isDir];
//    //目录是否存在
//    if (!(isFileExist && isDir)) {
//        BOOL isCreat = [RLFileManager createFileAtPath:filePath contents:nil attributes:nil];
//        if (isCreat) {
//            RLLog(@"创建成功");
//            return YES;
//        } else {
//            RLLog(@"创建失败");
//            return NO;
//        }
//    } else {
//        RLLog(@"创建失败，文件已存在");
//        return NO;
//    }
//    return NO;
//}
///**
// String写入
//
// @param content 写入的字符串内容
// @param filePath 写入文件的路径
// @return 写入结果YES/NO
// */
//+ (BOOL)writeString:(NSString *)content filePath:(NSString *)filePath {
//
//    BOOL isFileExist = [RLFileManager fileExistsAtPath:filePath];
//    if (isFileExist) {
//        BOOL isWrite = [content writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
//        if (isWrite) {
//            RLLog(@"写入成功");
//            return YES;
//        } else {
//            RLLog(@"写入失败");
//            return NO;
//        }
//    } else {
//        RLLog(@"写入失败,文件不存在");
//        return NO;
//    }
//    return NO;
//}
//
///**
// Dictionary写入
//
// @param dic 要写入的dictionary
// @param filePath 文件路径
// @return 写入结果YES/NO
// */
//+ (BOOL)writeDictionary:(NSDictionary *)dic filePath:(NSString *)filePath {
//
//    BOOL isFileExist = [RLFileManager fileExistsAtPath:filePath];
//    if (isFileExist) {
//        BOOL isCreat = [dic writeToFile:filePath atomically:YES];
//        if (isCreat) {
//            RLLog(@"写入成功");
//            return YES;
//        } else {
//            RLLog(@"写入失败");
//            return NO;
//        }
//    } else {
//        RLLog(@"写入失败,文件不存在");
//        return NO;
//    }
//    return NO;
//}
///**
// 读取存储的String
//
// @param filePath 文件路径
// @return 存储的字符串
// */
//+ (NSString *)readFileWithFilePath:(NSString *)filePath {
//
//    NSString *str = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
//    return str;
//}
///**
// 读取存储的dictionary
//
// @param filePath 文件路径
// @return 存储的dictionary
// */
//+ (NSDictionary *)readDictionaryWithFilePath:(NSString *)filePath {
//
//    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
//    return dic;
//}
///**
// 移除文件
//
// @param filePath 文件路径
// @return 移除结果YES/NO
// */
//+ (BOOL)removeFileWithFilePath:(NSString *)filePath {
//
//    if ([RLFileManager fileExistsAtPath:filePath]) {
//        BOOL isRemove = [RLFileManager removeItemAtPath:filePath error:nil];
//        if (!isRemove) {
//            RLLog(@"移除失败");
//            return NO;
//        } else {
//            RLLog(@"移除成功");
//            return YES;
//        }
//    } else {
//        RLLog(@"文件不存在");
//        return NO;
//    }
//    return NO;
//}

@end
