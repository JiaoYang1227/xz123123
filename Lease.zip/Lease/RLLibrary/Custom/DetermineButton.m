//
//  DetermineButton.m
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "DetermineButton.h"

@implementation DetermineButton
-(void)awakeFromNib{
    [super awakeFromNib];
    self.layer.cornerRadius = self.frame.size.height/2;
    self.backgroundColor = [UIColor colorWithRed:26.0/255.0 green:132.0/255.0 blue:210.0/255.0 alpha:1];
}
@end
