//
//  RLLocationManager.h
//  RLLibrary
//
//  Created by sun on 2018/4/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
typedef void(^RLLocationSuccess) (double lat, double lng);
typedef void(^RLLocationFailed) (NSError *error);
@interface RLLocationManager : NSObject<CLLocationManagerDelegate>{
    CLLocationManager *manager;
    RLLocationSuccess successCallBack;
    RLLocationFailed failedCallBack;
}
+ (RLLocationManager *) sharedGpsManager;

+ (void) getMoLocationWithSuccess:(RLLocationSuccess)success Failure:(RLLocationFailed)failure;

+ (void) stop;

@end
