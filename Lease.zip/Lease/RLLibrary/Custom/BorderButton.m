//
//  BorderButton.m
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "BorderButton.h"

@implementation BorderButton
-(void)awakeFromNib{
    [super awakeFromNib];
    self.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    self.layer.borderWidth = 0.5f;
    self.layer.shadowRadius = 100;
}
-(void)changeState{
    [self setSelected:!self.selected];
    if (self.selected) {
        self.layer.borderColor = [UIColor colorWithRed:26.0/255.0 green:132.0/255.0 blue:210.0/255.0 alpha:1].CGColor;
//        [self setTitleColor:[UIColor colorWithRed:26.0/255.0 green:132.0/255.0 blue:210.0/255.0 alpha:1] forState:UIControlStateNormal];
        self.layer.borderWidth = 0.5f;
        self.layer.shadowRadius = 100;
    }else{
        self.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
        self.layer.borderWidth = 0.5f;
        self.layer.shadowRadius = 100;
//        [self setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] forState:UIControlStateNormal];
    }
}
@end
