//
//  BorderTextView.h
//  AudiSuperApp
//
//  Created by sun on 2016/12/5.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BorderTextView : UITextView
/**
 *  限制输入文字位数 可以在delegate或者viewdidload设置
 */
@property (nonatomic, assign) NSInteger limit;
@property (nonatomic, copy) NSString *placeholder;
@property (nonatomic, copy) UIColor *placeholderColor;
@end
