//
//  BorderButton.h
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BorderButton : UIButton
-(void)changeState;
@end
