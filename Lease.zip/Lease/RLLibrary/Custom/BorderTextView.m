//
//  BorderTextView.h
//  AudiSuperApp
//
//  Created by sun on 2016/12/5.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BorderTextView.h"

@implementation BorderTextView

-(void)willMoveToSuperview:(UIView *)newSuperview{
    //    self.clipsToBounds = NO;
    if (newSuperview) {
//        self.textColor = [UIColor colorWithWhite:0.114 alpha:1.000];
        self.font = [UIFont systemFontOfSize:14];
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(textViewTextDidChange:)
                                                    name:@"UITextViewTextDidChangeNotification"
                                                  object:self];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange:) name:UITextViewTextDidChangeNotification object:self];
    }
}

- (void)textViewTextDidChange:(NSNotification *)notification
{
    UITextView *textField = (UITextView *)notification.object;
    
    NSString *toBeString = textField.text;
    
    if (toBeString.length > self.limit && self.limit>0)
    {
        textField.text = [toBeString substringToIndex:self.limit];
    }
}

- (NSInteger)getTextLength:(NSString *)text
{
    NSInteger asciiLength = 0;
    
    for (NSInteger i = 0; i<text.length; i++)
    {
        unichar t = [text characterAtIndex:i];
        
        asciiLength += isascii(t) ? 1 : 2;
    }
    return asciiLength;
}
- (void)textDidChange:(NSNotification *)note
{
    if (_placeholder.length == 0) return;
    [self setNeedsDisplay];
}

- (void)setText:(NSString *)text
{
    [super setText:text];
    
    if (_placeholder.length == 0) return;
    [self setNeedsDisplay];
}
- (void)setPlaceholder:(NSString *)placeholder
{
    _placeholder = placeholder;
    
    if (_placeholder.length == 0 || self.text.length != 0) return;
    [self setNeedsDisplay];
}

- (void)setPlaceholderColor:(UIColor *)placeholderColor
{
    _placeholderColor = placeholderColor;
    
    if (_placeholder.length == 0 || self.text.length != 0) return;
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    if (self.text.length == 0) {
        [_placeholderColor set];
        CGFloat padding = 8;
        CGRect placeholderRect = CGRectMake(padding, padding, rect.size.width - padding * 2, rect.size.height - padding);
        if (!_placeholderColor) {
            _placeholderColor = [UIColor grayColor];
        }
        [_placeholder drawInRect:placeholderRect withAttributes:@{NSForegroundColorAttributeName:_placeholderColor,NSFontAttributeName :
                                                                      [UIFont systemFontOfSize:14]}];
    }
}
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
