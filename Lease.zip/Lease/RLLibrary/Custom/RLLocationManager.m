//
//  RLLocationManager.m
//  RLLibrary
//
//  Created by sun on 2018/4/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLLocationManager.h"
#import <UIKit/UIKit.h>
#import "RLMicro.h"
@implementation RLLocationManager
+ (RLLocationManager *) sharedGpsManager {
    static RLLocationManager *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[RLLocationManager alloc] init];
    });
    return shared;
}

- (id)init {
    self = [super init];
    if (self) {
        // 打开定位 然后得到数据
        manager = [[CLLocationManager alloc] init];
        manager.delegate = self;
        //控制定位精度,越高耗电量越
        manager.desiredAccuracy = kCLLocationAccuracyBest;
        
        // 1. 适配 动态适配
        if ([manager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
            [manager requestWhenInUseAuthorization];
            [manager requestAlwaysAuthorization];
        }
        // 2. 另外一种适配 systemVersion 有可能是 8.1.1
        float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
        if (osVersion >= 8) {
            [manager requestWhenInUseAuthorization];
            [manager requestAlwaysAuthorization];
        }
    }
    return self;
}

- (void) getMoLocationWithSuccess:(RLLocationSuccess)success Failure:(RLLocationFailed)failure {
    successCallBack = [success copy];
    failedCallBack = [failure copy];
    // 停止上一次的
    [manager stopUpdatingLocation];
    // 开始新的数据定位
    [manager startUpdatingLocation];
}


+ (void) getMoLocationWithSuccess:(RLLocationSuccess)success Failure:(RLLocationFailed)failure {
    [[RLLocationManager sharedGpsManager] getMoLocationWithSuccess:success Failure:failure];
}


- (void) stop {
    [manager stopUpdatingLocation];
}

+ (void) stop {
    [[RLLocationManager sharedGpsManager] stop];
}

// 每隔一段时间就会调用
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    for (CLLocation *loc in locations) {
        CLLocationCoordinate2D l = loc.coordinate;
        double lat = l.latitude;
        double lnt = l.longitude;
        
        successCallBack ? successCallBack(lat, lnt) : nil;
    }
}

//失败代理方法
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    failedCallBack ? failedCallBack(error) : nil;
    if ([error code] == kCLErrorDenied) {
        RLLog(@"访问被拒绝");
    }
    if ([error code] == kCLErrorLocationUnknown) {
        RLLog(@"无法获取位置信息");
    }
}

@end
