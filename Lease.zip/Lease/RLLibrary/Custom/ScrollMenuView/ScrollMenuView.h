//
//  ScrollMenuView.h
//  ShareBar-Demo
//
//  Created by runlin on 16/4/7.
//  Copyright © 2016年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^TouchMenuScrollView)(NSInteger index,UIButton *button,id item);
typedef NSString*(^TitleForMenuScrollItem)(NSInteger index,id item);

@interface ScrollMenuView : UIView
{
    
    TouchMenuScrollView _touchMenuScrollView;
    NSMutableArray *_buttons;
    TitleForMenuScrollItem _titleForMenuScrollItem;
}
@property(nonatomic,strong) NSArray *items;
@property(nonatomic,strong) UIColor *itemNormalColor;
@property(nonatomic,strong) UIColor *itemSelectColor;
@property(nonatomic,assign) CGFloat itemWidth;

@property(nonatomic,strong) id currentItem;
@property(nonatomic) BOOL ishiddenRedLine; //默认不隐藏
@property(nonatomic) BOOL ishiddenLine; //默认不隐藏
@property(nonatomic,assign) NSInteger selectedIndex;

-(void)didClickMenuItem:(TouchMenuScrollView)touchMenuScrollView;
-(void)titleForMenuItem:(TitleForMenuScrollItem)titleForMenuScrollItem;
-(void)reloadData;
@end
