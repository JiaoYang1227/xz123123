//
//  LogWriter.m
//  DSPA2015
//
//  Created by runlin on 16/4/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "LogWriter.h"
#import "FileManager.h"
#import "DateManager.h"
#import "RLInclude.h"
#import "NSDictionary+JSONString.h"
#define KEY_LOG_FILENAME @"RLLog9.log"
#import "RLOperationModel.h"
#import "RLMicro.h"
@interface LogWriter()
@property(nonatomic,strong) NSMutableArray *cacheLogs;
@property(nonatomic,assign) BOOL isUpload;

@property (nonatomic,strong)dispatch_queue_t concurrentWriteFileQueue;//个线程
@end


@implementation LogWriter
+ (instancetype) shareInstance{
    static dispatch_once_t onceToken;
    static LogWriter *writer = nil;
    //确保创建单例只被执行一次。
    dispatch_once(&onceToken, ^{
        writer = [LogWriter new];
        //自己建立一个线程
        writer.concurrentWriteFileQueue = dispatch_queue_create("LogWriterQueue", DISPATCH_QUEUE_CONCURRENT);
        writer.cacheLogs = [NSMutableArray array];
    });
    return writer;
}
- (NSString*)getJSON:(NSDictionary*)obj{
    NSError *error = nil;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:obj
                                                       options:0
                                                         error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}
+ (void)writeLog:(NSString*)opration
        detail:(NSString*)detail
        inParams:(NSDictionary*)inParams
       outParams:(NSDictionary*)outParams
{
 
    dispatch_barrier_async([LogWriter shareInstance].concurrentWriteFileQueue, ^{
        RLLog(@"writeLog");
        [[LogWriter shareInstance] writeLog:opration detail:detail inParams:inParams outParams:outParams];
    });
}

- (void)writeLog:(NSString*)opration
          detail:(NSString*)detail
        inParams:(NSDictionary*)inParams
       outParams:(NSDictionary*)outParams{
    //如果已经连接Xcode调试则不输出到文件
    //    if (isatty(STDOUT_FILENO)) {
    //        return;
    //    }
    //    //判定如果是模拟器就不输出
    //    UIDevice *device = [UIDevice currentDevice];
    //    if ([[device model]hasSuffix:@"Simulator"]) {
    //        return;
    //    }
    
    //将RLLog打印信息保存到Document目录下的Log文件夹下
//    RLLog(@"RLLog.log path:%@",logPath);
    
    
    
    NSMutableString *mutiString = [NSMutableString string];
    
    NSString *time = [[DateManager sharedManager] stringConvertFromDate:[NSDate date] format:@"MM-dd HH:mm:ss.SSS"];
    
    
    [mutiString appendFormat:@"Date:%@ ", time];
    [mutiString appendFormat:@"Tag:%@  ",opration];
    
    if(detail!=nil && [detail description].length>0){
        [mutiString appendFormat:@"Log:%@  ",detail];
    }
    if(inParams!=nil){
        [mutiString appendFormat:@"InParams:%@  ",[self getJSON:inParams]];
    }
    if(outParams!=nil){
        [mutiString appendFormat:@"OutParams:%@  ",[self getJSON:outParams]];
    }
    [mutiString appendString:@"\n"];
    
    if(self.isUpload){
        RLLog(@"log正在上传缓存log");
        [self.cacheLogs addObject:mutiString];
        return;
    }
    [self writeFormatterLog:mutiString];
}
- (void)writeFormatterLog:(NSString*)mutiString{
    NSString *logPath = [FileManager documentsPath:KEY_LOG_FILENAME];
    //把错误日志写到文件中
    if (![[FileManager sharedManager] fileExistsAtPath:logPath]) {
        [mutiString writeToFile:logPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }else{
        NSFileHandle *outFile = [NSFileHandle fileHandleForWritingAtPath:logPath];
        [outFile seekToEndOfFile];
        [outFile writeData:[mutiString dataUsingEncoding:NSUTF8StringEncoding]];
        [outFile closeFile];
    }
}
-(void)clean{
    dispatch_barrier_async([LogWriter shareInstance].concurrentWriteFileQueue, ^{
        NSString *logPath = [FileManager documentsPath:KEY_LOG_FILENAME];
        [[FileManager sharedManager] removeFileAtPath:logPath];
        RLLog(@"clean");
        if(self.cacheLogs!=nil && self.cacheLogs.count>0){
            NSString *cacheLog =  [self.cacheLogs componentsJoinedByString:@""];
            [self.cacheLogs removeAllObjects];
            [self writeFormatterLog:cacheLog];
            RLLog(@"write cacheLog");
        }

    });
}
+(void)uploadLog{
    dispatch_barrier_async([LogWriter shareInstance].concurrentWriteFileQueue, ^{
        [[LogWriter shareInstance] uploadLog];
    });
}
- (void)uploadLog{
    if(self.isUpload){
        RLLog(@"log正在上传");
        return;
    }
    NSString *log =  [LogWriter readAll];
    RLLog(@"uploadLog");
    [LogWriter shareInstance].isUpload = YES;
    [RLOperationModel printLogBluetooth:@{@"log":log?:@""} success:^(BOOL success, NSString *message) {
 
        if (success) {
            [[LogWriter shareInstance] clean];
             [LogWriter shareInstance].isUpload = NO;
        }else{
            [LogWriter shareInstance].isUpload = NO;
        }
    } falure:^(NSError *error) {
        [LogWriter shareInstance].isUpload = NO;
    }];
}
+ (NSString*)readAll{
    NSString *logPath = [FileManager documentsPath:KEY_LOG_FILENAME];
    
    NSString *log =     [[NSString alloc] initWithContentsOfFile:logPath encoding:NSUTF8StringEncoding error:nil];
    if(!log){
        return nil;
    }
    NSString *version =  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString *build =  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
    NSString *versionBuild =[NSString stringWithFormat:@"%@(%@)",version,build];
  
    
    NSString *time = [[DateManager sharedManager] stringConvertFromDate:[NSDate date] format:@"MM-dd HH:mm:ss.SSS"];
    
    NSMutableString *logs = [NSMutableString string];
    [logs appendString:@"\n===============================iOS Log Start==================================\n"];
    [logs appendFormat:@"========================       App %@         ========================\n",versionBuild];
    [logs appendFormat:@"========================   %@   ========================\n",[RLInclude version]];
    [logs appendFormat:@"========================     %@      ========================\n",time];
    
    [logs appendString:log];
    [logs appendString:@"===============================iOS Log End==================================\n"];
    return logs;
}

@end
