//
//  RLConstant.h
//  RLLibrary
//
//  Created by sun on 2018/3/8.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RLInclude.h"
#import "RLNetWorkEnviromentNumber.h"

#define URI_SERVER_ADDRESS [RLNetWorkEnviromentNumber getRoot]

#define URI_INTERFACE_ROOT @"/interfaces"
#define URI_INTERFACE_KEY [RLNetWorkEnviromentNumber getPassword]

//#define URI_SERVER_ADDRESS [[RLNetWorkEnviromentNumber sharedManager]netWorkEnviromentNumber] == 0 ? @"http://192.168.203.110:8080" : ([[RLNetWorkEnviromentNumber sharedManager]netWorkEnviromentNumber] == 1 ? @"http://192.168.203.110:8080" : @"http://192.168.203.110:8080")
//
//#define URI_INTERFACE_ROOT @"/interfaces"
//#define URI_INTERFACE_KEY [[RLNetWorkEnviromentNumber sharedManager]netWorkEnviromentNumber] == 0 ?@"63629f9e687a433aae42c125ec323e5e": ([[RLNetWorkEnviromentNumber sharedManager]netWorkEnviromentNumber] == 1 ?@"63629f9e687a433aae42c125ec323e5e": @"63629f9e687a433aae42c125ec323e5e")

//#pragma mark ====================================接口================================
#define VERSION @"20191028"
//评价
#define URI_INTERFACES_MOBILITY_EVALUATE @"saveMobilityEvaluate"
//查询评价内容
#define URI_INTERFACES_EVALUATE @"evaluateByOrderNumbers"
//获取预约车辆剩余时间
#define URI_INTERFACES_VEHICLERESERCATIONS_TIME @"getVehicleReservationsTime"

//取消预约车辆
#define URI_INTERFACES_VEHICLERESERCATIONS_CANCLE @"cancelVehicleReservations"

//开始订单
#define URI_INTERFACES_VEHICLERESERCATIONS_BAGIN @"beginvehiclereservations"

//下发授权指令接口
#define URI_INTERFACES_AUTH @"auth"

//获取授权认证信息接口
#define URI_INTERFACES_GET_AUTH_KEY @"getAuthKey"
//去权
#define URI_INTERFACES_REVOKE_AUTH_KEY @"revokeAuth"

//查询工单列表
#define URI_INTERFACES_SELECTWORKORDER_LIST @"selectWorkorderListByAidAndStatus"

//工单状态修改
#define URI_INTERFACES_UPDATEWORKORSER_STATUS @"updateWorkorderStatus"

//查询实时行车数据（还车时获取信息）
#define URI_INTERFACES_DRIVING_DATA @"drivingData"

//下发还车指令接口
#define URI_INTERFACES_CHECKCAR @"checkCar"

//获取还车结果接口
#define URI_INTERFACES_GET_CHECKCAR_CODE @"getCheckCarCode"
//查询GPS坐标是否在场站
#define URI_INTERFACES_GET_CHECK_DOT @"checkDot"

//蓝牙数据进行还车检查
#define URI_INTERFACES_CHECKCAR_BLUETOOTH @"checkCarBluetooth"
//价格结束订单
#define URI_INTERFACES_RECHON_COSRFINSHORDER @"reckonCostFinishOrder"

//控车 
#define URI_INTERFACES_CONTROL_CAR @"controlCar"

//查询优惠券
#define URI_INTERFACES_SELECTCOUPON_LIST @"selectCouponList"
//查询可用优惠券
#define URI_INTERFACES_SELECTSTARTEDCOUPON_LIST @"selectStartedCoupon"
//违章查询
#define URI_INTERFACES_SELECTILLEGAL_LIST @"selectIllegalListByUserid"
//广告
#define URI_INTERFACES_SELECTADVERT_LIST @"selectAdvertList"
//广告点击次数增加
#define URI_INTERFACES_ADDADVERTNUMBER @"addAdvertNumber"
//发放魔豆
#define URI_INTERFACES_GRANT_MAGIC_BEAN @"grantMagicBean"

//蓝牙控车打印日志接口
#define URI_INTERFACES_PRINTLOG_BLUETOOTH @"printLogBluetooth"

@interface RLConstant : NSObject

@end
