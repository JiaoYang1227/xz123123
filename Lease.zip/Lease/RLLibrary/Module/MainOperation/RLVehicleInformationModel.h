//
//  RLVehicleInformationModel.h
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"

@interface RLVehicleInformationModel : RLBaseModel
//获取预约车辆剩余时间
+ (void)getVehicleReservationsTime:(NSDictionary *)param
                           success:(void(^)(NSString *time,NSString*message))success
                            falure:(void(^)(NSError *error))falure;
@end
