//
//  RLVehicleInformationModel.m
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLVehicleInformationModel.h"

@implementation RLVehicleInformationModel
+ (void)getVehicleReservationsTime:(NSDictionary *)param
                 success:(void(^)(NSString *time,NSString*message))success
                  falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafePOST:URI_INTERFACES_VEHICLERESERCATIONS_TIME parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success([responseObject jk_stringForKey:@"result"],nil);
        }else{
            success(nil,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
@end
