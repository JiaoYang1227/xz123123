//
//  MainOperationView.m
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLVehicleInformationView.h"
#import "RLInclude.h"
#import "RLVehicleInformationModel.h"
#import "JKAlert.h"
#import "RLOperationModel.h"
#import <SVProgressHUD.h>
#import "RLControlCarPopupView.h"
#import "UIViewController+JKPopup.h"
#import <UIImage+GIF.h>
#import "RLLocationManager.h"
#import "ReturnCarModel.h"
#import <RGBleSDK/RGBleSDK.h>
#import "NSTimer+UsingBlock.h"
#import "RDToast.h"
#import "RLMicro.h"
@implementation RLVehicleInformationView{
    NSString *_order_numbers;
    NSString *_vin;
    
    UIView *_viewLeft;
    UIView *_viewRight;
    UILabel *_timeLB;
    UILabel *_timeTitleLB;
    UIButton *_honkingBtn;
    
    UIButton *_bluetoothIcon;
    UILabel *_bluetoothTitleLB;
    UIButton *_flashBtn;
    
    NSTimer *_countDownTimer;
    long _secondsCountDown;//倒计时秒数
    
    RLControlCarPopupView *_returnCarPop;
    
    UIImage *_hubImage;
    
    BOOL _bluetoothSuccess;
    
    NSDate *_lastClickTime;

}


- (instancetype)initWithFrame:(CGRect)frame orderNumber:(NSString *)orderNumber vin:(NSString *)vin phone:(NSString *)phone userid:(NSString *)userid
{
    self = [super initWithFrame:frame];
    if (self) {
        _bluetoothSuccess = NO;
        [self setOrderNumber:orderNumber vin:vin phone:phone userid:userid];
        
        [self buidView];
    }
    return self;
}

-(void)setOrderNumber:(NSString *)orderNumber vin:(NSString *)vin phone:(NSString *)phone userid:(NSString *)userid{
    self.vin = vin;
    self.orderNumber = orderNumber;
    self.phone = phone;
    self.userid = userid;
    if ([self ISAssignment]) {
        [self.centralManager stopScan];
    }
    [self loadData];
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self buidView];
}
-(void)buidView{
    
    _returnCarPop = [[RLControlCarPopupView alloc] initWithNibName:@"RLControlCarPopupView" bundle:[NSBundle RLResourceBundle]];
    
    
    _viewLeft = [[UIView alloc]init];
    [self addSubview:_viewLeft];
    _viewRight = [[UIView alloc]init];
    [self addSubview:_viewRight];
    
    
    _timeLB = [[UILabel alloc]init];
//    _timeLB.text = @"15:00";
//    //倒计时
//    [self countdown];
    
    [_timeLB setTextAlignment:NSTextAlignmentCenter];
    _timeLB.font = [UIFont systemFontOfSize:14];
    [_viewLeft addSubview:_timeLB];
    
    _timeTitleLB = [[UILabel alloc]init];
    _timeTitleLB.text = @"保留时间";
    [_timeTitleLB setTextAlignment:NSTextAlignmentCenter];
    _timeTitleLB.font = [UIFont systemFontOfSize:14];
    [_viewLeft addSubview:_timeTitleLB];
    
    
    _honkingBtn= [[UIButton alloc]init];
    [_honkingBtn setTitle:@"鸣笛" forState:UIControlStateNormal];
    [_honkingBtn addTarget:self action:@selector(honkingTouched:) forControlEvents:UIControlEventTouchUpInside];
    [_honkingBtn setTitleColor:[UIColor colorWithRed:29.0/255.0 green:139.0/255.0 blue:241.0/255.0 alpha:1] forState:UIControlStateNormal];
    [_honkingBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    [_honkingBtn setBackgroundImage:[UIImage RLImageNamed:@"RLOperationView_btn_Rectangle"] forState:UIControlStateNormal];
    [_honkingBtn setBackgroundImage:[UIImage RLImageNamed:@"RLOperationView_btn_gray"] forState:UIControlStateHighlighted];
    [_viewLeft addSubview:_honkingBtn];
    
    
    _bluetoothIcon= [[UIButton alloc]init];
    [_bluetoothIcon setImage:[UIImage RLImageNamed:@"RLMainOperation_bluetooth_disconnection"] forState:UIControlStateNormal];
    [_bluetoothIcon addTarget:self action:@selector(bluetTouched:) forControlEvents:UIControlEventTouchUpInside];
    [_viewRight addSubview:_bluetoothIcon];
    
    _bluetoothTitleLB = [[UILabel alloc]init];
    _bluetoothTitleLB.text = @"蓝牙连接";
    [_bluetoothTitleLB setTextAlignment:NSTextAlignmentCenter];
    _bluetoothTitleLB.font = [UIFont systemFontOfSize:14];
    [_viewRight addSubview:_bluetoothTitleLB];
    
    _flashBtn= [[UIButton alloc]init];
    [_flashBtn setTitle:@"闪灯" forState:UIControlStateNormal];
    [_flashBtn addTarget:self action:@selector(flashTouched:) forControlEvents:UIControlEventTouchUpInside];
    [_flashBtn setTitleColor:[UIColor colorWithRed:29.0/255.0 green:139.0/255.0 blue:241.0/255.0 alpha:1] forState:UIControlStateNormal];
    [_flashBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    [_flashBtn setBackgroundImage:[UIImage RLImageNamed:@"RLOperationView_btn_Rectangle"] forState:UIControlStateNormal];
    [_flashBtn setBackgroundImage:[UIImage RLImageNamed:@"RLOperationView_btn_gray"] forState:UIControlStateHighlighted];
    [_viewRight addSubview:_flashBtn];
    
    NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    _hubImage = [UIImage sd_animatedGIFWithData:data];
    
    
    [self changeFrame];
}

-(void)loadData{
    if ([self ISAssignment]) {
        NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
        [param setValue:self.orderNumber?:@"" forKey:@"order_numbers"];
        [param setValue:self.vin?:@"" forKey:@"vin"];
        [param setValue:self.userid?:@"" forKey:@"aid"];
        [param setValue:self.phone?:@"" forKey:@"phone"];
        
        [RLVehicleInformationModel getVehicleReservationsTime:param success:^(NSString *time, NSString *message) {
            if (time) {
                RLLog(@"保留时间:%@",time);
//                _secondsCountDown = [time longLongValue];//倒计时秒数
                _secondsCountDown = 2 * 3600;//倒计时秒数

                if (_secondsCountDown>0) {
                    [self countdown];
                    if (self.retentionTimeOut) {
                        self.retentionTimeOut(time);
                    }
                }else{
                    _timeLB.text = @"00:00";
                    if (self.retentionTimeOut) {
                        self.retentionTimeOut(@"保留时间为0");
                    }
                }

            }else{
                [JKAlert showMessage:message];
            }
        } falure:^(NSError *error) {
            [JKAlert showMessage:@"网络连接失败,请重试!"];
        }];
        
//        NSString *ticketStr = @"Wod4pIapeBRYNPx2zWstWr3eTkABfguBfpjGOZHg8K5hB1hfy/HCX+TPy4eq4zioEr+2HQ5oqRlnREYM2PKKcd3eUSPpxWYXrv2mdrw0EpcIxmkNNv1Ol1J6AKv/KCeNdhk6LUAijr1P5rVrbsG+wD2yeeIvTCCRZfJhHZbl+XcshoVldFtZbT4eDAV0+GXZJ2wShhjqvmn1hUozUre1dvJHRsZ74piAnCF3GAqP28lpB2Uqk2HHdt3ZVwVRZa9Tm4TlhG66Rn82BzoBgxMdigTCBlgZ06TrWa6j+6dYmjg=";
//        //蓝牙
//        [[RGBleController shareController] connectWithTicket:ticketStr result:^(BOOL isSuccess, RGBleError *error) {
//            if (isSuccess) {
//                _bluetoothSuccess = YES;
//                [_bluetoothIcon setImage:[UIImage RLImageNamed:@"RLMainOperation_bluetooth"] forState:UIControlStateNormal];
//            }
//            if (error) {
//                RLLog(@"error --- %@", error);
//            }
//        }];
    }
}
-(void)honkingTouched:(UIButton *)sender{
    if (_lastClickTime&&[[NSDate date] timeIntervalSinceDate:_lastClickTime]<3) {
        RLLog(@"1111111%f",[[NSDate date] timeIntervalSinceDate:_lastClickTime]);
        _lastClickTime = [NSDate date];
        [RDToast showWithText:@"您的操作过于频繁，请稍后再试"];
        return;
    }
    _lastClickTime = [NSDate date];
    
    RLLog(@"鸣笛");
//    if (_bluetoothSuccess == YES) {
//        [[RGBleController shareController] searchingCarWithExeSuccess:^(id result) {
//            //成功 在这里做成功之后的事，result暂时不需要关注
//        } exeFailed:^(RGBleError *bleError) {
//            [self searchingCar];
//            //失败
//            RLLog(@"失败：%@", bleError);
//        }];
//    }else{
        [self searchingCar];
//    }
    
}
//网络控车鸣笛
-(void)searchingCar{
    [self getDistanceBlock:^(BOOL limit50) {
        if (limit50) {
            if ([self ISAssignment]) {
                NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
                [param setValue:self.orderNumber?:@"" forKey:@"orderNumbers"];
                [param setValue:self.vin?:@"" forKey:@"vin"];
                [param setValue:self.userid?:@"" forKey:@"userid"];
                [param setValue:@"app" forKey:@"datafrom"];
                [param setValue:@"02" forKey:@"type"];
                
                
                [SVProgressHUD setInfoImage:_hubImage];
                SVProgressHUD.backgroundColor = [UIColor whiteColor];
                [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
                [SVProgressHUD showInfoWithStatus:@"努力加载中..."];
                [SVProgressHUD setImageViewSize:CGSizeMake(80, 53)];
                
                [RLOperationModel controlCar:param success:^(BOOL success,NSString *message) {
                    if (success) {
                        [SVProgressHUD setMaximumDismissTimeInterval:3];
                        [SVProgressHUD setInfoImage:_hubImage];
                        [SVProgressHUD showInfoWithStatus:@"鸣笛中..."];
                        
                    }else{
                        [SVProgressHUD dismiss];
                        [JKAlert showMessage:message];
                        
                    }
                } falure:^(NSError *error) {
                    [SVProgressHUD dismiss];
                    [JKAlert showMessage:@"网络连接失败,请重试!"];
                }];
            }
        }
    }];
}

-(void)flashTouched:(UIButton *)sender{
    if (_lastClickTime&&[[NSDate date] timeIntervalSinceDate:_lastClickTime]<3) {
        RLLog(@"1111111%f",[[NSDate date] timeIntervalSinceDate:_lastClickTime]);
        _lastClickTime = [NSDate date];
        [RDToast showWithText:@"您的操作过于频繁，请稍后再试"];
        return;
    }
    _lastClickTime = [NSDate date];
    RLLog(@"闪灯");
//    if (_bluetoothSuccess == YES) {
//        [[RGBleController shareController] lightFlickerWithExeSuccess:^(id result) {
//            //成功 在这里做成功之后的事，result暂时不需要关注
//        } exeFailed:^(RGBleError *bleError) {
//            //失败
//            RLLog(@"失败：%@", bleError);
//            [self lightFlicker];
//        }];
//    }else{
        [self lightFlicker];
//    }
    
}
//网络控车闪灯
-(void)lightFlicker{
    [self getDistanceBlock:^(BOOL limit50) {
        if (limit50) {
            if ([self ISAssignment]) {
                NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
                [param setValue:self.orderNumber?:@"" forKey:@"orderNumbers"];
                [param setValue:self.vin?:@"" forKey:@"vin"];
                [param setValue:self.userid forKey:@"userid"];
                [param setValue:@"app" forKey:@"datafrom"];
                [param setValue:@"01" forKey:@"type"];
                [SVProgressHUD setInfoImage:_hubImage];
                SVProgressHUD.backgroundColor = [UIColor whiteColor];
                [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
                [SVProgressHUD showInfoWithStatus:@"努力加载中..."];
                [SVProgressHUD setImageViewSize:CGSizeMake(80, 53)];
                
                [RLOperationModel controlCar:param success:^(BOOL success,NSString *message) {
                    if (success) {
                        [SVProgressHUD setMaximumDismissTimeInterval:3];
                        [SVProgressHUD setInfoImage:_hubImage];
                        [SVProgressHUD showInfoWithStatus:@"闪灯中..."];
                        //                _returnCarPop.status = @"闪灯中";
                        //                [[self viewController] presentJKPopupViewController:_returnCarPop];
                    }else{
                        [SVProgressHUD dismiss];
                        [JKAlert showMessage:message];
                    }
                } falure:^(NSError *error) {
                    [SVProgressHUD dismiss];
                    [JKAlert showMessage:@"网络连接失败,请重试!"];
                }];
            }
        }
    }];
}
-(void)changeFrame{
    float height = self.frame.size.height*16.0/56.0;
    float width = height/16.0*38.0;
    
    float xSpacing = (self.frame.size.width/2-width)/2;
    float ySpacing = (self.frame.size.height-height-55)/2+55;
    
    [_viewLeft setFrame:CGRectMake(0, 0, self.frame.size.width/2, self.frame.size.height)];
    [_viewRight setFrame:CGRectMake(self.frame.size.width/2, 0, self.frame.size.width/2, self.frame.size.height)];
    
    [_timeLB setFrame:CGRectMake(0, 5, self.frame.size.width/2, 20)];
    [_timeTitleLB setFrame:CGRectMake(0, 30, self.frame.size.width/2, 20)];
    [_honkingBtn setFrame:CGRectMake(xSpacing, ySpacing, width, height)];
    
    [_bluetoothIcon setFrame:CGRectMake(0, 5, self.frame.size.width/2, 20)];
    [_bluetoothTitleLB setFrame:CGRectMake(0, 30, self.frame.size.width/2, 20)];
    [_flashBtn setFrame:CGRectMake(xSpacing, ySpacing, width, height)];

}
-(void)layoutSubviews{
    
    [self changeFrame];
    
}

- (void)bluetTouched:(id)sender{
    if (_bluetoothSuccess == YES) {
        [RDToast showWithText:@"蓝牙已开启" bottomOffset:80];
    }else{
        [RDToast showWithText:@"蓝牙是关闭状态,请打开蓝牙" bottomOffset:80];
    }
    
//    NSString *ticketStr = @"Wod4pIapeBRYNPx2zWstWr3eTkABfguBfpjGOZHg8K5hB1hfy/HCX+TPy4eq4zioEr+2HQ5oqRlnREYM2PKKcd3eUSPpxWYXrv2mdrw0EpcIxmkNNv1Ol1J6AKv/KCeNdhk6LUAijr1P5rVrbsG+wD2yeeIvTCCRZfJhHZbl+XcshoVldFtZbT4eDAV0+GXZJ2wShhjqvmn1hUozUre1dvJHRsZ74piAnCF3GAqP28lpB2Uqk2HHdt3ZVwVRZa9Tm4TlhG66Rn82BzoBgxMdigTCBlgZ06TrWa6j+6dYmjg=";
//    //    RGBleError *error = nil;
//    [self.centralManager stopScan];
//    [[RGBleController shareController] connectWithTicket:ticketStr result:^(BOOL isSuccess, RGBleError *error) {
//        if (isSuccess) {
//            _bluetoothSuccess =YES;
//            [_bluetoothIcon setImage:[UIImage RLImageNamed:@"RLMainOperation_bluetooth"] forState:UIControlStateNormal];
//        }
//        if (error) {
//            RLLog(@"error --- %@", error);
//        }
//    }];
}

- (void)countdown{
    //倒计时
    [_countDownTimer invalidate];
    _countDownTimer = nil;
    
    __weak typeof(self) weakSelf = self;
    //启动倒计时后会每秒钟调用一次方法 countDownAction
    _countDownTimer = [NSTimer  ub_scheduledTimerWithTimeInterval:1.0 block:^{
        [weakSelf countDownAction];
        
    } repeats:YES];
    
    [[NSRunLoop currentRunLoop]addTimer:_countDownTimer forMode:NSRunLoopCommonModes];

    //设置倒计时显示的时间
//    NSString *str_hour = [NSString stringWithFormat:@"%02ld",_secondsCountDown/3600];//时
    NSString *str_minute = [NSString stringWithFormat:@"%02ld",(_secondsCountDown%3600)/60];//分
    NSString *str_second = [NSString stringWithFormat:@"%02ld",_secondsCountDown%60];//秒
    NSString *format_time = [NSString stringWithFormat:@"%@:%@",str_minute,str_second];
    RLLog(@"time:%@",format_time);
    _timeLB.text = format_time;
}

-(void) countDownAction{
    //倒计时-1
    _secondsCountDown--;
    NSString *str_hour = [NSString stringWithFormat:@"%02ld",_secondsCountDown/3600];
    NSString *str_minute = [NSString stringWithFormat:@"%02ld",(_secondsCountDown%3600)/60];
    NSString *str_second = [NSString stringWithFormat:@"%02ld",_secondsCountDown%60];
    NSString *format_time = [NSString stringWithFormat:@"%@:%@:%@",str_hour,str_minute,str_second];
    //修改倒计时标签现实内容
   _timeLB.text = format_time;
    //当倒计时到0时，做需要的操作
    if(_secondsCountDown==0){
        [_countDownTimer invalidate];
        if (self.retentionTimeOut) {
            self.retentionTimeOut(@"保留时间为0");
        }
    }
}

-(BOOL)ISAssignment{
    if (!self.vin||[@""isEqualToString:self.vin]||
        !self.orderNumber||[@""isEqualToString:self.orderNumber]||
        !self.phone||[@""isEqualToString:self.phone]||
        !self.userid||[@""isEqualToString:self.userid]) {
        RLLog(@"没有vin,和orderNumber,phone,userid请调用这个方法添加-(void)setOrderNumber:(NSString *)orderNumber vin:(NSString *)vin phone:(NSString *)phone userid:(NSString *)userid");
        return NO;
    }
    return YES;
}
//判断距离是否在50米以内
-(void)getDistanceBlock:(void(^)(BOOL limit50))block{
    if (!self.vin||[@""isEqualToString:self.vin]||
        !self.orderNumber||[@""isEqualToString:self.orderNumber]) {
        RLLog(@"没有vin,和orderNumber,userid,请调用这个方法-(void)setOrderNumber:(NSString *)orderNumber vin:(NSString *)vin userid:(NSString *)userid");
        return;
    }
    
    
    NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    UIImage *hubImage = [UIImage sd_animatedGIFWithData:data];
    [SVProgressHUD setInfoImage:hubImage];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    SVProgressHUD.backgroundColor = [UIColor whiteColor];
    [SVProgressHUD showInfoWithStatus:@"获取位置信息..."];
    NSMutableDictionary *returnCarparam = [[NSMutableDictionary alloc]init];
    [returnCarparam setValue:self.vin?:@"" forKey:@"vin"];
    [returnCarparam setValue:self.userid?:@"" forKey:@"aid"];
    [returnCarparam setValue:@"runlin" forKey:@"datafrom"];
    __block double lat1;
    __block double lng1;
    [ReturnCarModel drivingData:returnCarparam success:^(NSArray *result, NSDictionary *location, NSString *message) {
        if (location) {
            lat1 = [[location jk_stringForKey:@"latitude"] doubleValue];
            lng1 = [[location jk_stringForKey:@"longitude"] doubleValue];
            RLLog(@"车辆位置 (%f, %f)", lat1, lng1);
            //只获取一次
            __block  BOOL isOnece = YES;
            [RLLocationManager getMoLocationWithSuccess:^(double lat, double lng){
                isOnece = NO;
                [SVProgressHUD dismiss];
                RLLog(@"手机位置 (%f, %f)", lat, lng);
                CLLocation *orig=[[CLLocation alloc] initWithLatitude:lat1  longitude:lng1];
                CLLocation* dist=[[CLLocation alloc] initWithLatitude:lat longitude:lng];
                
                CLLocationDistance kilometers=[orig distanceFromLocation:dist];
                if (kilometers<=50) {
                    block(YES);
                }else{
                    block(NO);
                    [JKAlert showMessage:@"距离过远，请离近再试"];
                }
                RLLog(@"距离:%f",kilometers);
                if (!isOnece) {
                    [RLLocationManager stop];
                }
            } Failure:^(NSError *error){
                isOnece = NO;
                RLLog(@"error = %@", error);
                if (!isOnece) {
                    [RLLocationManager stop];
                }
                block(NO);
                [JKAlert showMessage:@"位置请求失败!"];
                [SVProgressHUD dismiss];
            }];
        }else{
            [JKAlert showMessage:@"车辆位置请求失败!"];
            [SVProgressHUD dismiss];
            block(NO);
        }
    } falure:^(NSError *error) {
        [JKAlert showMessage:@"网络连接失败,请重试!"];
        block(NO);
        [SVProgressHUD dismiss];
    }];

}



//蓝牙
- (CBCentralManager *)centralManager
{
    if (!_centralManager)
    {
        _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return _centralManager;
}

// 当状态更新时调用(如果不实现会崩溃)
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
        case CBManagerStateUnknown:{
            RLLog(@"未知状态");
        }
            break;
        case CBManagerStateResetting:
        {
            RLLog(@"重置状态");
        }
            break;
        case CBManagerStateUnsupported:
        {
            RLLog(@"不支持的状态");
        }
            break;
        case CBManagerStateUnauthorized:
        {
            RLLog(@"未授权的状态");
        }
            break;
        case CBManagerStatePoweredOff:
        {
            RLLog(@"关闭状态");
            [_bluetoothIcon setImage:[UIImage RLImageNamed:@"RLMainOperation_bluetooth_disconnection"] forState:UIControlStateNormal];
            [RDToast showWithText:@"蓝牙是关闭状态,请打开蓝牙,再进行连接" bottomOffset:80];
        }
            break;
        case CBManagerStatePoweredOn:
        {
            RLLog(@"开启状态－可用状态");
//            [JKAlert showMessage:@"蓝牙已开启"];
            _bluetoothSuccess = YES;
            [_bluetoothIcon setImage:[UIImage RLImageNamed:@"RLMainOperation_bluetooth"] forState:UIControlStateNormal];
        }
            break;
        default:
            break;
    }
}

@end
