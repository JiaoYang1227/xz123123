//
//  RLControlCarPopupView.h
//  RLLibrary
//
//  Created by sun on 2018/3/19.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RLControlCarPopupView : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *titleLB;
@property (weak,nonatomic)NSString *status;
@end
