
//  RLControlCarPopupView.m
//  RLLibrary
//
//  Created by sun on 2018/3/19.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLControlCarPopupView.h"
#import "UIViewController+JKPopup.h"
#import "RLInclude.h"
#import <UIImage+GIF.h>
#import "NSTimer+UsingBlock.h"
@interface RLControlCarPopupView (){
    NSTimer *timer;
    __weak IBOutlet UIWebView *_webView;
    __weak IBOutlet UIImageView *gifImageView;
}

@end

@implementation RLControlCarPopupView

- (void)viewDidLoad {
    [super viewDidLoad];
    self.titleLB.text = self.status;
    __weak typeof(self) weakSelf = self;
    timer = [NSTimer  ub_scheduledTimerWithTimeInterval:3.0 block:^{
        [weakSelf timerAction];
        
    } repeats:YES];
    
    [[NSRunLoop currentRunLoop]addTimer:timer forMode:NSRunLoopCommonModes];
    
    NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    UIImage *image = [UIImage sd_animatedGIFWithData:data];
    gifImageView.image = image;
}

-(void)timerAction{
    [timer invalidate];
    [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
        
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
