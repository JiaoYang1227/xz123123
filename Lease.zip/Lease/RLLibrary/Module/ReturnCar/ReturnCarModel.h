//
//  ReturnCarModel.h
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"
#import <RGBleSDK/RGBleSDK.h>
@interface ReturnCarModel : RLBaseModel
@property (nonatomic,copy)NSString *vin;//底盘号
@property (nonatomic,copy)NSString *aid;//用户id
@property (nonatomic,copy)NSString *orderNumber;//订单编号
@property (nonatomic,copy)NSString *version;//版本号
@property (nonatomic,copy)NSString *time;//采集时间
@property (nonatomic,copy)NSString *longitude;//经度
@property (nonatomic,copy)NSString *latitude;//纬度
@property (nonatomic,copy)NSString *allMileage;//总里程 米
@property (nonatomic,copy)NSString *speed;//时速 公里/小时
@property (nonatomic,copy)NSString *oil;//油位 升
@property (nonatomic,copy)NSString *surplusMileage;//剩余里程（公里）
@property (nonatomic,copy)NSString *engineSpeed;//发动机转速
@property (nonatomic,copy)NSString *engineDoor;//发动机舱盖
@property (nonatomic,copy)NSString *farlight;//远光灯
@property (nonatomic,copy)NSString *nearlight;//近光灯
@property (nonatomic,copy)NSString *widelight;//示宽灯
@property (nonatomic,copy)NSString *trunkLock;//后备箱
@property (nonatomic,copy)NSString *leftFrontDoor;//左前门门锁
@property (nonatomic,copy)NSString *rightFrontDoor;//右前门门锁
@property (nonatomic,copy)NSString *leftBackDoor;//左后门门锁
@property (nonatomic,copy)NSString *rightBackDoor;//右后门门锁

@property (nonatomic,copy)NSString *leftFrontWindow;//左后门门锁
@property (nonatomic,copy)NSString *rightFrontWindow;//右后门门锁
@property (nonatomic,copy)NSString *leftBackWindow;//左前窗
@property (nonatomic,copy)NSString *rightBackWindow;//右前窗
@property (nonatomic,copy)NSString *skyWindow;//天窗
@property (nonatomic,copy)NSString *waterTemperature;//水温
@property (nonatomic,copy)NSString *maintainMileage;//保养里程
@property (nonatomic,copy)NSString *maintainDays;//保养天数
@property (nonatomic,copy)NSString *carOuterTemperature;//车外温度
@property (nonatomic,copy)NSString *carVoltage;//车辆蓄电池电压
@property (nonatomic,copy)NSString *engineOilLevel;//    机油液位（毫米）
@property (nonatomic,copy)NSString *engineOilLower;//   机油下限值（毫米）
@property (nonatomic,copy)NSString *handbrakeState;//    手刹状态
@property (nonatomic,copy)NSString *gear;//    档位
@property (nonatomic,copy)NSString *leftFrontDoorState;//    门状态（左前门）
@property (nonatomic,copy)NSString *rightFrontDoorState;//    门状态（右前门）
@property (nonatomic,copy)NSString *leftBackDoorState;//    门状态（左后门）
@property (nonatomic,copy)NSString *rightBackDoorState;//    门状态（右前门）
@property (nonatomic,copy)NSString *surplusElectric;//    电动车高压电池剩余电量
@property (nonatomic,copy)NSString *powerUp;//   上电状态
@property (nonatomic,copy)NSString *boot;
-(void)initWithRoiCarStatus:(RoiCarStatus *)RoiCarStatus;
//查询实时行车数据
+ (void)drivingData:(NSDictionary *)param
            success:(void(^)(NSArray *result,NSDictionary *location,NSString *message))success
             falure:(void(^)(NSError *error))falure;

//下发还车指令接口
+ (void)checkCar:(NSDictionary *)param
         success:(void(^)(id responseObject,BOOL success,NSString *message,BOOL isOrder))success
          falure:(void(^)(NSError *error))falure;

//获取还车结果接口
+ (void)getCheckCarCode:(NSDictionary *)param
                success:(void(^)(BOOL success,NSArray *result,NSString *message,NSDictionary *location))success
                 falure:(void(^)(NSError *error))falure;
//查询GPS坐标是否在场站
+ (void)checkDot:(NSDictionary *)param
                success:(void(^)(id responseObject,BOOL success,double returnCost,NSString *message))success
                 falure:(void(^)(NSError *error))falure;
//获取还车结果接口
+ (void)checkCarBluetooth:(NSDictionary *)param
                  success:(void(^)(id responseObject,BOOL success,NSArray *result,NSString *message,NSDictionary *location,BOOL isOrder))success
                   falure:(void(^)(NSError *error))falure;
//价格结束订单

+ (void)reckonCostFinishOrder:(NSDictionary *)param
                      success:(void(^)(BOOL success,NSString *message))success
                       falure:(void(^)(NSError *error))falure;
+(NSArray *)getCheckCarCode:(NSString *)type;
+(ReturnCarModel *)returnCarModelCarStatus:(RoiCarStatus *)roiCarStatus;

//jia
//+(ReturnCarModel *)returnCarModel;
@end
