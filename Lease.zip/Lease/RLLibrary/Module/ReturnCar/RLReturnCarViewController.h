//
//  RLReturnCarViewController.h
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^JumpThePayment)(BOOL jump,NSDictionary *location,BOOL isOrder);

typedef void(^ReconnectBluetooth)(void);

@interface RLReturnCarViewController : UIViewController
@property (nonatomic,copy) JumpThePayment jumpThePayment;
@property (nonatomic,copy) ReconnectBluetooth reconnectBluetooth;

@property(nonatomic,strong)NSString *vin;
@property(nonatomic,strong)NSString *userid;
@property(nonatomic,strong)NSString *orderNumber;
@end
