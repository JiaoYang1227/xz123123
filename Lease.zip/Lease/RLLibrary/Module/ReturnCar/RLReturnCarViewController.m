//
//  RLReturnCarViewController.m
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLReturnCarViewController.h"
#import "RLReturnCarCell.h"
#import "RLInclude.h"
#import "UIViewController+JKPopup.h"
#import "DetermineButton.h"
#import "ReturnCarModel.h"
#import "JKAlert.h"
#import <SVProgressHUD.h>
#import <UIImage+GIF.h>
#import "RLFileManager.h"
#import "RLOperationModel.h"
#import "DateManager.h"
#import <RGBleSDK/RGBleSDK.h>
#import "NSTimer+UsingBlock.h"
#import "RLOperationManager.h"
#import "RDToast.h"
#import "ReturnCarModel.h"
#import "LogWriter.h"
#import "RLMicro.h"
@class RLInclude;
@interface RLReturnCarViewController (){
    
    __weak IBOutlet UILabel *_IncompletePrompt;//未完成提示
    __weak IBOutlet DetermineButton *_backBtn;
    NSTimer *_countDownTimer;
    long _secondsCountDown;//倒计时秒数
    NSMutableArray *_dataList;
    __weak IBOutlet UITableView *_tableView;
    __weak IBOutlet UIImageView *loadGif;
    __weak IBOutlet UILabel *_title;
    __weak IBOutlet UIView *_confirmCarView;
    BOOL _isBack;//直接返回,不需要跳转支付页
    NSDictionary *_location;
    NSDate *_lastClickTime;
    ReturnCarModel *_returnCarModel;
    BOOL _isorder;
    UIImage *_hubImage;

}

@end

@implementation RLReturnCarViewController
-(UIImage*)loadHubImag{
    if(_hubImage==nil){
        NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
        NSData *data = [NSData dataWithContentsOfFile:path];
        _hubImage = [UIImage sd_animatedGIFWithData:data];
    }
    return _hubImage;
}
- (void)viewDidLoad {
    [super viewDidLoad];
//    [LogWriter uploadLog];
    _isBack = YES;
    _isorder = NO;
}

//蓝牙查询车辆状态
-(void)RGBleReturnCar{
    [LogWriter writeLog:@"RLReturnCarVC"
                 detail:@"蓝牙查询车辆状态"
               inParams:nil outParams:nil];
    
    
    [SVProgressHUD setMaximumDismissTimeInterval:3];
    [SVProgressHUD setInfoImage:[self loadHubImag]];
    [SVProgressHUD showInfoWithStatus:@"蓝牙还车中"];
    [[RGBleController shareController]fetchCarStatusWithExeSuccess:^(RoiCarStatus *statusModel) {
        [SVProgressHUD dismiss];
        if (statusModel) {
            _returnCarModel = [ReturnCarModel returnCarModelCarStatus:statusModel];
         
            [LogWriter writeLog:@"蓝牙查询车辆状态"
                         detail:@"有数据"
                       inParams:[_returnCarModel toDictionary] outParams:nil];
            
            [self checkDot:YES];
        }else{
            [LogWriter writeLog:@"蓝牙查询车辆状态"
                         detail:@"数据为空"
                       inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:nil];
          
             [self checkDot:NO];
        }
        
    } exeFailed:^(RGBleError *bleError) {
        [SVProgressHUD dismiss];

        [LogWriter writeLog:@"蓝牙查询车辆状态"
                     detail:@"exeFailed失败"
                   inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:@{@"error":bleError.debugDescription?:@""}];
        [self checkDot:NO];
    }];
}
//蓝牙还车检查
-(void)checkCarBluetooth{
    
    _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
    
    [_tableView reloadData];
    [_IncompletePrompt setHidden:YES];
    //    _returnCarModel = [ReturnCarModel returnCarModel];
    if (_returnCarModel==nil) {
        return;
    }
    
    _returnCarModel.vin = self.vin?:@"";
    _returnCarModel.aid = self.userid?:@"";
    _returnCarModel.orderNumber = self.orderNumber?:@"";
    
    NSDictionary *dic = [_returnCarModel toDictionary];
    

    
    [ReturnCarModel checkCarBluetooth:dic success:^(id responseObject,BOOL success, NSArray *result, NSString *message, NSDictionary *location,BOOL isOrder) {
        
        [LogWriter writeLog:@"网络蓝牙还车"
                     detail:@"网络请求成功"
                   inParams:dic outParams:responseObject];
        
        
        if (location) {
            _location = [NSDictionary dictionaryWithDictionary:location];
        }
        if (success == YES) {
            if (isOrder==YES) {
                _dataList = [NSMutableArray arrayWithArray:result];
                [_tableView reloadData];
                _isBack = YES;
                _isorder = YES;
                [RLInclude terminationControlCar];
                [self countdown];
            }else{
                _isBack = NO;
                _dataList = [NSMutableArray arrayWithArray:result];
                [_tableView reloadData];
                for (NSDictionary *dic in _dataList) {
                    if ([[dic jk_stringForKey:@"state"]isEqualToString:@"1"]) {
                        [_IncompletePrompt setHidden:NO];
                        _isBack = YES;
                        
                    }
                }
                if (_isBack == YES) {
                    [self countdown];
                }else{
                    [self reckonCostFinishOrder];
                    [_backBtn setTitle:@"去支付" forState:UIControlStateNormal];
                    //                [self performSelector:@selector(backTouched:) withObject:nil afterDelay:1.0];
                }
            }
        }else{
            _isBack = YES;
            _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
            [_tableView reloadData];
            //            [JKAlert showMessage:message];
            _IncompletePrompt.text = @"网络异常，请稍后再试";
            [_IncompletePrompt setHidden:NO];
            [self countdown];
            [_backBtn setHidden:NO];
            [_title setHidden:YES];
        }

    } falure:^(NSError *error) {
        _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
        [_tableView reloadData];
        _IncompletePrompt.text = @"网络异常，请稍后再试";
        [_IncompletePrompt setHidden:NO];
        [_backBtn setHidden:NO];
        [self countdown];
        [_title setHidden:YES];
       
        
        [LogWriter writeLog:@"网络蓝牙还车"
                     detail:@"网络请求失败"
                   inParams:dic outParams:@{@"error":error.localizedDescription?:@""}];
    }];
    
}
//是否在网点
-(void)checkDot:(BOOL) Bluetooth{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:self.vin?:@"" forKey:@"vin"];
    if (Bluetooth==YES) {
        [dic setObject:@"Bluetooth" forKey:@"type"];
        if (_returnCarModel!=nil && _returnCarModel.latitude>0&&_returnCarModel.longitude>0) {
            [dic setValue:_returnCarModel.longitude forKey:@"longitude"];
            [dic setValue:_returnCarModel.latitude forKey:@"latitude"];
            
        }else{
            [dic setValue:@"" forKey:@"longitude"];
            [dic setValue:@"" forKey:@"latitude"];
            
        }
    }else{
        [dic setObject:@"network" forKey:@"type"];
        [dic setValue:@"" forKey:@"longitude"];
        [dic setValue:@"" forKey:@"latitude"];
    }
  
    
    [LogWriter writeLog:@"可还区域检查"
                 detail:[RLOperationManager sharedManager].authKey?:@""
               inParams:dic outParams:nil];
    
    [ReturnCarModel checkDot:dic success:^(id respoe,BOOL success, double returnCost, NSString *message) {
        
        [LogWriter writeLog:@"可还区域检查"
                     detail:@"网络请求成功"
                   inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:respoe];
        
        if (success==YES) {
            if([respoe jk_boolForKey:@"result"]){
               
                if (returnCost==0) {
                    [LogWriter writeLog:@"可还区域检查"
                                 detail:@"网点费用为0直接还车" inParams:@{} outParams:@{}];
                    
                    [_confirmCarView setHidden:YES];
                    NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ReturnCar_loding" ofType:@"gif"];
                    NSData *data = [NSData dataWithContentsOfFile:path];
                    [loadGif setImage:[UIImage sd_animatedGIFWithData:data]];
                    if (Bluetooth == YES) {
                        [self checkCarBluetooth];//蓝牙还车
                    }else{
                        [self netReturnCar];//网络还车
                    }
                }else{
                    [LogWriter writeLog:@"可还区域检查"
                                 detail:@"网点费用不为0弹出提示" inParams:@{} outParams:@{}];
                    JKAlert *alert = [[JKAlert alloc]initWithTitle:@"提示" andMessage:[NSString stringWithFormat:@"停车网点费用:%f元",returnCost]];
                    [alert addButton:ITEM_OK withTitle:@"确定" handler:^(JKAlertItem *item) {
                        [_confirmCarView setHidden:YES];
                        NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ReturnCar_loding" ofType:@"gif"];
                        NSData *data = [NSData dataWithContentsOfFile:path];
                        [loadGif setImage:[UIImage sd_animatedGIFWithData:data]];
                        if (Bluetooth == YES) {
                            [self checkCarBluetooth];//蓝牙还车
                        }else{
                            [self netReturnCar];//网络还车
                        }
                    }];
                    [alert addButton:ITEM_CANCEL withTitle:@"取消" handler:^(JKAlertItem *item) {
                        
                    }];
                    [alert show];
                }
            }else{
               [RDToast showWithText:@"请到可还区域进行还车操作"];
                [LogWriter writeLog:@"请到可还区域进行还车操作"
                             detail:@"result false" inParams:@{} outParams:@{}];
            }
        }else{
             [RDToast showWithText:@"可还区域检查失败,请重试"];
            [LogWriter writeLog:@"可还区域检查"
                         detail:@"success failed" inParams:@{} outParams:@{}];
        }
    } falure:^(NSError *error) {
        [RDToast showWithText:@"可还区域检查失败,请重试"];
   
        
        [LogWriter writeLog:@"可还区域检查"
                     detail:@"网络请求失败"
                   inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:@{@"error":error.debugDescription}];
        
    }];
}
-(void)reckonCostFinishOrder{
    _isBack = NO;
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:self.orderNumber?:@"" forKey:@"orderNumbe"];
    [dic setValue:self.vin?:@"" forKey:@"vin"];
    [dic setValue:self.userid?:@"" forKey:@"aid"];
    
    [LogWriter writeLog:@"reckonCostFinishOrder"
                 detail:@""
               inParams:dic outParams:nil];
    
    [ReturnCarModel reckonCostFinishOrder:dic success:^(BOOL success,  NSString *message) {
        if (success) {
            _isBack = NO;
            [self performSelector:@selector(backTouched:) withObject:nil afterDelay:1.0];
        }else{
            [RDToast showWithText:message];
            _isBack = YES;
            [self performSelector:@selector(backTouched:) withObject:nil afterDelay:1.0];
        }
        [LogWriter writeLog:@"reckonCostFinishOrder"
                     detail:@"网络请求成功"
                   inParams:nil outParams:@{@"message":message?:@""}];
    } falure:^(NSError *error) {
        _isBack = YES;
        [self performSelector:@selector(backTouched:) withObject:nil afterDelay:1.0];
       
        [LogWriter writeLog:@"reckonCostFinishOrder"
                     detail:@"网络请求失败"
                   inParams:nil outParams:@{@"error":error.debugDescription?:@""}];
    }];
}

- (IBAction)backTouched:(id)sender {
    if (_isorder == YES) {
        if (self.jumpThePayment) {
            self.jumpThePayment(NO,_location?:@{},YES);
        }
       
        [LogWriter writeLog:@"还车成功"
                     detail:@"点击返回按钮"
                   inParams:@{@"vin":self.vin?:@"",@"userid":self.userid?:@"",@"_isorder":@(_isorder)} outParams:nil];
        
        [LogWriter uploadLog];
        [RDToast showWithText:@"还车成功，请到历史订单中进行查看和支付"];
        [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
            
        }];
    }else{
    if (_dataList&&_dataList.count>0) {
        if (_isBack == YES) {//返回
            if (self.jumpThePayment) {
                self.jumpThePayment(NO,_location?:@{},NO);
            }
          
            
            [LogWriter writeLog:@"还车成功"
                         detail:@"不需要跳支付页1"
                       inParams:@{@"vin":self.vin?:@"",@"userid":self.userid?:@"",@"_isorder":@(_isorder)} outParams:nil];
            
//            [LogWriter uploadLog];
            [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
                
            }];
        }else{//支付
            if (self.jumpThePayment) {
                self.jumpThePayment(YES,_location?:@{},NO);
            }

            [RLOperationManager destroyInstance];
            [[RGBleController shareController] disConnect];
            
            [LogWriter writeLog:@"还车成功"
                         detail:@"断开蓝牙连接"
                       inParams:nil outParams:nil];
            
            [LogWriter writeLog:@"还车成功"
                         detail:@"要跳支付页"
                       inParams:@{@"vin":self.vin?:@"",@"userid":self.userid?:@"",@"_isorder":@(_isorder)} outParams:_location];
            
           
//            [LogWriter uploadLog];
            [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
                
            }];
        }
    }else{
        if (self.jumpThePayment) {
            self.jumpThePayment(NO,_location?:@{},NO);
        }
        
        [LogWriter writeLog:@"还车成功"
                     detail:@"不需要跳支付页2"
                   inParams:@{@"vin":self.vin?:@"",@"userid":self.userid?:@"",@"_isorder":@(_isorder)} outParams:nil];
        
//        [LogWriter uploadLog];
        [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
            
        }];
    }
    }
}

-(void)loadData{
    if (!self.vin||[@"" isEqualToString:self.vin]||
        !self.userid||[@"" isEqualToString:self.userid]) {
        RLLog(@"没有vin或者没有用户id");
        return;
    }
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.vin?:@"" forKey:@"vin"];
    [param setValue:self.userid?:@"" forKey:@"aid"];
    [param setValue:@"runlin" forKey:@"datafrom"];

    
    [ReturnCarModel getCheckCarCode:param success:^(BOOL success, NSArray *result, NSString *message, NSDictionary *location) {
        if (location) {
            _location = [NSDictionary dictionaryWithDictionary:location];
        }
        if (success==YES) {//有值刷新
                _isBack = NO;
                _dataList = [NSMutableArray arrayWithArray:result];
                [_tableView reloadData];
                for (NSDictionary *dic in _dataList) {
                    if ([[dic jk_stringForKey:@"state"]isEqualToString:@"1"]) {
                        [_IncompletePrompt setHidden:NO];
                        _isBack = YES;
                    }
                }
                if (_isBack == YES) {
                    [self countdown];
                }else{
                    [_backBtn setTitle:@"去支付" forState:UIControlStateNormal];
                    [self reckonCostFinishOrder];
                }
            
        }else{//没值,3秒后走网络
            [self performSelector:@selector(secondLoadData) withObject:nil afterDelay:3.0];
        }
        
    } falure:^(NSError *error) {
        _isBack = YES;
        _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
        [_tableView reloadData];
        _IncompletePrompt.text = @"网络异常，请稍后再试";
        [_IncompletePrompt setHidden:NO];
        [self countdown];
        [_title setHidden:YES];
    }];
}
-(void)secondLoadData{
    if (!self.vin||[@"" isEqualToString:self.vin]||
        !self.userid||[@"" isEqualToString:self.userid]) {
        RLLog(@"没有vin或者没有用户id");
        return;
    }
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.vin?:@"" forKey:@"vin"];
    [param setValue:self.userid?:@"" forKey:@"aid"];
    [param setValue:@"runlin" forKey:@"datafrom"];
    [ReturnCarModel getCheckCarCode:param success:^(BOOL success, NSArray *result, NSString *message, NSDictionary *location) {
        if (location) {
            _location = [NSDictionary dictionaryWithDictionary:location];
        }
        
        if (success==YES) {//有值刷新
            
            _isBack = NO;
            _dataList = [NSMutableArray arrayWithArray:result];
            [_tableView reloadData];
            for (NSDictionary *dic in _dataList) {
                if ([[dic jk_stringForKey:@"state"]isEqualToString:@"1"]) {
                    [_IncompletePrompt setHidden:NO];
                    [self reckonCostFinishOrder];
                    _isBack = YES;
                }
            }
            if (_isBack == YES) {
                [self countdown];
            }else{
                [_backBtn setTitle:@"去支付" forState:UIControlStateNormal];
                [self reckonCostFinishOrder];
//                [self performSelector:@selector(backTouched:) withObject:nil afterDelay:1.0];
            
            }
        }else{//没值,3秒后走网络
            [self performSelector:@selector(thirdLoadData) withObject:nil afterDelay:3.0];
        }
        
    } falure:^(NSError *error) {
        _isBack = YES;
        _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
        [_tableView reloadData];
        _IncompletePrompt.text = @"网络异常，请稍后再试";
        [_IncompletePrompt setHidden:NO];
        [self countdown];
        [_title setHidden:YES];
    }];
}
-(void)thirdLoadData{
    if (!self.vin||[@"" isEqualToString:self.vin]||
        !self.userid||[@"" isEqualToString:self.userid]) {
        RLLog(@"没有vin或者没有用户id");
        return;
    }
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.vin?:@"" forKey:@"vin"];
    [param setValue:self.userid?:@"" forKey:@"aid"];
    [param setValue:@"runlin" forKey:@"datafrom"];
    [ReturnCarModel getCheckCarCode:param success:^(BOOL success, NSArray *result, NSString *message, NSDictionary *location) {
        if (location) {
            _location = [NSDictionary dictionaryWithDictionary:location];
        }
        if (success==YES) {//有值刷新
            
            _isBack = NO;
            _dataList = [NSMutableArray arrayWithArray:result];
            [_tableView reloadData];
            for (NSDictionary *dic in _dataList) {
                if ([[dic jk_stringForKey:@"state"]isEqualToString:@"1"]) {
                    [_IncompletePrompt setHidden:NO];
                    [self reckonCostFinishOrder];
                    _isBack = YES;
                }
            }
            if (_isBack == YES) {
                [self countdown];
            }else{
                [_backBtn setTitle:@"去支付" forState:UIControlStateNormal];
                [self reckonCostFinishOrder];
//                [self performSelector:@selector(backTouched:) withObject:nil afterDelay:1.0];
            
            }
        }else{//没值,4秒后走网络
            [self performSelector:@selector(fourLoadData) withObject:nil afterDelay:4.0];
        }
        
    } falure:^(NSError *error) {
        _isBack = YES;
        _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
        [_tableView reloadData];
        _IncompletePrompt.text = @"网络异常，请稍后再试";
        [_IncompletePrompt setHidden:NO];
        [self countdown];
        [_title setHidden:YES];
    }];
}
-(void)fourLoadData{
    if (!self.vin||[@"" isEqualToString:self.vin]||
        !self.userid||[@"" isEqualToString:self.userid]) {
        RLLog(@"没有vin或者没有用户id");
        return;
    }
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.vin?:@"" forKey:@"vin"];
    [param setValue:self.userid?:@"" forKey:@"aid"];
    [param setValue:@"runlin" forKey:@"datafrom"];
    [ReturnCarModel getCheckCarCode:param success:^(BOOL success, NSArray *result, NSString *message, NSDictionary *location) {
        if (location) {
            _location = [NSDictionary dictionaryWithDictionary:location];
        }
        if (success == YES) {
            _isBack = NO;
            _dataList = [NSMutableArray arrayWithArray:result];
            [_tableView reloadData];
            for (NSDictionary *dic in _dataList) {
                if ([[dic jk_stringForKey:@"state"]isEqualToString:@"1"]) {
                    [_IncompletePrompt setHidden:NO];
                    [self reckonCostFinishOrder];
                    _isBack = YES;
                }
            }
            if (_isBack == YES) {
                [self countdown];
            }else{
                [_backBtn setTitle:@"去支付" forState:UIControlStateNormal];
                [self reckonCostFinishOrder];
//                [self performSelector:@selector(backTouched:) withObject:nil afterDelay:1.0];
            
            }
        }else{
            _isBack = YES;
            _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
            [_tableView reloadData];
            //            [JKAlert showMessage:message];
            _IncompletePrompt.text = @"网络异常，请稍后再试";
            [_IncompletePrompt setHidden:NO];
            [self countdown];
            [_backBtn setHidden:NO];
            [_title setHidden:YES];
        }
    } falure:^(NSError *error) {
        _isBack = YES;
        _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
        [_tableView reloadData];
        _IncompletePrompt.text = @"网络异常，请稍后再试";
        [_IncompletePrompt setHidden:NO];
        [_backBtn setHidden:NO];
        [self countdown];
        [_title setHidden:YES];
        
    }];
}
#pragma mark -
#pragma -mark TableView Delegate

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"RLReturnCarCell";
    [tableView registerNib:[UINib nibWithNibName:@"RLReturnCarCell" bundle:[NSBundle RLResourceBundle]] forCellReuseIdentifier:CellIdentifier];
    RLReturnCarCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    NSDictionary *item = [_dataList jk_dictionaryWithIndex:indexPath.row];
    [cell configCell:item];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
    
}

- (void)countdown{
    [_backBtn setHidden:NO];
    _secondsCountDown = 5;//倒计时秒数
    __weak typeof(self) weakSelf = self;
    _countDownTimer = [NSTimer  ub_scheduledTimerWithTimeInterval:1.0 block:^{
        [weakSelf countDownAction];
        
    } repeats:YES];
    
    [[NSRunLoop currentRunLoop]addTimer:_countDownTimer forMode:NSRunLoopCommonModes];
    //启动倒计时后会每秒钟调用一次方法 countDownAction
    
    [_backBtn setTitle:[NSString stringWithFormat:@"(%ld)秒返回",_secondsCountDown] forState:UIControlStateNormal];
}

-(void) countDownAction{
    //倒计时-1
    _secondsCountDown--;
    //修改倒计时标签现实内容
   [_backBtn setTitle:[NSString stringWithFormat:@"(%ld)秒返回",_secondsCountDown] forState:UIControlStateNormal];
    //当倒计时到0时，做需要的操作，比如验证码过期不能提交
    if(_secondsCountDown==0){
        [_countDownTimer invalidate];
        [self backTouched:nil];
    }
}
//确认还车
- (IBAction)confirmCarTouched:(id)sender {
    if (!self.vin||[@"" isEqualToString:self.vin]||
        !self.userid||[@"" isEqualToString:self.userid]) {
        RLLog(@"没有vin或者没有用户id");
        return;
    }
    if (_lastClickTime&&[[NSDate date] timeIntervalSinceDate:_lastClickTime]<3) {
        RLLog(@"1111111%f",[[NSDate date] timeIntervalSinceDate:_lastClickTime]);
        _lastClickTime = [NSDate date];
        [RDToast showWithText:@"您的操作过于频繁，请稍后再试"];
        return;
    }
    _lastClickTime = [NSDate date];

    if ([[RGBleController shareController]connectingStatus] == RGBleStatusDisConnected) {//未连接
        _returnCarModel = nil;
        //如果未连接 尝试连接一次蓝牙
        if(self.reconnectBluetooth!=NULL){
            self.reconnectBluetooth();
        }
        [LogWriter writeLog:@"RLReturnCarVC"
                     detail:@"蓝牙未连接尝试连接"
                   inParams:nil outParams:nil];
    }
    
    if ([[RGBleController shareController]connectingStatus]==RGBleStatusConnected) {//已连接
        [LogWriter writeLog:@"RLReturnCarVC"
                     detail:@"蓝牙已连接尝试蓝牙还车"
                   inParams:nil outParams:nil];
        [self RGBleReturnCar];//蓝牙查询车辆状态
       
    }else{
        [LogWriter writeLog:@"RLReturnCarVC"
                     detail:@"蓝牙未连接尝试网络还车"
                   inParams:nil outParams:nil];
        [self checkDot:NO];
    }

}
//取消
- (IBAction)cancelTouched:(id)sender {
    [LogWriter writeLog:@"点击取消"
                 detail:@"不需要跳支付页1"
               inParams:@{@"vin":self.vin?:@"",@"userid":self.userid?:@"",@"_isorder":@(_isorder)} outParams:_location];
    
    if (self.jumpThePayment) {
        self.jumpThePayment(NO,_location?:@{},NO);
    }
    
    
    [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
        
    }];
}
+(NSArray *)getCheckCarCode:(NSString *)type{
    NSMutableArray *array = [NSMutableArray array];
    //已在可还区域
    NSMutableDictionary *dic5 = [[NSMutableDictionary alloc] init];
    [dic5 setValue:@"已在可还区域" forKey:@"name"];
    [dic5 setValue:type forKey:@"state"];
    [array addObject:dic5];
    //熄火
    NSMutableDictionary *dic1 = [[NSMutableDictionary alloc] init];
    [dic1 setValue:@"车辆已熄火" forKey:@"name"];
    [dic1 setValue:type forKey:@"state"];
    [array addObject:dic1];
    //车门
    NSMutableDictionary *dic2 = [[NSMutableDictionary alloc] init];
    [dic2 setValue:@"车门已锁" forKey:@"name"];
    [dic2 setValue:type forKey:@"state"];
    [array addObject:dic2];
    
    //车灯
    NSMutableDictionary *dic3 = [[NSMutableDictionary alloc] init];
    [dic3 setValue:@"车灯已经关闭" forKey:@"name"];
    [dic3 setValue:type forKey:@"state"];
    [array addObject:dic3];
    
    //车窗
    NSMutableDictionary *dic4 = [[NSMutableDictionary alloc] init];
    [dic4 setValue:@"车窗已经关闭" forKey:@"name"];
    [dic4 setValue:type forKey:@"state"];
    [array addObject:dic4];
    
    //车窗
    NSMutableDictionary *dic7 = [[NSMutableDictionary alloc] init];
    [dic7 setValue:@"费用计算" forKey:@"name"];
    [dic7 setValue:type forKey:@"state"];
    [array addObject:dic7];
    //    //蓝牙控车关闭
    //    NSMutableDictionary *dic6 = [[NSMutableDictionary alloc] init];
    //    [dic6 setValue:@"蓝牙控车关闭" forKey:@"name"];
    //    [dic6 setValue:type forKey:@"state"];
    //    [array addObject:dic6];
    return array;
}
//网络还车
-(void)netReturnCar{
    
    __weak typeof(self) weakSelf = self;
    _dataList = [NSMutableArray arrayWithArray:[ReturnCarModel getCheckCarCode:@"2"]];
    [_tableView reloadData];
    [_IncompletePrompt setHidden:YES];
    
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.vin?:@"" forKey:@"vin"];
    [param setValue:self.userid?:@"" forKey:@"aid"];
    [param setValue:self.orderNumber?:@"" forKey:@"orderNumber"];
    [ReturnCarModel checkCar:param success:^(id responseObject,BOOL success, NSString *message,BOOL isOrder) {
     
        
        [LogWriter writeLog:@"网络还车"
                     detail:@"网络返回成功"
                   inParams:param outParams:responseObject];
        
        if (success) {
            if (isOrder) {
                _isBack = YES;
                _isorder = YES;
                [RLInclude terminationControlCar];
                [self countdown];
                
            }else{
            dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0/*延迟执行时间*/
                                                                                   * NSEC_PER_SEC));
            dispatch_after(delayTime, dispatch_get_main_queue(), ^{
                [weakSelf loadData];
            });
            }
        }else{
            [JKAlert showMessage:message];
            [self countdown];
        }
    } falure:^(NSError *error) {
        [_IncompletePrompt setHidden:NO];
        _IncompletePrompt.text = @"网络异常，请稍后再试";
        //        dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0/*延迟执行时间*/
        //                                                                               * NSEC_PER_SEC));
        //        dispatch_after(delayTime, dispatch_get_main_queue(), ^{
        //            _dataList = [NSMutableArray arrayWithArray:[RLReturnCarViewController getCheckCarCode:@"1"]];
        //            [_tableView reloadData];
        //        });
        [LogWriter writeLog:@"网络还车"
                     detail:@"网络返回error"
                   inParams:nil outParams:@{@"error":error.debugDescription?:@""}];
        [self countdown];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
