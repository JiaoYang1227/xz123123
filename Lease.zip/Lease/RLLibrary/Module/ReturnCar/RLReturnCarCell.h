//
//  RLReturnCarCell.h
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RLReturnCarCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIButton *icon;
-(void)configCell:(NSDictionary *)dic;
@end
