//
//  RLReturnView.m
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLReturnCarView.h"
#import "UIViewController+JKPopup.h"
#import "RLInclude.h"
@implementation RLReturnCarView{
    UIButton * _submit;
}
- (instancetype)initWithFrame:(CGRect)frame vin:(NSString *)vin userid:(NSString *)userid isJumpThePayment:(ISJumpThePayment)isJumpThePayment{
    self = [super initWithFrame:frame];
    if (self) {
        [self setVin:vin userid:userid isJumpThePayment:self.jumpThePayment];
        [self buidView];
    }
    return self;
}

-(void)setVin:(NSString *)vin userid:(NSString *)userid isJumpThePayment:(ISJumpThePayment)isJumpThePayment{
    self.vin = vin;
    self.userid = userid;
    self.jumpThePayment = [isJumpThePayment copy];
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self buidView];
}
-(void)buidView{
    _submit = [[UIButton alloc]init];
    [_submit setTitle:@"还车" forState: UIControlStateNormal];
    [_submit addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    _submit.layer.cornerRadius = _submit.frame.size.height/2;
    _submit.backgroundColor = [UIColor colorWithRed:26.0/255.0 green:132.0/255.0 blue:210.0/255.0 alpha:1];
    [self addSubview:_submit];
    [self changeFrame];
}

-(void)action:(UIButton *)sender{
    
    
    
//    [[UIViewController topShowViewController]
//     presentJKPopupViewController:[RLInclude getRLReturnCarViewControllerWithVin:self.vin userid:self.userid orderNumber:@""  isJumpThePayment:^(BOOL jump,NSDictionary *location) {
//        if (self.jumpThePayment) {
//            self.jumpThePayment(jump,location);
//        }
//    }]];
}

-(void)changeFrame{
    float width = 0;
    float height = 0;
    float xSpacing = 0;
    float ySpacing = 0;
    
    width = self.frame.size.width*174.0/181.0;
    height = self.frame.size.height*23.0/40.0;
    xSpacing = (self.frame.size.width - width)/2.0;
    ySpacing = (self.frame.size.height - height)/2.0;
    
    _submit.layer.cornerRadius = _submit.frame.size.height/2;
    _submit.backgroundColor = [UIColor colorWithRed:26.0/255.0 green:132.0/255.0 blue:210.0/255.0 alpha:1];
    
    [_submit setFrame:CGRectMake(xSpacing, ySpacing, width, height)];
}
-(void)layoutSubviews{
    
    [self changeFrame];
    
}

/**
 *  返回当前视图的控制器
 */
- (UIViewController *)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder *nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController *)nextResponder;
        }
    }
    return nil;
}


@end
