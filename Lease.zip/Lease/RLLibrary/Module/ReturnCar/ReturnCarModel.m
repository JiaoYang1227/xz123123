//
//  ReturnCarModel.m
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "ReturnCarModel.h"
#import "RLMicro.h"
@implementation ReturnCarModel
+ (void)drivingData:(NSDictionary *)param
                          success:(void(^)(NSArray *result,NSDictionary *location,NSString *message))success
                           falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_DRIVING_DATA parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
//            "trunkLock": "0",//后备箱锁 0:关闭,1:打开,>1获取失败
//            "rightBackDoor": "1",//右后门锁 0:解锁,1:上锁,>1获取失败
//            "surplusMileage": "5000",//剩余里程（米）
//            "latitude": "43.8983376071",//纬度
//            "rightFrontDoor": "1",//右前门锁 0:解锁,1:上锁,>1获取失败
//            "speed": "60",//速度 公里/小时
//            "oil": "40",//油位 升
//            "leftBackDoor": "1",//左后门锁 0:解锁,1:上锁,>1获取失败
//            "allMileage": "10000",//总里程（米）
//            "time": "2018-02-13 11:11:11",//时间
//            "leftFrontDoor": "1",//左前门锁 0:解锁,1:上锁,>1获取失败
//            "longitude": "125.313642427",//经度
//            "engineSpeed": "1200"//发动机转速 用于判断是否熄火
//            "farLight": "0"//灯状态(远光灯)0:关闭,1:打开,>1获取失败
//            "nearLight": "0"//灯状态(近光灯)0:关闭,1:打开,>1获取失败
//            "wideLight": "0"//灯状态(示宽灯)0:关闭,1:打开,>1获取失败
            NSString *str = [responseObject jk_stringForKey:@"result"];
//            NSDictionary *result = [responseObject jk_dictionaryForKey:@"result"];
            
            NSDictionary *result =[ReturnCarModel dictionaryWithJsonString:str];
            
            NSMutableDictionary *location = [[NSMutableDictionary alloc]init];
            [location setValue:[result jk_stringForKey:@"latitude"] forKey:@"latitude"];
            [location setValue:[result jk_stringForKey:@"longitude"] forKey:@"longitude"];
//            NSMutableArray *array = [NSMutableArray array];
//            //熄火
//            if ([[result jk_stringForKey:@"engineSpeed"] intValue]==0) {
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车辆已熄火" forKey:@"name"];
//                [dic setValue:@"0" forKey:@"state"];
//                [array addObject:dic];
//            }else{
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车辆已熄火" forKey:@"name"];
//                [dic setValue:@"1" forKey:@"state"];
//                [array addObject:dic];
//            }
//
//            //车门
//            if ([[result jk_stringForKey:@"trunkLock"]intValue]==0
//                &&[[result jk_stringForKey:@"rightBackDoor"]intValue]==1
//                &&[[result jk_stringForKey:@"rightFrontDoor"]intValue]==1
//                &&[[result jk_stringForKey:@"leftBackDoor"]intValue]==1
//                &&[[result jk_stringForKey:@"leftFrontDoor"]intValue]==1) {
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车门已经关闭" forKey:@"name"];
//                [dic setValue:@"0" forKey:@"state"];
//                [array addObject:dic];
//            }else{
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车门已经关闭" forKey:@"name"];
//                [dic setValue:@"1" forKey:@"state"];
//                [array addObject:dic];
//            }
//
//            //车灯
//            if ([[result jk_stringForKey:@"farLight"]intValue] == 0
//                &&[[result jk_stringForKey:@"nearLight"]intValue] == 0
//                &&[[result jk_stringForKey:@"wideLight"]intValue]==0) {
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车灯已经关闭" forKey:@"name"];
//                [dic setValue:@"0" forKey:@"state"];
//                [array addObject:dic];
//            }else{
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车灯已经关闭" forKey:@"name"];
//                [dic setValue:@"1" forKey:@"state"];
//                [array addObject:dic];
//            }
//           //车窗
//            if ([[result jk_stringForKey:@"leftFrontWindow"]intValue] == 0
//                &&[[result jk_stringForKey:@"rightFrontWindow"]intValue] == 0
//                &&[[result jk_stringForKey:@"leftBackWindow"]intValue] == 0
//                &&[[result jk_stringForKey:@"rightBackWindow"]intValue] == 0) {
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车窗已经关闭" forKey:@"name"];
//                [dic setValue:@"0" forKey:@"state"];
//                [array addObject:dic];
//            }else{
//                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//                [dic setValue:@"车窗已经关闭" forKey:@"name"];
//                [dic setValue:@"1" forKey:@"state"];
//                [array addObject:dic];
//            }
            success(result,location,[responseObject jk_stringForKey:@"message"]);
        }else{
            success(nil,nil,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
+ (void)checkCar:(NSDictionary *)param
            success:(void(^)(id responseObject,BOOL success,NSString *message,BOOL isOrder))success
             falure:(void(^)(NSError *error))falure
{
    NSMutableDictionary *paramdic = [[NSMutableDictionary alloc]initWithDictionary:param];
    [paramdic setObject:VERSION forKey:@"version"];
    [RLAPIManager SafeGET:URI_INTERFACES_CHECKCAR parameters:paramdic success:^(NSURLSessionTask *operation, id responseObject) {
        
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            success(responseObject,YES,[responseObject jk_stringForKey:@"message"],NO);
        }else if([@"order"isEqualToString:[responseObject jk_stringForKey:@"status"]]){
        success(responseObject,YES,[responseObject jk_stringForKey:@"message"],YES);
        } else{
            success(responseObject,NO,[responseObject jk_stringForKey:@"message"],NO);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
//获取还车结果接口
+ (void)getCheckCarCode:(NSDictionary *)param
         success:(void(^)(BOOL success,NSArray *result,NSString *message,NSDictionary *location))success
          falure:(void(^)(NSError *error))falure
{
    NSMutableDictionary *paramdic = [[NSMutableDictionary alloc]initWithDictionary:param];
    [paramdic setObject:VERSION forKey:@"version"];
    [RLAPIManager SafeGET:URI_INTERFACES_GET_CHECKCAR_CODE parameters:paramdic success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            NSMutableDictionary *location = [[NSMutableDictionary alloc]init];
            [location setValue:[responseObject jk_stringForKey:@"latitude"] forKey:@"latitude"];
            [location setValue:[responseObject jk_stringForKey:@"longitude"] forKey:@"longitude"];
            BOOL isSuccess = NO;
            if ([responseObject jk_hasKey:@"resultCode"]) {
                NSMutableArray *array = [NSMutableArray array];
                if ([@"1" isEqualToString: [responseObject jk_stringForKey:@"resultCode"]]) {//可以还车
                    isSuccess = YES;
                    [array setArray:[ReturnCarModel getCheckCarCode:@"0"]];
                }else{//有失败项处理todo
                    NSArray *noPassCodeList = [responseObject jk_arrayForKey:@"noPassCode"];
                    if (noPassCodeList.count>0) {
                        isSuccess = YES;
                        [array setArray:[ReturnCarModel getArray:noPassCodeList]];
                    }else{
                        isSuccess = NO;
                        array = nil;
                    }
                }
                success(isSuccess,array,[responseObject jk_stringForKey:@"message"],location);
            }
        }else{
            success(NO,nil,[responseObject jk_stringForKey:@"message"],nil);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
//查询GPS坐标是否在场站

+ (void)checkDot:(NSDictionary *)param
         success:(void(^)(id responseObject,BOOL success,double returnCost,NSString *message))success
          falure:(void(^)(NSError *error))falure{
    [RLAPIManager SafeGET:URI_INTERFACES_GET_CHECK_DOT parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            success(responseObject,YES,[responseObject jk_doubleForKey:@"returnCost"],[responseObject jk_stringForKey:@"message"]);
        }else{
            success(responseObject,NO,[responseObject jk_doubleForKey:@"returnCost"],[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
//价格结束订单

+ (void)reckonCostFinishOrder:(NSDictionary *)param
         success:(void(^)(BOOL success,NSString *message))success
          falure:(void(^)(NSError *error))falure{
    [RLAPIManager SafeGET:URI_INTERFACES_RECHON_COSRFINSHORDER parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        
        if ([@"0"isEqualToString:[responseObject jk_stringForKey:@"code"]]) {//成功
            success(YES,[responseObject jk_stringForKey:@"msg"]);
        }else{
            success(NO,[responseObject jk_stringForKey:@"msg"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}


//获取还车结果接口
//isOrder 直接跳转支付
+ (void)checkCarBluetooth:(NSDictionary *)param
                success:(void(^)(id responseObject,BOOL success,NSArray *result,NSString *message,NSDictionary *location,BOOL isOrder))success
                 falure:(void(^)(NSError *error))falure
{
    NSMutableDictionary *paramdic = [[NSMutableDictionary alloc]initWithDictionary:param];
    [RLAPIManager SafePOST:URI_INTERFACES_CHECKCAR_BLUETOOTH parameters:paramdic success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            NSMutableDictionary *location = [[NSMutableDictionary alloc]init];
            [location setValue:[responseObject jk_stringForKey:@"latitude"] forKey:@"latitude"];
            [location setValue:[responseObject jk_stringForKey:@"longitude"] forKey:@"longitude"];
            BOOL isSuccess = NO;
            if ([responseObject jk_hasKey:@"resultCode"]) {
                NSMutableArray *array = [NSMutableArray array];
                if ([@"1" isEqualToString: [responseObject jk_stringForKey:@"resultCode"]]) {//可以还车
                    isSuccess = YES;
                    [array setArray:[ReturnCarModel getCheckCarCode:@"0"]];
                    
                }else{//有失败项处理todo
                    NSArray *noPassCodeList = [responseObject jk_arrayForKey:@"noPassCode"];
                    if (noPassCodeList.count>0) {
                        isSuccess = YES;
                        [array setArray:[ReturnCarModel getArray:noPassCodeList]];
                    }else{
                        isSuccess = NO;
                        array = nil;
                    }
                }
                success(responseObject,isSuccess,array,[responseObject jk_stringForKey:@"message"],location,NO);
            }
        }else if ([@"order"isEqualToString:[responseObject jk_stringForKey:@"status"]]){
            NSMutableDictionary *location = [[NSMutableDictionary alloc]init];
            [location setValue:[responseObject jk_stringForKey:@"latitude"] forKey:@"latitude"];
            [location setValue:[responseObject jk_stringForKey:@"longitude"] forKey:@"longitude"];
            NSMutableArray *array = [NSMutableArray array];
            [array setArray:[ReturnCarModel getCheckCarCode:@"0"]];
             success(responseObject,YES,array,[responseObject jk_stringForKey:@"message"],location,YES);
        } else{
            success(responseObject,NO,nil,[responseObject jk_stringForKey:@"message"],nil,NO);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}

+ (NSArray *)getArray:(NSArray *)noPassCodeList{
    NSMutableArray *array = [NSMutableArray array];
    //已在可还区域
    NSMutableDictionary *dic5 = [[NSMutableDictionary alloc] init];
    [dic5 setValue:@"已在可还区域" forKey:@"name"];
    if ([noPassCodeList containsObject: @"05"]) {
        [dic5 setValue:@"1" forKey:@"state"];
    }else{
        [dic5 setValue:@"0" forKey:@"state"];
    }
    [array addObject:dic5];
    //熄火
    NSMutableDictionary *dic1 = [[NSMutableDictionary alloc] init];
    [dic1 setValue:@"车辆已熄火" forKey:@"name"];
    if ([noPassCodeList containsObject: @"03"]) {
        [dic1 setValue:@"1" forKey:@"state"];
    }else{
        [dic1 setValue:@"0" forKey:@"state"];
    }
    [array addObject:dic1];
    //车门
    NSMutableDictionary *dic2 = [[NSMutableDictionary alloc] init];
    [dic2 setValue:@"车门已锁" forKey:@"name"];
    if ([noPassCodeList containsObject: @"02"]) {
        [dic2 setValue:@"1" forKey:@"state"];
    }else{
        [dic2 setValue:@"0" forKey:@"state"];
    }
    [array addObject:dic2];
    
    //车灯
    NSMutableDictionary *dic3 = [[NSMutableDictionary alloc] init];
    [dic3 setValue:@"车灯已经关闭" forKey:@"name"];
    if ([noPassCodeList containsObject: @"01"]) {
        [dic3 setValue:@"1" forKey:@"state"];
    }else{
        [dic3 setValue:@"0" forKey:@"state"];
    }
    [array addObject:dic3];
    
    //车窗
    NSMutableDictionary *dic4 = [[NSMutableDictionary alloc] init];
    [dic4 setValue:@"车窗已经关闭" forKey:@"name"];
    if ([noPassCodeList containsObject: @"04"]) {
        [dic4 setValue:@"1" forKey:@"state"];
    }else{
        [dic4 setValue:@"0" forKey:@"state"];
    }
    [array addObject:dic4];
    
    //车窗
    NSMutableDictionary *dic7 = [[NSMutableDictionary alloc] init];
    [dic7 setValue:@"费用计算" forKey:@"name"];
    if ([noPassCodeList containsObject: @"07"]) {
        [dic7 setValue:@"1" forKey:@"state"];
    }else{
        [dic7 setValue:@"0" forKey:@"state"];
    }
    [array addObject:dic7];
//    //蓝牙控车关闭
//    NSMutableDictionary *dic6 = [[NSMutableDictionary alloc] init];
//    [dic6 setValue:@"蓝牙控车关闭" forKey:@"name"];
//    [dic6 setValue:@"1" forKey:@"state"];
//    [array addObject:dic6];
    return array;
}

+(NSArray *)getCheckCarCode:(NSString *)type{
    NSMutableArray *array = [NSMutableArray array];
    //已在可还区域
    NSMutableDictionary *dic5 = [[NSMutableDictionary alloc] init];
    [dic5 setValue:@"已在可还区域" forKey:@"name"];
    [dic5 setValue:type forKey:@"state"];
    [array addObject:dic5];
    //熄火
    NSMutableDictionary *dic1 = [[NSMutableDictionary alloc] init];
    [dic1 setValue:@"车辆已熄火" forKey:@"name"];
    [dic1 setValue:type forKey:@"state"];
    [array addObject:dic1];
    //车门
    NSMutableDictionary *dic2 = [[NSMutableDictionary alloc] init];
    [dic2 setValue:@"车门已锁" forKey:@"name"];
    [dic2 setValue:type forKey:@"state"];
    [array addObject:dic2];
    
    //车灯
    NSMutableDictionary *dic3 = [[NSMutableDictionary alloc] init];
    [dic3 setValue:@"车灯已经关闭" forKey:@"name"];
    [dic3 setValue:type forKey:@"state"];
    [array addObject:dic3];
    
    //车窗
    NSMutableDictionary *dic4 = [[NSMutableDictionary alloc] init];
    [dic4 setValue:@"车窗已经关闭" forKey:@"name"];
    [dic4 setValue:type forKey:@"state"];
    [array addObject:dic4];
    
    //费用计算
    NSMutableDictionary *dic7 = [[NSMutableDictionary alloc] init];
    [dic7 setValue:@"费用计算" forKey:@"name"];
    [dic7 setValue:type forKey:@"state"];
    [array addObject:dic7];
//    //蓝牙控车关闭
//    NSMutableDictionary *dic6 = [[NSMutableDictionary alloc] init];
//    [dic6 setValue:@"蓝牙控车关闭" forKey:@"name"];
//    [dic6 setValue:type forKey:@"state"];
//    [array addObject:dic6];
    return array;
}
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        RLLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}
+(ReturnCarModel *)returnCarModelCarStatus:(RoiCarStatus *)roiCarStatus{
    if (roiCarStatus == nil) {
        return nil;
    }
    ReturnCarModel *model= [[ReturnCarModel alloc]init];
    model.version = VERSION;
    NSDateFormatter*dateFormatter=[[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    model.time = [dateFormatter stringFromDate:[NSDate new]];
    
    [model setLongitude:[NSString stringWithFormat:@"%f",roiCarStatus.lng]]; //经度
    [model setLatitude:[NSString stringWithFormat:@"%f",roiCarStatus.lat]]; //纬度
    [model setAllMileage:roiCarStatus.totalMileage]; //总里程 米
//    [model setSpeed:roiCarStatus.speed]; //时速 公里/小时
    [model setOil:roiCarStatus.oil]; //油位 升
    [model setSurplusElectric:roiCarStatus.remainingBattery]; ////电动车高压电池剩余电量
    [model setSurplusMileage:roiCarStatus.cruisingRange]; ////剩余里程

//    [model setEngineSpeed:roiCarStatus.engineSpeed]; // //发动机转速
    [model setEngineDoor:[NSString stringWithFormat:@"%d",roiCarStatus.hood]];  //发动机舱盖
    [model setFarlight:[NSString stringWithFormat:@"%d",roiCarStatus.highbeam]];//远光灯
    model.nearlight = [NSString stringWithFormat:@"%d",roiCarStatus.lowbeam];//近光灯
    model.widelight = [NSString stringWithFormat:@"%d",roiCarStatus.widthlamp]; //示宽灯
    model.trunkLock=[NSString stringWithFormat:@"%d",roiCarStatus.trunk];  //后备箱
    model.leftFrontDoor = [NSString stringWithFormat:@"%d",roiCarStatus.doorLockfl];  //左前门门锁
    model.leftBackDoor = [NSString stringWithFormat:@"%d",roiCarStatus.doorLockbl]; // 左后门门锁
    model.rightFrontDoor = [NSString stringWithFormat:@"%d",roiCarStatus.doorLockfr]; //右前门门锁
    
    model.rightBackDoor =[NSString stringWithFormat:@"%d",roiCarStatus.doorLockbr]; //右后门门锁
    model.leftFrontWindow = [NSString stringWithFormat:@"%d",roiCarStatus.windowfl]; //左前窗
    model.leftBackWindow = [NSString stringWithFormat:@"%d",roiCarStatus.windowbr]; //左后窗
    model.rightFrontWindow = [NSString stringWithFormat:@"%d",roiCarStatus.windowfr]; //右前窗
    model.rightBackWindow = [NSString stringWithFormat:@"%d",roiCarStatus.windowbr];//右后窗
    model.skyWindow = [NSString stringWithFormat:@"%d",roiCarStatus.windowtop];//天窗
//    model.waterTemperature = roiCarStatus.coolantTemperature;//水温
//    model.maintainMileage = roiCarStatus.maintenanceMileage;//保养里程
//    model.maintainDays = roiCarStatus.maintenanceDays;  //保养天数
//    model.carOuterTemperature = roiCarStatus.outsideTemperature;//车外温度
    model.carVoltage = roiCarStatus.batteryVoltage;  //车辆蓄电池电压
//    model.engineOilLevel = roiCarStatus.engineOilLevel; //机油液位（毫米）
//    model.engineOilLower = roiCarStatus.engineOilLowerLimit; //机油下限值（毫米）
//    model.handbrakeState = [NSString stringWithFormat:@"%d",roiCarStatus.handbrake]; //手刹状态

    model.leftBackDoorState = [NSString stringWithFormat:@"%d",roiCarStatus.doorbl]; //门状态（左后门）
    model.rightFrontDoorState = [NSString stringWithFormat:@"%d",roiCarStatus.doorfr]; //门状态（右前门）
    model.rightBackDoorState = [NSString stringWithFormat:@"%d",roiCarStatus.doorbr]; //门状态（右后门）
    model.powerUp = [NSString stringWithFormat:@"%d",roiCarStatus.powerStatus]; // 上电状态
    model.leftFrontDoorState =  [NSString stringWithFormat:@"%d",roiCarStatus.doorfl];//左前门
    model.boot = [NSString stringWithFormat:@"%d",roiCarStatus.boot];
    return model;
}
//jia
+(ReturnCarModel *)returnCarModel{

    ReturnCarModel *model= [[ReturnCarModel alloc]init];
    model.version = VERSION;
    NSDateFormatter*dateFormatter=[[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    model.time = [dateFormatter stringFromDate:[NSDate new]];
    
    [model setLongitude:@"125.26633"]; //经度
    [model setLatitude:@"43.86945"]; //纬度
    [model setAllMileage:@"3"]; //总里程 米
    [model setSpeed:@"4"]; //时速 公里/小时
    [model setOil:@"5"]; //油位 升
    [model setSurplusElectric:@"6"]; //电动车高压电池剩余电量
    [model setEngineSpeed:@"0"]; // //发动机转速
    [model setEngineDoor:@"0"];  //发动机舱盖
    [model setFarlight:@"0"];//远光灯
    model.nearlight = @"0";//近光灯
    model.widelight = @"0"; //示宽灯
    model.trunkLock=@"0";  //后备箱
    model.leftFrontDoor = @"1";  //左前门门锁
    model.leftBackDoor = @"1"; // 左后门门锁
    model.rightFrontDoor = @"1"; //右前门门锁
    model.rightBackDoor =@"1"; //右后门门锁
    model.leftFrontWindow = @"0"; //左前窗
    model.leftBackWindow = @"0"; //左后窗
    model.rightFrontWindow = @"0"; //右前窗
    model.rightBackWindow = @"0";//右后窗
    model.skyWindow = @"0";//天窗
    model.waterTemperature = @"23";//水温
    model.maintainMileage = @"24";//保养里程
    model.maintainDays = @"9";  //保养天数
    model.carOuterTemperature = @"0";//车外温度
    model.carVoltage = @"0";  //车辆蓄电池电压
    model.engineOilLevel = @"0"; //机油液位（毫米）
    model.engineOilLower = @"0"; //机油下限值（毫米）
    model.handbrakeState = @"0"; //手刹状态
    
    model.leftBackDoorState = @"0"; //门状态（左后门）
    model.rightFrontDoorState = @"0"; //门状态（右前门）
    model.rightBackDoorState = @"0"; //门状态（右后门）
    model.powerUp = @"34"; // 上电状态
    model.leftFrontDoorState = @"0";
    return model;
}
@end
