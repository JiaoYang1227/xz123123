//
//  RLCouponListViewController.m
//  RLLibrary
//
//  Created by sun on 2018/4/24.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLCouponListViewController.h"
#import "RLCouponListCell.h"
#import "RLInclude.h"
#import "RLCouponModel.h"
#import <MJRefresh/MJRefresh.h>
#import "JKAlert.h"
#import "CBTracking.h"
#import "ScrollMenuView.h"
#import "RLMicro.h"
@interface RLCouponListViewController (){
    
    __weak IBOutlet UITableView *_tableView;
    NSMutableArray *_items;
    NSInteger _pageNum;
    NSInteger _maxCount;
    NSString *_couponUseStatus;
}
@property (weak, nonatomic) IBOutlet ScrollMenuView *menuView;

@end

@implementation RLCouponListViewController
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"AllCoupon"];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"AllCoupon"];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self addRefreshView];
    
    
    self.menuView.items = @[@{@"key":@"0",@"value":@"未使用"},@{@"key":@"1",@"value":@"已使用"}];
    self.menuView.itemWidth =  [ UIScreen mainScreen ].bounds.size.width/2;
//    self.menuView.ishiddenRedLine = YES;
//    self.menuView.ishiddenLine = YES;
    _menuView.itemNormalColor = [UIColor colorWithRed:131 /255.0 green:131 /255.0 blue:131 /255.0 alpha:1.0];
    self.menuView.itemSelectColor = [UIColor colorWithRed:29.0/255.0 green:139.0/255.0 blue:241.0/255.0 alpha:1.000];
    [self.menuView titleForMenuItem:^NSString *(NSInteger index, id item) {
        return [item objectForKey:@"value"];
    }];
    [self.menuView didClickMenuItem:^(NSInteger index, UIButton *button, id item) {
        _couponUseStatus = [NSString stringWithFormat:@"%@",[item objectForKey:@"key"]];
        _pageNum = 1;
        _maxCount = 0;
        [self loadData:_pageNum loadData:NO];
    }];
    
    
}
-(void)loadData:(NSInteger)page loadData:(BOOL)loadData{
    
    if (!self.aid||[@""isEqualToString:self.aid]) {
        RLLog(@"没有userid");
        return;
    }
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    [param setValue:self.aid?:@"" forKey:@"aid"];
    [param setValue:[NSNumber numberWithInteger:_pageNum] forKey:@"pageon"];
    [param setValue:@"20" forKey:@"pageonCount"];
    [param setValue:_couponUseStatus?:@"" forKey:@"couponUseStatus"];
    [RLCouponModel selectCouponList:param success:^(NSUInteger count,NSArray *list, NSString *msg) {
        _maxCount = count;
        if (!_items) {
            _items = [NSMutableArray array];
        }
        if (page==1) {
            [_items removeAllObjects];
            [_tableView reloadData];
        }
        [_tableView.mj_header endRefreshing];
        if (list) {
            if (loadData) {
                if (list.count == 0) {
                    [_tableView.mj_footer endRefreshingWithNoMoreData];
                }else{
                    [_tableView.mj_footer endRefreshing];
                }
            }else{
                if (list.count == 0) {
                }
                [_tableView.mj_footer resetNoMoreData];
            }
            [_items addObjectsFromArray:list];
        }else{
            [JKAlert showMessage:msg];
        }
        
        [_tableView reloadData];
    } falure:^(NSError *error) {
        if (loadData) {
            [_tableView.mj_footer endRefreshing];
        }
        [_tableView.mj_header endRefreshing];
    }];
}

#pragma mark ---------------UITableView---------------
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 120*[UIScreen mainScreen].bounds.size.width/375;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _items.count;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"RLCouponListCell";
    [tableView registerNib:[UINib nibWithNibName:@"RLCouponListCell" bundle:[NSBundle RLResourceBundle]] forCellReuseIdentifier:CellIdentifier];
    RLCouponListCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    [cell configCell:[_items objectAtIndex:indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (void)addRefreshView{
    _tableView.mj_header.automaticallyChangeAlpha = YES;
    _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        _pageNum = 1;
        [self loadData:_pageNum loadData:NO];
    }];
    _tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [_tableView.mj_footer endRefreshingWithNoMoreData];
//        _pageNum ++;
//        if (_pageNum<_maxCount) {
//            [self loadData:_pageNum loadData:YES];
//        }else{
//            [_tableView.mj_footer endRefreshingWithNoMoreData];
//        }
    }];
}
- (IBAction)back:(id)sender {
    if(self.navigationController){
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
