//
//  RLAvailableCouponListViewController.m
//  RLLibrary
//
//  Created by sun on 2018/4/24.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLAvailableCouponListViewController.h"
#import "RLInclude.h"
#import "RLCouponCell.h"
#import "MJRefresh/MJRefresh.h"
#import "JKAlert.h"
#import "CBTracking.h"
#import "RLMicro.h"
@interface RLAvailableCouponListViewController (){
    __weak IBOutlet UITableView *_tableView;
    NSMutableArray *_items;
    NSInteger _pageNum;
    __weak IBOutlet UIButton *_notUsedBTN;
    NSInteger _maxCount;
}

@end

@implementation RLAvailableCouponListViewController
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"Coupon"];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"Coupon"];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _pageNum = 1;
    [self loadData:_pageNum loadData:NO];
    [self addRefreshView];
    
    _notUsedBTN.layer.cornerRadius = 5.0;
    _notUsedBTN.layer.masksToBounds = YES;
    _notUsedBTN.layer.borderWidth = 1.0;
    _notUsedBTN.layer.borderColor = [[UIColor colorWithRed:29.0/255.0 green:139.0/255.0 blue:241.0/255.0 alpha:1] CGColor];
    _maxCount = 0;
}
-(void)loadData:(NSInteger)page loadData:(BOOL)loadData{
    if (!self.aid||[@""isEqualToString:self.aid]||!self.starTime||[@""isEqualToString:self.starTime]||!self.price||[@""isEqualToString:self.price]) {
        RLLog(@"没有userid或没有starTime,或者没有price");
        return;
    }
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    [param setValue:self.starTime?:@"" forKey:@"starttime"];
    [param setValue:self.aid?:@"" forKey:@"aid"];
    [param setValue:[NSNumber numberWithInteger:_pageNum] forKey:@"pageon"];
    [param setValue:@"20" forKey:@"pageonCount"];
    [param setValue:self.price?:@"" forKey:@"price"];
    [RLCouponModel selectAvailableCouponList:param success:^(NSUInteger count,NSArray *list, NSString *msg) {
        _maxCount = count;
        if (!_items) {
            _items = [NSMutableArray array];
        }
        if (page==1) {
            [_items removeAllObjects];
            [_tableView reloadData];
        }
        [_tableView.mj_header endRefreshing];
        if (list) {
            if (loadData) {
                if (list.count == 0) {
                    [_tableView.mj_footer endRefreshingWithNoMoreData];
                }else{
                    [_tableView.mj_footer endRefreshing];
                }
            }else{
                if (list.count == 0) {
                }
                [_tableView.mj_footer resetNoMoreData];
            }
            [_items addObjectsFromArray:list];
        }else{
            [JKAlert showMessage:msg];
        }
        
        [_tableView reloadData];
    } falure:^(NSError *error) {
        if (loadData) {
            [_tableView.mj_footer endRefreshing];
        }
        [_tableView.mj_header endRefreshing];
    }];
}

#pragma mark ---------------UITableView---------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _items.count;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"RLCouponCell";
    [tableView registerNib:[UINib nibWithNibName:@"RLCouponCell" bundle:[NSBundle RLResourceBundle]] forCellReuseIdentifier:CellIdentifier];
    RLCouponCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    [cell configCell:[_items objectAtIndex:indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    RLCouponModel *model = [_items objectAtIndex:indexPath.row];
    RLLog(@"%@",model.ID);
    if (self.choosedCoupon) {
        self.choosedCoupon(YES,[model toDictionary]);
    }
    [self back:nil];
    
}

- (void)addRefreshView{
    _tableView.mj_header.automaticallyChangeAlpha = YES;
    _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        _pageNum = 1;
        [self loadData:_pageNum loadData:NO];
    }];
    _tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        _pageNum ++;
        if (_pageNum<_maxCount) {
            [self loadData:_pageNum loadData:YES];
        }else{
            [_tableView.mj_footer endRefreshingWithNoMoreData];
        }
        
    }];
}
- (IBAction)back:(id)sender {
    if(self.navigationController){
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
- (IBAction)notUseTouched:(id)sender {
    if (self.choosedCoupon) {
        self.choosedCoupon(NO,nil);
    }
    [self back:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
