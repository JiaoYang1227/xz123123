//
//  RLCouponCell.m
//  RLLibrary
//
//  Created by sun on 2018/4/24.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLCouponCell.h"
#import "RLInclude.h"
@implementation RLCouponCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)configCell:(RLCouponModel *)item{
    if ([@"1" isEqualToString:item.overtimeFlag]) {
        [self.passbyImage setHidden:NO];
    }else{
        [self.passbyImage setHidden:YES];
    }
    if ([@"0"isEqualToString: item.overtimeFlag]&&[@"0"isEqualToString:item.couponuseStatus]) {//未过期&&未使用
        [self.overtimeFlagImage setImage:[UIImage RLImageNamed:@"RL_coupon_car_gray"]];
        [self.viewBg setBackgroundColor:[UIColor colorWithRed:193.0/255.0 green:223.0/255.0 blue:247.0/255.0 alpha:1]];
        switch ([item.preferentialway integerValue]) {
            case 0://折扣
            {
                [self.preferentialwayBTN setImage:[UIImage RLImageNamed:@"RL_discount_icon"] forState:UIControlStateNormal];
                break;
            }
            case 1://满减
                [self.preferentialwayBTN setImage:[UIImage RLImageNamed:@"RL_fullReduction_icon"] forState:UIControlStateNormal];
                break;
            case 2://现金
                [self.preferentialwayBTN setImage:[UIImage RLImageNamed:@"RL_vouchers_icon"] forState:UIControlStateNormal];
                break;
            default:
                break;
        }
    }else{
        [self.overtimeFlagImage setImage:[UIImage RLImageNamed:@"RL_coupon_car"]];
        [self.viewBg setBackgroundColor:[UIColor colorWithRed:244.0/255.0 green:243.0/255.0 blue:243.0/255.0 alpha:1]];
        switch ([item.preferentialway integerValue]) {
            case 0://折扣
                [self.preferentialwayBTN setImage:[UIImage RLImageNamed:@"RL_discount_icon_gray"] forState:UIControlStateNormal];
                break;
            case 1://满减
                [self.preferentialwayBTN setImage:[UIImage RLImageNamed:@"RL_fullReduction_icon_gray"] forState:UIControlStateNormal];
                break;
            case 2://现金
                [self.preferentialwayBTN setImage:[UIImage RLImageNamed:@"RL_vouchers_icon_gray"] forState:UIControlStateNormal];
                break;
            default:
                break;
        }
    }
    switch ([item.preferentialway integerValue]) {
        case 0://折扣
        {
            self.preferentialpriceLB.text = [NSString stringWithFormat:@"%@折",item.preferentialprice?:@""];
            [self.fullcutpriceLB setHidden:YES];
            break;
        }
        case 1://满减
        {
            self.preferentialpriceLB.text = [NSString stringWithFormat:@"¥%@",item.preferentialprice?:@""];
            [self.fullcutpriceLB setHidden:NO];
            self.fullcutpriceLB.text = [NSString stringWithFormat:@"满%@元可用",item.fullcutprice?:@""];
            break;
        }
        case 2://现金
        {
            self.preferentialpriceLB.text = [NSString stringWithFormat:@"¥%@",item.preferentialprice?:@""];
            [self.fullcutpriceLB setHidden:YES];
            break;
        }
        default:
            break;
    }
    self.starttimeLB.text = [NSString stringWithFormat:@"有效期至:%@",item.starttime?:@""];
    self.endtimeLB.text = [NSString stringWithFormat:@"有效期至:%@",item.endtime?:@""];
    self.couponnameLB.text = item.couponname;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
