//
//  RLCouponModel.m
//  RLLibrary
//
//  Created by sun on 2018/4/24.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLCouponModel.h"

@implementation RLCouponModel
+(JSONKeyMapper*)keyMapper
{
    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{@"ID":@"id"}];
}
+ (void)selectCouponList:(NSDictionary *)param
                         success:(void(^)(NSUInteger count,NSArray *list, NSString *msg))success
                          falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_SELECTCOUPON_LIST parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            NSMutableArray *array = [NSMutableArray array];
            for (NSDictionary *dic in [responseObject jk_arrayForKey:@"result"]) {
                RLCouponModel *model = [RLCouponModel objectFromDictionary:dic];
                [array addObject:model];
            }
            success([responseObject jk_integerForKey:@"pageNum"],array,nil);
        }else{
            success(0,nil,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
+ (void)selectAvailableCouponList:(NSDictionary *)param
                          success:(void(^)(NSUInteger count,NSArray *list,NSString *msg))success
                           falure:(void(^)(NSError *error))falure{
    [RLAPIManager SafePOST:URI_INTERFACES_SELECTSTARTEDCOUPON_LIST parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            NSMutableArray *array = [NSMutableArray array];
            for (NSDictionary *dic in [responseObject jk_arrayForKey:@"result"]) {
                RLCouponModel *model = [RLCouponModel objectFromDictionary:dic];
                [array addObject:model];
            }
            success([responseObject jk_integerForKey:@"pageNum"],array,nil);
        }else{
            success(0,nil,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
@end
