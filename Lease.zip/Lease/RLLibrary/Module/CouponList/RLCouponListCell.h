//
//  RLCouponCell.h
//  RLLibrary
//
//  Created by sun on 2018/4/24.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RLCouponModel.h"
@interface RLCouponListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *preferentialwayBTN;
@property (weak, nonatomic) IBOutlet UILabel *starttimeLB;
@property (weak, nonatomic) IBOutlet UILabel *endtimeLB;
@property (weak, nonatomic) IBOutlet UILabel *fullcutpriceLB;
@property (weak, nonatomic) IBOutlet UILabel *couponnameLB;
@property (weak, nonatomic) IBOutlet UILabel *preferentialpriceLB;
@property (weak, nonatomic) IBOutlet UIView *viewBg;
@property (weak, nonatomic) IBOutlet UIImageView *passbyImage;
@property (weak, nonatomic) IBOutlet UIImageView *cell_bg;
@property (weak, nonatomic) IBOutlet UIView *maskView;
-(void)configCell:(RLCouponModel *)item;
@end
