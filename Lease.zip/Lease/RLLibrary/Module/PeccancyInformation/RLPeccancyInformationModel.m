//
//  RLPeccancyInformationModel.m
//  RLLibrary
//
//  Created by Cluy on 2018/5/31.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLPeccancyInformationModel.h"

@implementation RLPeccancyInformationModel
+ (void)getIllegalistData:(NSDictionary *)param
            success:(void(^)(NSArray *result,NSString *message))success
             falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_SELECTILLEGAL_LIST parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            NSArray *result = [responseObject jk_arrayForKey:@"result"];
            success(result,nil);
        }else{
            success(nil,[responseObject jk_stringForKey:@"message"]);
        }
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
@end
