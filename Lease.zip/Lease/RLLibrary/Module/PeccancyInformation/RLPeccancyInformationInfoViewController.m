//
//  RLPeccancyInformationInfoViewController.m
//  RLLibrary
//
//  Created by Cluy on 2018/5/22.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLPeccancyInformationInfoViewController.h"
#import "RLInclude.h"
#import "RLRuleViewController.h"
#import "RLMicro.h"
@interface RLPeccancyInformationInfoViewController ()

@end

@implementation RLPeccancyInformationInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initView];
}
-(void)initView{
    self.orderNumbers.text = _item.orderNumbers;
    self.plate.text = _item.carplate;
    self.illegalTime.text = _item.illegalTime;
    self.place.text = _item.place ;
    self.illegalContent.text = _item.illegalContent ;
    self.price.text = _item.price ;
    self.points.text = _item.points;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)ruleTouched:(id)sender {
    RLLog(@"点击了规则按钮");
    RLRuleViewController *viewController = [[RLRuleViewController alloc] initWithNibName:@"RLRuleViewController" bundle:[NSBundle RLResourceBundle]];
    [self presentViewController:viewController animated:YES completion:^{
    }];
}

#pragma mark ---------------back---------------
- (IBAction)back:(id)sender {
    if(self.navigationController){
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

@end
