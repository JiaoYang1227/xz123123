//
//  RLPeccancyInformationModel.h
//  RLLibrary
//
//  Created by Cluy on 2018/5/31.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"

@interface RLPeccancyInformationModel : RLBaseModel
@property(nonatomic,strong)NSString *carid;//车辆ID
@property(nonatomic,strong)NSString *orderNumbers;//订单编号
@property(nonatomic,strong)NSString *illegalTime;//违章时间
@property(nonatomic,strong)NSString *illegalContent;//违章项
@property(nonatomic,strong)NSString *place;//地点
@property(nonatomic,strong)NSString *points;//扣分
@property(nonatomic,strong)NSString *price;//扣款（元）
@property(nonatomic,strong)NSString *status;//状态（0未处理 1处理）
@property(nonatomic,strong)NSString *adduserid;//添加人id
@property(nonatomic,strong)NSString *addtime;//添加时间
@property(nonatomic,strong)NSString *upduserid;//修改人id
@property(nonatomic)long long updtime;//修改时间
@property(nonatomic)BOOL isdelete;//是否删除（0 未删除 1 已删除）
@property(nonatomic,strong)NSString *flag;// 标识
@property(nonatomic,strong)NSString *carplate;//车牌号
//获取违章查询 参数为userid 
+ (void)getIllegalistData:(NSDictionary *)param
                  success:(void(^)(NSArray *result,NSString *message))success
                   falure:(void(^)(NSError *error))falure;

@end
