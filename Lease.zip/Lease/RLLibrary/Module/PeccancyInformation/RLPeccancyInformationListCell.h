//
//  RLPeccancyInformationListCell.h
//  RLLibrary
//
//  Created by Cluy on 2018/5/22.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RLPeccancyInformationModel.h"

@interface RLPeccancyInformationListCell : UITableViewCell
//罚分
@property (weak, nonatomic) IBOutlet UILabel *points;
//扣款
@property (weak, nonatomic) IBOutlet UILabel *price;
//时间
@property (weak, nonatomic) IBOutlet UILabel *time;
//违章项
@property (weak, nonatomic) IBOutlet UILabel *illegalContent;
//违章地点
@property (weak, nonatomic) IBOutlet UILabel *place;

-(void)ConfigCell:(RLPeccancyInformationModel*)item;
@end
