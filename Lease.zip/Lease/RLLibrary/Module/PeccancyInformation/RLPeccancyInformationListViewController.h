//
//  PeccancyInformationListViewController.h
//  RLLibrary
//
//  Created by Cluy on 2018/5/22.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RLPeccancyInformationListViewController : UIViewController
//未处理
@property (weak, nonatomic) IBOutlet UIButton *untreatedBtn;
@property (weak, nonatomic) IBOutlet UIView *untreatedLine;

//已处理
@property (weak, nonatomic) IBOutlet UIButton *completeBtn;
@property (weak, nonatomic) IBOutlet UIView *completeLine;

@property (weak, nonatomic) IBOutlet UITableView *listTable;
@property (weak, nonatomic) NSString *aid;
@property (nonatomic,strong)NSArray *dataList;
@property (nonatomic,strong)NSString *staus;
@end
