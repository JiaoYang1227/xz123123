//
//  RLRuleViewController.m
//  RLLibrary
//
//  Created by Cluy on 2018/6/4.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLRuleViewController.h"
#import "RLConstant.h"

@interface RLRuleViewController ()

@end

@implementation RLRuleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *url = [NSString stringWithFormat:@"%@/htmlPage/rulePage",URI_SERVER_ADDRESS];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark ---------------back---------------
- (IBAction)back:(id)sender {
    if(self.navigationController){
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

@end
