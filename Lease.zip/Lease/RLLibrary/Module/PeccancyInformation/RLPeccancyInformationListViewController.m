//
//  PeccancyInformationListViewController.m
//  RLLibrary
//
//  Created by Cluy on 2018/5/22.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLPeccancyInformationListViewController.h"
#import "RLPeccancyInformationInfoViewController.h"
#import "RLPeccancyInformationListCell.h"
#import "RLPeccancyInformationModel.h"
#import "RLInclude.h"
#import "JKAlert.h"
#import <MJRefresh/MJRefresh.h>
#import "CBTracking.h"
@interface RLPeccancyInformationListViewController ()

@end

@implementation RLPeccancyInformationListViewController
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"ViolationList"];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"ViolationList"];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initView];
    [self addRefreshView];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)initView{
    _untreatedBtn.selected = YES;
    _untreatedLine.hidden = NO;
    _completeBtn.selected = NO;
    _completeLine.hidden = YES;
    
    _staus = @"0";
}
- (void)addRefreshView{
    _listTable.mj_header.automaticallyChangeAlpha = YES;
    _listTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self loadData];
    }];
}
-(void)loadData{
    _dataList = [[NSArray alloc]init];
    [RLPeccancyInformationModel getIllegalistData:@{@"userid":self.aid?:@"",@"status":_staus} success:^(NSArray *result, NSString *message) {
        if (message!= nil) {
            [JKAlert showMessage:message];
            [_listTable.mj_header endRefreshing];
            [_listTable reloadData];
            return ;
        }else{
            if(_dataList == nil){
                
            }
            _dataList = (NSMutableArray *)result;
            [_listTable.mj_header endRefreshing];
            [_listTable reloadData];
        }
    } falure:^(NSError *error) {
         [_listTable.mj_header endRefreshing];
    }];
}
//待处理
- (IBAction)treatedBtnTouched:(id)sender {
    _untreatedBtn.selected = YES;
    _untreatedLine.hidden = NO;
    _completeBtn.selected = NO;
    _completeLine.hidden = YES;
    _staus = @"0";
    [self loadData];
}
//已处理
- (IBAction)completeBtnTouched:(id)sender {
    _untreatedBtn.selected = NO;
    _untreatedLine.hidden = YES;
    _completeBtn.selected = YES;
    _completeLine.hidden = NO;
    _staus = @"1";
    [self loadData];
}

#pragma mark ---------------UITableView---------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_dataList count];
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"RLPeccancyInformationListCell";
    [tableView registerNib:[UINib nibWithNibName:@"RLPeccancyInformationListCell" bundle:[NSBundle RLResourceBundle]] forCellReuseIdentifier:CellIdentifier];
    RLPeccancyInformationListCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    RLPeccancyInformationModel *item = [RLPeccancyInformationModel objectFromDictionary:[_dataList objectAtIndex:indexPath.row]];
    [cell ConfigCell:item];
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    RLPeccancyInformationInfoViewController *controller = [[RLPeccancyInformationInfoViewController alloc] initWithNibName:@"RLPeccancyInformationInfoViewController" bundle:[NSBundle RLResourceBundle]];
    RLPeccancyInformationModel *item = [RLPeccancyInformationModel objectFromDictionary:[_dataList objectAtIndex:indexPath.row]];
    controller.item = item;
    [self presentViewController:controller animated:YES completion:^{
    }];
}
#pragma mark ---------------back---------------
- (IBAction)back:(id)sender {
    if(self.navigationController){
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

@end
