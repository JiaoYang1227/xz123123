//
//  RLPeccancyInformationListCell.m
//  RLLibrary
//
//  Created by Cluy on 2018/5/22.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLPeccancyInformationListCell.h"

@implementation RLPeccancyInformationListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)ConfigCell:(RLPeccancyInformationModel*)item{
    //罚分
    _points.text = item.points?:@"";
    //扣款
    _price.text = item.price?:@"";
    //时间
    _time.text = item.illegalTime;
    //违章项
    _illegalContent.text = [NSString stringWithFormat:@"违章行为：%@",item.illegalContent];
    //违章地点
    _place.text = [NSString stringWithFormat:@"违章地点：%@",item.place];
}
@end
