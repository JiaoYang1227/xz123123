//
//  RLPeccancyInformationInfoViewController.h
//  RLLibrary
//
//  Created by Cluy on 2018/5/22.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RLPeccancyInformationModel.h"

@interface RLPeccancyInformationInfoViewController : UIViewController
@property(nonatomic,strong)RLPeccancyInformationModel *item;
@property (weak, nonatomic) IBOutlet UILabel *orderNumbers;
@property (weak, nonatomic) IBOutlet UILabel *plate;
@property (weak, nonatomic) IBOutlet UILabel *illegalTime;
@property (weak, nonatomic) IBOutlet UILabel *place;
@property (weak, nonatomic) IBOutlet UILabel *illegalContent;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *points;

@end
