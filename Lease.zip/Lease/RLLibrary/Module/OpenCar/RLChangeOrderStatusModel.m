//
//  RLChangeOrderStatusModel.m
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLChangeOrderStatusModel.h"

@implementation RLChangeOrderStatusModel
+ (void)beginvehiclereservations:(NSDictionary *)param
                 success:(void(^)(BOOL success,NSString *message))success
                  falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafePOST:URI_INTERFACES_VEHICLERESERCATIONS_BAGIN parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success(YES,nil);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}

+ (void)auth:(NSDictionary *)param
                         success:(void(^)(BOOL success,NSString *message))success
                          falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_AUTH parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success(YES,nil);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
+ (void)getAuthKey:(NSDictionary *)param
     success:(void(^)(NSString *authKey,NSString *message))success
      falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_GET_AUTH_KEY parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success([responseObject jk_stringForKey:@"result"],nil);
        }else{
            success(nil,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
+ (void)revokeAuth:(NSDictionary *)param
           success:(void(^)(BOOL success,NSString *message))success
            falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_REVOKE_AUTH_KEY parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success(YES,nil);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
+ (void)cancelVehicleReservations:(NSDictionary *)param
                         success:(void(^)(BOOL success,NSString *message))success
                          falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafePOST:URI_INTERFACES_VEHICLERESERCATIONS_CANCLE parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success(YES,[responseObject jk_stringForKey:@"message"]);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
@end
