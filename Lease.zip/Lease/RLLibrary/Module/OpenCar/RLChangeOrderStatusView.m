//
//  RLOpenCarView.m
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLChangeOrderStatusView.h"
#import "RLChangeOrderStatusModel.h"
#import "JKAlert.h"
#import <SVProgressHUD.h>
#import <UIImage+GIF.h>
#import "RLInclude.h"
#import "RLFileManager.h"
#import "RLOperationModel.h"
#import "DateManager.h"
#import "LogWriter.h"
#import "RLMicro.h"
@implementation RLChangeOrderStatusView{
    UIButton * _submit;
    UIButton * _cancel;
}
- (instancetype)initWithFrame:(CGRect)frame
                  orderNumber:(NSString *)orderNumber
                          vin:(NSString *)vin
                        phone:(NSString *)phone
                       userid:(NSString *)userid
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setOrderNumber:orderNumber vin:vin phone:phone userid:userid];
        [self buidView];
    }
    return self;
}

-(void)setOrderNumber:(NSString *)orderNumber
                  vin:(NSString *)vin
                phone:(NSString *)phone
               userid:(NSString *)userid{
    self.vin = vin;
    self.orderNumber = orderNumber;
    self.userid = userid;
    self.phone = phone;
    [LogWriter uploadLog];
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self buidView];
}
-(void)buidView{
    _submit = [[UIButton alloc]init];
    [_submit setTitle:@"开始订单" forState: UIControlStateNormal];
    [_submit addTarget:self action:@selector(openCar:)
      forControlEvents:UIControlEventTouchUpInside];
    _submit.layer.cornerRadius = _submit.frame.size.height/2;
    _submit.backgroundColor = [UIColor colorWithRed:26.0/255.0 green:132.0/255.0 blue:210.0/255.0 alpha:1];
    [self addSubview:_submit];
    
    _cancel = [[UIButton alloc]init];
    [_cancel setTitle:@"取消订单" forState: UIControlStateNormal];
    [_cancel addTarget:self action:@selector(CancelOrder:) forControlEvents:UIControlEventTouchUpInside];
    [_cancel setTitleColor:[UIColor colorWithRed:120.0/255.0 green:120.0/255.0 blue:120.0/255.0 alpha:1] forState:UIControlStateNormal];
    [self addSubview:_cancel];
    [self changeFrame];
}
-(void)openCar:(UIButton *)sender{
    if (self.shouldReloadParent) {
        [LogWriter writeLog:@"点击开始订单" detail:@"此处钛玛调用人脸识别" inParams:nil outParams:nil];
        
        self.shouldReloadParent(@"开始订单",YES);
    }
}
-(void)beginOrderWitbeginOrderType:(BeginOrder)beginOrdertype{
  
    [LogWriter writeLog:@"钛玛人脸识别返回成功调用开始订单"
                 detail:@"此处钛玛调用人脸识别" inParams:@{@"orderNumber":self.orderNumber?:@"",@"userid":self.userid?:@"",@"vin":self.vin?:@"",@"phone":self.phone?:@""} outParams:nil];
    
    if ([self ISAssignment]) {
        NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
        [param setValue:self.orderNumber?:@"" forKey:@"order_numbers"];
        [param setValue:self.vin?:@"" forKey:@"vin"];
        [param setValue:self.userid?:@"" forKey:@"aid"];
        [param setValue:self.phone?:@"" forKey:@"phone"];
        NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
        NSData *data = [NSData dataWithContentsOfFile:path];
        UIImage *hubImage = [UIImage sd_animatedGIFWithData:data];
        [SVProgressHUD setInfoImage:hubImage];
        [SVProgressHUD setImageViewSize:CGSizeMake(80, 53)];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
        [SVProgressHUD showInfoWithStatus:@"努力加载中..."];
        [RLChangeOrderStatusModel auth:param success:^(BOOL success,NSString *message) {
            if (success) {
                [RLChangeOrderStatusModel beginvehiclereservations:param success:^(BOOL success, NSString *message) {
                    if (success) {
                        if (beginOrdertype) {
                            [LogWriter writeLog:@"开始订单接口返回成功"
                                         detail:@""
                                       inParams:nil outParams:nil];
                            
                            beginOrdertype(@"开始订单",YES);
                        }
                    }else{
                        [LogWriter writeLog:@"开始订单接口返回失败"
                                     detail:@""
                                   inParams:nil outParams:nil];
                        [JKAlert showMessage:message];
                    }
                } falure:^(NSError *error) {
                    if (beginOrdertype) {
                        [LogWriter writeLog:@"开始订单接口返回error"
                                     detail:error.localizedDescription
                                   inParams:nil outParams:nil];
                        beginOrdertype(@"开始订单",NO);
                    }
                }];
                
            }else{
                if (beginOrdertype) {
                    [LogWriter writeLog:@"下发授权指令接口success NO"
                                 detail:nil
                               inParams:nil outParams:nil];
                    beginOrdertype(@"开始订单",NO);
                }
                [JKAlert showMessage:message];
            }
            [SVProgressHUD dismiss];
        } falure:^(NSError *error) {
            [JKAlert showMessage:@"网络连接失败,请重试!"];
            if (beginOrdertype) {
                [LogWriter writeLog:@"下发授权指令接口error"
                             detail:error.localizedDescription
                           inParams:nil outParams:nil];
                beginOrdertype(@"开始订单",NO);
            }
            [SVProgressHUD dismiss];
        }];
    }
}
-(void)CancelOrder:(UIButton *)sender{
    JKAlert *alert = [[JKAlert alloc]initWithTitle:@"提示" andMessage:@"尊敬的用户您好：每日取消订单次数不得超过5次，是否确认取消订单" style:STYLE_ALERT];
    [alert addButton:ITEM_OK withTitle:@"确认" handler:^(JKAlertItem *item) {
        if ([self ISAssignment]) {
            NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
            [param setValue:self.orderNumber?:@"" forKey:@"order_numbers"];
            [param setValue:self.vin?:@"" forKey:@"vin"];
            [param setValue:self.userid forKey:@"aid"];
            [param setValue:self.phone?:@"" forKey:@"phone"];
            [param setValue:@"runlin" forKey:@"datafrom"];
            NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
            NSData *data = [NSData dataWithContentsOfFile:path];
            UIImage *hubImage = [UIImage sd_animatedGIFWithData:data];
            [SVProgressHUD setInfoImage:hubImage];
            [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
            [SVProgressHUD setImageViewSize:CGSizeMake(80, 53)];
            [SVProgressHUD showInfoWithStatus:@"努力加载中..."];
            [RLChangeOrderStatusModel cancelVehicleReservations:param success:^(BOOL success,NSString *message) {
                [SVProgressHUD dismiss];
                if (success) {
                    [JKAlert showMessage:@"取消成功"];
                    [LogWriter writeLog:@"取消订单"
                                 detail:@"返回成功"
                               inParams:nil outParams:nil];
                    if (self.shouldReloadParent) {
                        self.shouldReloadParent(@"取消订单",YES);
                    }
                }else{
                    [JKAlert showMessage:message];
                    [LogWriter writeLog:@"取消订单"
                                 detail:@"返回失败"
                               inParams:nil outParams:nil];
                    if (self.shouldReloadParent) {
                        self.shouldReloadParent(@"取消订单",NO);
                    }
                }
            } falure:^(NSError *error) {
                [LogWriter writeLog:@"取消订单接口error"
                             detail:error.localizedDescription
                           inParams:nil outParams:nil];
                [SVProgressHUD dismiss];
                [JKAlert showMessage:@"网络连接失败,请重试!"];
                if (self.shouldReloadParent) {
                    self.shouldReloadParent(@"取消订单",YES);
                }
                
            }];
        }
    }];
    [alert addButton:ITEM_CANCEL withTitle:@"取消" handler:^(JKAlertItem *item) {
        
    }];
    [alert show];
    
}
     
-(void)changeFrame{
    float width = 0;
    float height = 0;
    float xSpacing = 0;
    float ySpacing = 0;
    
    width = self.frame.size.width*174.0/181.0;
    height = self.frame.size.height*23.0/49.0;
    xSpacing = (self.frame.size.width - width)/2.0;
    ySpacing = self.frame.size.height*6.5/49.0;
    
    _submit.layer.cornerRadius = _submit.frame.size.height/2;
    _submit.backgroundColor = [UIColor colorWithRed:26.0/255.0 green:132.0/255.0 blue:210.0/255.0 alpha:1];
    
    [_submit setFrame:CGRectMake(xSpacing, ySpacing, width, height)];
    
    [_cancel setFrame:CGRectMake(xSpacing, self.frame.size.height*34.0/49.0, width, self.frame.size.height*10.0/49.0)];
}
     
-(void)layoutSubviews{
    
    [self changeFrame];
    
}

/**
 *  返回当前视图的控制器
 */
- (UIViewController *)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder *nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController *)nextResponder;
        }
    }
    return nil;
}


-(BOOL)ISAssignment{
    if (!self.vin||[@""isEqualToString:self.vin]||
        !self.orderNumber||[@""isEqualToString:self.orderNumber]||
        !self.phone||[@""isEqualToString:self.phone]||
        !self.userid||[@""isEqualToString:self.userid]) {
        RLLog(@"没有vin,和orderNumber,请调用这个方法添加-(void)setOrderNumber:(NSString *)orderNumber vin:(NSString *)vin phone:(NSString *)phone userid:(NSString *)userid");
        return NO;
    }
    return YES;
}
 
@end
