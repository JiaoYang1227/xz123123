//
//  RLChangeOrderStatusModel.h
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"

@interface RLChangeOrderStatusModel : RLBaseModel
//开始订单
+ (void)beginvehiclereservations:(NSDictionary *)param
                         success:(void(^)(BOOL success,NSString *message))success
                          falure:(void(^)(NSError *error))falure;

//取消预约车辆
+ (void)cancelVehicleReservations:(NSDictionary *)param
                          success:(void(^)(BOOL success,NSString *message))success
                           falure:(void(^)(NSError *error))falure;

//下发授权指令接口
+ (void)auth:(NSDictionary *)param
     success:(void(^)(BOOL success,NSString *message))success
      falure:(void(^)(NSError *error))falure;

//获取授权认证信息接口
+ (void)getAuthKey:(NSDictionary *)param
           success:(void(^)(NSString *authKey,NSString *message))success
            falure:(void(^)(NSError *error))falure;
//去权
+ (void)revokeAuth:(NSDictionary *)param
           success:(void(^)(BOOL success,NSString *message))success
            falure:(void(^)(NSError *error))falure;
@end
