//
//  RLCommentsModel.h
//  RLLibrary
//
//  Created by sun on 2018/3/8.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"

@interface RLCommentsModel : RLBaseModel
+ (void)mobilityEvaluate:(NSDictionary *)param
               imageList:(NSArray *)imageList
                 success:(void(^)(BOOL success,NSString *message))success
                  falure:(void(^)(NSError *error))falure;

+ (void)evaluateByOrderNumbers:(NSString *)orderNumbers
                       success:(void(^)(NSDictionary *result,NSString *message))success
                        falure:(void(^)(NSError *error))falure;
//发放魔豆
+ (void)grantMagicBean:(NSDictionary *)param
               success:(void(^)(BOOL success,NSString *message))success
                falure:(void(^)(NSError *error))falure;
@end
