//
//  RLCommentsViewController.m
//  RLLibrary
//
//  Created by sun on 2018/3/5.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLCommentsViewController.h"
#import <TZImagePickerController.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/Photos.h>
#import "RLInclude.h"
#import "RLRatingView.h"
#import "BorderTextView.h"
#import "BorderButton.h"
#import "RLCommentsModel.h"
#import "JKAlert.h"
#import "DetermineButton.h"
#import "RLAddPhotoCell.h"
#import <UIView+Layout.h>
#import <TZLocationManager.h>
#import <TZImageManager.h>
#import <SVProgressHUD.h>
#import "NSDictionary+JKSafeAccess.h"
#import <UIImage+GIF.h>
#import "UIImage+JKSuperCompress.h"
#import "UIViewController+JKPopup.h"
#import <UIImageView+AFNetworking.h>
#import "CBTracking.h"
#define iOS7Later ([UIDevice currentDevice].systemVersion.floatValue >= 7.0f)
#define iOS8Later ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f)
#define iOS9Later ([UIDevice currentDevice].systemVersion.floatValue >= 9.0f)
#define iOS9_1Later ([UIDevice currentDevice].systemVersion.floatValue >= 9.1f)
#import "RLMicro.h"
@interface RLCommentsViewController ()<TZImagePickerControllerDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UIAlertViewDelegate,UINavigationControllerDelegate>{
    __weak IBOutlet UILabel *_paymentStatusLB;//支付状态
    __weak IBOutlet UILabel *_moneyLB;
    __weak IBOutlet UILabel *_rentalLocationLB;//租车地点
    __weak IBOutlet UILabel *_returnCarLocationLB;//还车地点
    __weak IBOutlet RLRatingView *_softwareExperienceStarView;//软件体验
    __weak IBOutlet RLRatingView *_conditionStarView;//车辆状况
    __weak IBOutlet RLRatingView *_drivingExperienceStarView;//驾驶体验
    __weak IBOutlet DetermineButton *_submitBTN;
    NSString *_appScore; //APP评分
    NSString *_carScore;//车况评分
    NSString *_serviceScore;//服务评分
    UICollectionViewFlowLayout * layout;
    BOOL _isSelectOriginalPhoto;
    
    __weak IBOutlet BorderTextView *noteTV;//content评价内容
    NSMutableArray *_selectedPhotos;
    NSMutableArray *_showPhotos;
    NSMutableArray *_selectedAssets;
    TZImagePickerController *_photpLibaryPickerVc;
    
    __weak IBOutlet UIView *_starView;
    __weak IBOutlet UIView *_noteView;
    BOOL _alreadyComments;
}
@property (nonatomic, strong) UIImagePickerController *imagePickerVc;
@property (strong, nonatomic) CLLocation *location;
@property (weak, nonatomic) IBOutlet UICollectionView *addPhotoCollectionView;
@end

@implementation RLCommentsViewController
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"Evaluate"];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"Evaluate"];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setDefault];
    _alreadyComments = NO;
    _selectedPhotos = [NSMutableArray array];
    _showPhotos = [NSMutableArray array];
    _selectedAssets = [NSMutableArray array];
    [self configCollectionView];
    
}
-(void)getDefaultValue:(NSDictionary *)dic{
    [_submitBTN setHidden:YES];
    [_starView setUserInteractionEnabled:NO];
    [noteTV setUserInteractionEnabled:NO];
    [_noteView setUserInteractionEnabled:NO];
    [_addPhotoCollectionView setUserInteractionEnabled:NO];
    [_submitBTN setUserInteractionEnabled:NO];
    
    [_softwareExperienceStarView displayRating:[dic jk_integerForKey:@"appScore"]];
    [_conditionStarView displayRating:[dic jk_integerForKey:@"carScore"]];
    [_drivingExperienceStarView displayRating:[dic jk_integerForKey:@"serviceScore"]];
    
    RLLog(@"%@",[dic objectForKey:@"picone"]);
    
    
        NSString *str = [dic jk_stringForKey:@"content"];
    
    
        NSMutableArray *noteArray = (NSMutableArray *)[str componentsSeparatedByString:@","];
        NSString *noteStr = [NSString string];
        for (UIButton *btn in _allBtns) {
            BOOL isbool = [noteArray containsObject: btn.titleLabel.text];
            if (isbool) {
                [btn setSelected:YES];
                [noteArray removeObject:btn.titleLabel.text];
            }else{
                [btn setSelected:NO];
            }
        }
        for (NSString *str in noteArray) {
            noteStr = [noteStr stringByAppendingString:str];
        }
        noteTV.text = noteStr;
    _alreadyComments = YES;
    if ([dic jk_stringForKey:@"picone"]) {
        [_showPhotos addObject:[dic jk_stringForKey:@"picone"]];
    }
    if ([dic jk_stringForKey:@"pictwo"]) {
        [_showPhotos addObject:[dic jk_stringForKey:@"pictwo"]];
    }
    if ([dic jk_stringForKey:@"picthree"]) {
        [_showPhotos addObject:[dic jk_stringForKey:@"picthree"]];
    }
    if ([dic jk_stringForKey:@"picfour"]) {
        [_showPhotos addObject:[dic jk_stringForKey:@"picfour"]];
    }
    [_addPhotoCollectionView reloadData];
}
-(void)setDefault{
    _paymentStatusLB.text = self.paymentStatus?:@"";
    _moneyLB.text = [NSString stringWithFormat:@"%@元",self.money?:@""];
    _rentalLocationLB.text = self.rentalLocation?:@"暂无";
    _returnCarLocationLB.text = self.returnCarLocation?:@"暂无";
    noteTV.placeholder = @"其他想说的";
    noteTV.placeholderColor = [UIColor colorWithRed:170.0/255.0 green:170.0/255.0 blue:170.0/255.0 alpha:1];
    [_softwareExperienceStarView setImagesDeselected:@"RL_Comments_star_normal" fullSelected:@"RL_OrderEvaluatestar_star_selected" andJYRatingChangedBlock:^(float newRating) {
        _appScore = [NSString stringWithFormat:@"%d",(int)newRating];
        RLLog(@"软件体验当前评分:%f",newRating);
    }];
    [_softwareExperienceStarView displayRating:5];

    [_conditionStarView setImagesDeselected:@"RL_Comments_star_normal" fullSelected:@"RL_OrderEvaluatestar_star_selected" andJYRatingChangedBlock:^(float newRating) {
        _carScore = [NSString stringWithFormat:@"%d",(int)newRating];
        RLLog(@"车辆状况当前评分:%f",newRating);
    }];
    [_conditionStarView displayRating:5];

    [_drivingExperienceStarView setImagesDeselected:@"RL_Comments_star_normal" fullSelected:@"RL_OrderEvaluatestar_star_selected" andJYRatingChangedBlock:^(float newRating) {
        _serviceScore = [NSString stringWithFormat:@"%d",(int)newRating];
        RLLog(@"驾驶体验当前评分:%f",newRating);
    }];
    [_drivingExperienceStarView displayRating:5];
    [RLCommentsModel evaluateByOrderNumbers:self.orderNumber success:^(NSDictionary *result, NSString *message) {
        if (result) {
            [self getDefaultValue:result];
        }
    } falure:^(NSError *error) {

    }];
}

- (void)configCollectionView {
    layout = [[UICollectionViewFlowLayout alloc] init];
    [_addPhotoCollectionView setCollectionViewLayout:layout];
    _addPhotoCollectionView.alwaysBounceVertical = YES;
    _addPhotoCollectionView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);

    _addPhotoCollectionView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;

    [_addPhotoCollectionView registerClass:[RLAddPhotoCell class] forCellWithReuseIdentifier:@"RLAddPhotoCell"];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    layout.itemSize = CGSizeMake(_addPhotoCollectionView.tz_width/4, _addPhotoCollectionView.tz_width/4-12);
    layout.minimumInteritemSpacing = 0;
    layout.minimumLineSpacing = 0;
    [_addPhotoCollectionView setCollectionViewLayout:layout];
    _submitBTN.layer.cornerRadius = _submitBTN.tz_height/2;
}

- (IBAction)back:(id)sender {
    if(self.navigationController){
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark 限制输入
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range  replacementText:(NSString *)text
{
    // 删除回退的时候返回yes
    if (text.length == 0 && range.length == 1) {
        return YES;
    }
    //判断加上输入的字符，是否超过界限
    noteTV.limit = 50;
    return YES;
}
- (IBAction)KeywordSelection:(BorderButton *)sender {
    [sender changeState];
}
- (IBAction)submitTouched:(id)sender {
    if (!self.orderNumber||[@""isEqualToString:self.orderNumber]||
        !self.userid||[@""isEqualToString:self.userid]) {
        RLLog(@"没有userid,或者没有orderNumber");
        return;
    }
    [SVProgressHUD showWithStatus:@"努力加载中..."];
    __weak typeof(self) weakSelf = self;
    if (_showPhotos.count>_selectedPhotos.count) {
        dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1/*延迟执行时间*/
                                                                               * NSEC_PER_SEC));
        dispatch_after(delayTime, dispatch_get_main_queue(), ^{
            [weakSelf submitTouched:nil];
        });
    }else{
        [self upload];
    }
    
}
-(void)upload{
    
    NSString *str = [NSString string];
    for (UIButton *btn in _allBtns) {
        if (btn.selected) {
            if (str.length == 0) {
                str = btn.titleLabel.text;
            }else{
                str = [NSString stringWithFormat:@"%@,%@",str,btn.titleLabel.text];
            }
        }
    }
    RLLog(@"%@",str);
    NSString * note;
    if (str.length>0) {
        note = [NSString stringWithFormat:@"[%@]%@",noteTV.text?:@"",str];
    }else{
        note = noteTV.text?:@"";
    }
//    for (NSData *image1 in _selectedPhotos) {
//        RLLog(@"qqqqq:%lu",[image1 length]/1024);
//    }
    
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.orderNumber?:@"" forKey:@"orderNumbers"];
    [param setValue:_appScore?:@"" forKey:@"appScore"];
    [param setValue:_carScore?:@"" forKey:@"carScore"];
    [param setValue:_serviceScore?:@"" forKey:@"serviceScore"];
    [param setValue:self.userid?:@"" forKey:@"aid"];
    [param setValue:note forKey:@"content"];
    
    [RLCommentsModel mobilityEvaluate:param imageList:_selectedPhotos  success:^(BOOL success,NSString*message) {
        if (success == NO) {
            [JKAlert showMessage:message];
        }else{
            
            [self presentJKPopupViewController:[RLInclude getRLCommentShareViewControllerwithaid:self.userid?:@"" orderNo:self.orderNumber?:@"" ShareDone:^(BOOL success) {
//                [self back:nil];
            }]];
            
        }
        [SVProgressHUD dismiss];
    } falure:^(NSError *error) {
        [JKAlert showMessage:@"网络连接失败,请重试!"];
        [SVProgressHUD dismiss];
    }];
}
//费用详细
- (IBAction)detailTouched:(id)sender {
    if (self.jumpThePayment) {
        self.jumpThePayment(self);
    }
}

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
- (UIImagePickerController *)imagePickerVc {
    if (_imagePickerVc == nil) {
        _imagePickerVc = [[UIImagePickerController alloc] init];
        _imagePickerVc.delegate = self;
        // set appearance / 改变相册选择页的导航栏外观
        if (iOS7Later) {
            _imagePickerVc.navigationBar.barTintColor = self.navigationController.navigationBar.barTintColor;
        }
        _imagePickerVc.navigationBar.tintColor = self.navigationController.navigationBar.tintColor;
        UIBarButtonItem *tzBarItem, *BarItem;
        if (iOS9Later) {
            tzBarItem = [UIBarButtonItem appearanceWhenContainedInInstancesOfClasses:@[[TZImagePickerController class]]];
            BarItem = [UIBarButtonItem appearanceWhenContainedInInstancesOfClasses:@[[UIImagePickerController class]]];
        } else {
            tzBarItem = [UIBarButtonItem appearanceWhenContainedIn:[TZImagePickerController class], nil];
            BarItem = [UIBarButtonItem appearanceWhenContainedIn:[UIImagePickerController class], nil];
        }
        NSDictionary *titleTextAttributes = [tzBarItem titleTextAttributesForState:UIControlStateNormal];
        [BarItem setTitleTextAttributes:titleTextAttributes forState:UIControlStateNormal];
        
    }
    return _imagePickerVc;
}

#pragma mark UICollectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (_alreadyComments) {
        return _showPhotos.count;
    }else{
        if (_showPhotos.count < 4) {
            return _showPhotos.count + 1;
        }else{
            return 4;
        }
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    RLAddPhotoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"RLAddPhotoCell" forIndexPath:indexPath];
    cell.numLable.hidden = YES;
    cell.deleteBtn.hidden = NO;
    if (indexPath.row == _showPhotos.count&&_showPhotos.count<4) {
        cell.imageView.image = [UIImage RLImageNamed:@"RL_OrderEvaluatestar_upload_photos"];
        cell.deleteBtn.hidden = YES;
        cell.numLable.hidden = NO;

    } else {
        if (_alreadyComments == YES) {
            [cell.imageView setImageWithURL:[NSURL URLWithString:[_showPhotos objectAtIndex:indexPath.row]?:@""]];
            cell.deleteBtn.hidden = YES;
        }else{
             cell.imageView.image = _showPhotos[indexPath.row];
            cell.asset = _selectedAssets[indexPath.row];
            cell.deleteBtn.hidden = NO;
        }
       
        
        
        
    }
    cell.deleteBtn.tag = indexPath.row;
    [cell.deleteBtn addTarget:self action:@selector(deleteBtnClik:) forControlEvents:UIControlEventTouchUpInside];
    cell.numLable.text = [NSString stringWithFormat:@"%ld/4",(long)indexPath.row+1];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == _showPhotos.count) {
        UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"去相册选择", nil];
        [sheet showInView:self.view];
    }else{// preview photos / 预览照片
        _photpLibaryPickerVc = [[TZImagePickerController alloc] initWithSelectedAssets:_selectedAssets selectedPhotos:_showPhotos index:indexPath.row];
        _photpLibaryPickerVc.maxImagesCount = 4;
        _photpLibaryPickerVc.allowPickingGif = NO;
        _photpLibaryPickerVc.allowPickingOriginalPhoto = NO;
        _photpLibaryPickerVc.allowPickingMultipleVideo = NO;
        _photpLibaryPickerVc.isSelectOriginalPhoto = _isSelectOriginalPhoto;
        __weak typeof(self) weakSelf = self;
        [_photpLibaryPickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
            _showPhotos = [NSMutableArray arrayWithArray:photos];
            _selectedAssets = [NSMutableArray arrayWithArray:assets];
            _isSelectOriginalPhoto = isSelectOriginalPhoto;
            [weakSelf.addPhotoCollectionView reloadData];

        }];
        [self presentViewController:_photpLibaryPickerVc animated:YES completion:nil];
    }
    
}

- (void)refreshCollectionViewWithAddedAsset:(id)asset image:(UIImage *)image {
    [_showPhotos addObject:image];
    [_addPhotoCollectionView reloadData];
    [_selectedAssets addObject:asset];
    [UIImage jk_compressImage:image toMaxLength:256*1024 maxWidth:image.size.width imageBlock:^(NSData *newImage) {
        [_selectedPhotos addObject:newImage];
    }];
    
    if ([asset isKindOfClass:[PHAsset class]]) {
        PHAsset *phAsset = asset;
        RLLog(@"location:%@",phAsset.location);
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    if ([picker isKindOfClass:[UIImagePickerController class]]) {
        [picker dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark - TZImagePickerController

- (void)pushTZImagePickerController {
    
    _photpLibaryPickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:4 columnNumber:4 delegate:self pushPhotoPickerVc:YES];
    // imagePickerVc.navigationBar.translucent = NO;
    
#pragma mark - 五类个性化设置，这些参数都可以不传，此时会走默认设置
    _photpLibaryPickerVc.isSelectOriginalPhoto = _isSelectOriginalPhoto;
    
        // 1.设置目前已经选中的图片数组
    _photpLibaryPickerVc.selectedAssets = _selectedAssets; // 目前已经选中的图片数组
    
    _photpLibaryPickerVc.allowTakePicture = YES; // 在内部显示拍照按钮
    
    // 3. 设置是否可以选择视频/图片/原图
    _photpLibaryPickerVc.allowPickingVideo = NO;
    _photpLibaryPickerVc.allowPickingImage = YES;
    _photpLibaryPickerVc.allowPickingOriginalPhoto = NO;
    _photpLibaryPickerVc.allowPickingGif = NO;
    _photpLibaryPickerVc.allowPickingMultipleVideo = NO; // 是否可以多选视频
    
    // 4. 照片排列按修改时间升序
    _photpLibaryPickerVc.sortAscendingByModificationDate = YES;
    
    // 5. 单选模式,maxImagesCount为1时才生效
    _photpLibaryPickerVc.showSelectBtn = NO;
    _photpLibaryPickerVc.allowCrop = YES;
    _photpLibaryPickerVc.needCircleCrop = NO;
    // 设置竖屏下的裁剪尺寸
    NSInteger left = 30;
    NSInteger widthHeight = self.view.tz_width - 2 * left;
    NSInteger top = (self.view.tz_height - widthHeight) / 2;
    _photpLibaryPickerVc.cropRect = CGRectMake(left, top, widthHeight, widthHeight);
    // 设置横屏下的裁剪尺寸
    // imagePickerVc.cropRectLandscape = CGRectMake((self.view.tz_height - widthHeight) / 2, left, widthHeight, widthHeight);
    /*
     [imagePickerVc setCropViewSettingBlock:^(UIView *cropView) {
     cropView.layer.borderColor = [UIColor redColor].CGColor;
     cropView.layer.borderWidth = 2.0;
     }];*/
    
    //imagePickerVc.allowPreview = NO;
    // 自定义导航栏上的返回按钮
    
     [_photpLibaryPickerVc setNavLeftBarButtonSettingBlock:^(UIButton *leftButton){
     [leftButton setImage:[UIImage imageNamed:@"RLPublic_icon_back"] forState:UIControlStateNormal];
     [leftButton setImageEdgeInsets:UIEdgeInsetsMake(0, -10, 0, 20)];
     }];
     _photpLibaryPickerVc.delegate = self;
    
    
    // Deprecated, Use statusBarStyle
    // imagePickerVc.isStatusBarDefault = NO;
//    _photpLibaryPickerVc.statusBarStyle = UIStatusBarStyleLightContent;
    
//    imagePickerVc.preferredLanguage = @"zh-Hans";
    
    // You can get the photos by block, the same as by delegate.
    // 你可以通过block或者代理，来得到用户选择的照片.
    [_photpLibaryPickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        
    }];
    
    [self presentViewController:_photpLibaryPickerVc animated:YES completion:nil];
}

#pragma mark - UIImagePickerController

- (void)takePhoto {
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if ((authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied) && iOS7Later) {
        // 无相机权限 做一个友好的提示
        if (iOS8Later) {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"无法使用相机" message:@"请在iPhone的""设置-隐私-相机""中允许访问相机" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"设置", nil];
            [alert show];
        } else {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"无法使用相机" message:@"请在iPhone的""设置-隐私-相机""中允许访问相机" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
        }
    } else if (authStatus == AVAuthorizationStatusNotDetermined) {
        // fix issue 466, 防止用户首次拍照拒绝授权时相机页黑屏
        if (iOS7Later) {
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                if (granted) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self takePhoto];
                    });
                }
            }];
        } else {
            [self takePhoto];
        }
        // 拍照之前还需要检查相册权限
    } else if ([TZImageManager authorizationStatus] == 2) { // 已被拒绝，没有相册权限，将无法保存拍的照片
        if (iOS8Later) {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"无法访问相册" message:@"请在iPhone的""设置-隐私-相册""中允许访问相册" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"设置", nil];
            [alert show];
        } else {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"无法访问相册" message:@"请在iPhone的""设置-隐私-相册""中允许访问相册" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
        }
    } else if ([TZImageManager authorizationStatus] == 0) { // 未请求过相册权限
        [[TZImageManager manager] requestAuthorizationWithCompletion:^{
            [self takePhoto];
        }];
    } else {
        [self pushImagePickerController];
    }
}

// 调用相机
- (void)pushImagePickerController {
    // 提前定位
//    __weak typeof(self) weakSelf = self;
//    [[TZLocationManager manager] startLocationWithSuccessBlock:^(NSArray<CLLocation *> *locations) {
//        __strong typeof(weakSelf) strongSelf = weakSelf;
//        strongSelf.location = [locations firstObject];
//    } failureBlock:^(NSError *error) {
//        __strong typeof(weakSelf) strongSelf = weakSelf;
//        strongSelf.location = nil;
//    }];
    
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
        self.imagePickerVc.sourceType = sourceType;
        if(iOS8Later) {
            _imagePickerVc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        }
        [self presentViewController:_imagePickerVc animated:YES completion:nil];
    } else {
        RLLog(@"模拟器中无法打开照相机,请在真机中使用");
    }
}

- (void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSString *type = [info jk_stringForKey:UIImagePickerControllerMediaType];
    if ([type isEqualToString:@"public.image"]) {
        TZImagePickerController *tzImagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:1 delegate:self];
        tzImagePickerVc.sortAscendingByModificationDate = YES;
        [tzImagePickerVc showProgressHUD];
        UIImage *image = (UIImage *)[info objectForKey:UIImagePickerControllerOriginalImage];
        
        // save photo and get asset / 保存图片，获取到asset
        [[TZImageManager manager] savePhotoWithImage:image location:self.location completion:^(NSError *error){
            if (error) {
                [tzImagePickerVc hideProgressHUD];
                RLLog(@"图片保存失败 %@",error);
            } else {
                [[TZImageManager manager] getCameraRollAlbum:NO allowPickingImage:YES needFetchAssets:NO completion:^(TZAlbumModel *model) {
                    [[TZImageManager manager] getAssetsFromFetchResult:model.result allowPickingVideo:NO allowPickingImage:YES completion:^(NSArray<TZAssetModel *> *models) {
                        [tzImagePickerVc hideProgressHUD];
                        TZAssetModel *assetModel = [models firstObject];
                        if (tzImagePickerVc.sortAscendingByModificationDate) {
                            assetModel = [models lastObject];
                        }
                        
                        [self refreshCollectionViewWithAddedAsset:assetModel.asset image:image];
                        
                    }];
                }];
            }
        }];
    }
}

#pragma mark - UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) { // take photo / 去拍照
        [self takePhoto];
    } else if (buttonIndex == 1) {
        [self pushTZImagePickerController];
    }
}

#pragma mark - TZImagePickerControllerDelegate

/// User click cancel button
/// 用户点击了取消
- (void)tz_imagePickerControllerDidCancel:(TZImagePickerController *)picker {
    // RLLog(@"cancel");
}

// The picker should dismiss itself; when it dismissed these handle will be called.
// If isOriginalPhoto is YES, user picked the original photo.
// You can get original photo with asset, by the method [[TZImageManager manager] getOriginalPhotoWithAsset:completion:].
// The UIImage Object in photos default width is 828px, you can set it by photoWidth property.
// 这个照片选择器会自己dismiss，当选择器dismiss的时候，会执行下面的代理方法
// 如果isSelectOriginalPhoto为YES，表明用户选择了原图
// 你可以通过一个asset获得原图，通过这个方法：[[TZImageManager manager] getOriginalPhotoWithAsset:completion:]
// photos数组里的UIImage对象，默认是828像素宽，你可以通过设置photoWidth属性的值来改变它
- (void)imagePickerController:(TZImagePickerController *)picker didFinishPickingPhotos:(NSArray<UIImage *> *)photos sourceAssets:(NSArray *)assets isSelectOriginalPhoto:(BOOL)isSelectOriginalPhoto infos:(NSArray<NSDictionary *> *)infos {
    _showPhotos = [NSMutableArray arrayWithArray:photos];
    _selectedAssets = [NSMutableArray arrayWithArray:assets];
    _isSelectOriginalPhoto = isSelectOriginalPhoto;
    [_addPhotoCollectionView reloadData];
    _selectedPhotos = [NSMutableArray array];
    
    for (UIImage *image1 in photos) {
        [UIImage jk_compressImage:image1 toMaxLength:256*1024 maxWidth:image1.size.width imageBlock:^(NSData *newImage) {
            [_selectedPhotos addObject:newImage];
        }];
    }

    
    if (iOS8Later) {
        for (PHAsset *phAsset in assets) {
            RLLog(@"location:%@",phAsset.location);
        }
    }
}

#pragma mark - Click Event

- (void)deleteBtnClik:(UIButton *)sender {
    [_selectedPhotos removeObjectAtIndex:sender.tag];
    [_selectedAssets removeObjectAtIndex:sender.tag];
    [_showPhotos removeObjectAtIndex:sender.tag];
    [_addPhotoCollectionView reloadData];
//    [_addPhotoCollectionView performBatchUpdates:^{
//        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:sender.tag inSection:0];
//        [_addPhotoCollectionView deleteItemsAtIndexPaths:@[indexPath]];
//    } completion:^(BOOL finished) {
//        [_addPhotoCollectionView reloadData];
//    }];
}

//-(NSData *)scaleImage:(UIImage *)image toKb:(NSInteger)kb{
//
//    if (!image) {
//        return UIImageJPEGRepresentation(image, 1);
//    }
//    if (kb<1) {
//        return UIImageJPEGRepresentation(image, 1);
//    }
//
//    kb*=1024;
//
//    CGFloat compression = 1.0f;
//    NSData *imageData = UIImageJPEGRepresentation(image, 1);
//    float imageLength = [[NSNumber numberWithInteger:imageData.length] doubleValue];
//    float LimitLength =  [[NSNumber numberWithInteger:kb] doubleValue];
//    if (imageLength > LimitLength) {
//        compression = LimitLength/imageLength;
//        imageData = UIImageJPEGRepresentation(image, compression);
//    }
//    RLLog(@"当前大小:%fkb",(float)[imageData length]/1024.0f);
//    return imageData;
//}

@end
