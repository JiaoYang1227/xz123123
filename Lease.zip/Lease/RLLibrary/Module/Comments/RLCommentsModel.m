//
//  RLCommentsModel.m
//  RLLibrary
//
//  Created by sun on 2018/3/8.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLCommentsModel.h"
#import "RLConstant.h"
@implementation RLCommentsModel
+ (void)mobilityEvaluate:(NSDictionary *)param
               imageList:(NSArray *)imageList
                 success:(void(^)(BOOL success,NSString *message))success
                  falure:(void(^)(NSError *error))falure
{
     NSString *urlWithSign = [NSString stringWithFormat:@"%@?sign=%@",URI_INTERFACES_MOBILITY_EVALUATE,[RLAPIManager getSignCheckContentV1:param withURL:URI_INTERFACES_MOBILITY_EVALUATE]];
    RLAPIManager *manager = [RLAPIManager sharedManager];

    [manager POST:urlWithSign parameters:param constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if (imageList.count>0) {
            [formData appendPartWithFileData:[imageList objectAtIndex:0] name:@"picone" fileName:@"picone.jpg" mimeType:@"image/jpeg"];
        }
        if (imageList.count>1) {
            [formData appendPartWithFileData:[imageList objectAtIndex:1] name:@"pictwo" fileName:@"pictwo.jpg" mimeType:@"image/jpeg"];
        }
        if (imageList.count>2) {
            [formData appendPartWithFileData:[imageList objectAtIndex:2] name:@"picthree" fileName:@"picthree.jpg" mimeType:@"image/jpeg"];
        }
        if (imageList.count>3) {
            [formData appendPartWithFileData:[imageList objectAtIndex:3] name:@"picfour" fileName:@"picfour.jpg" mimeType:@"image/jpeg"];
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success(YES,nil);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        falure(error);
    }];
}
+ (void)evaluateByOrderNumbers:(NSString *)orderNumbers
                       success:(void(^)(NSDictionary *result,NSString *message))success
                        falure:(void(^)(NSError *error))falure{
    [RLAPIManager SafeGET:URI_INTERFACES_EVALUATE parameters:@{@"orderNumbers":orderNumbers?:@""} success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success([responseObject jk_dictionaryForKey:@"result"],nil);
        }else{
            success(nil,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}

+ (void)grantMagicBean:(NSDictionary *)param
         success:(void(^)(BOOL success,NSString *message))success
          falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafePOST:URI_INTERFACES_GRANT_MAGIC_BEAN parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        
        if ([@"SUCCEED"isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            success(YES,[responseObject jk_stringForKey:@"message"]);
        }else{
            success(nil,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}

@end
