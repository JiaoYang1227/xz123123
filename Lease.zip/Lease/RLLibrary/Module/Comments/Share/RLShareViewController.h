//
//  RLShareViewController.h
//  RLLibrary
//
//  Created by Cluy on 2018/5/23.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OpenShareHeader.h"
typedef void(^ShareDone)(BOOL success);
@interface RLShareViewController : UIViewController
@property(nonatomic,copy)NSString *aid;
@property(nonatomic,copy)NSString *orderNo;
@property (nonatomic,copy) ShareDone shareDone;

/**
 分享到微信

 @param url url
 @param title 标题
 @param desc 描述
 @param image 图片
 @param shareDone 分享状态
 */
+(void)shareWeixinWithUrl:(NSString *)url title:(NSString *)title desc:(NSString *)desc image:(UIImage *)image shareDone:(ShareDone)shareDone;
/**
 分享到朋友圈
 
 @param url url
 @param title 标题
 @param desc 描述
 @param image 图片
 @param shareDone 分享状态
 */
+(void)sharePengyouquanWithUrl:(NSString *)url title:(NSString *)title desc:(NSString *)desc image:(UIImage *)image shareDone:(ShareDone)shareDone;
@end
