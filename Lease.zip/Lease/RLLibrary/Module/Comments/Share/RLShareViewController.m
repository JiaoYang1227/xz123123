//
//  RLShareViewController.m
//  RLLibrary
//
//  Created by Cluy on 2018/5/23.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLShareViewController.h"
#import "UIViewController+JKPopup.h"
#import "JKAlert.h"
#import "RLInclude.h"
#import "RLCommentsModel.h"
#import "RLFileManager.h"
#import "RLOperationModel.h"
#import "DateManager.h"
#import "RLMicro.h"
#import "LogWriter.h"
@interface RLShareViewController ()

@end

@implementation RLShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [LogWriter uploadLog];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
 
-(void)backWithShareSuccess:(BOOL)success{
    if (self.shareDone) {
        self.shareDone(success);
    }
    [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
    }];
}
- (IBAction)sharePengyouquan:(id)sender {
    
    if ([OpenShare isWeixinInstalled]) {
        
        OSMessage *msg=[[OSMessage alloc]init];
        
        msg.title= @"摩捷出行";
        msg.desc = @"";
        msg.image = [UIImage RLImageNamed:@"RLShare_info.jpg"];
        msg.thumbnail = nil;
    
        [LogWriter writeLog:@"分享朋友圈魔豆发放"
                     detail:@""
                   inParams:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} outParams:nil];
        
        
        [RLCommentsModel grantMagicBean:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} success:^(BOOL success, NSString *message) {
            if (success) {
            
                [LogWriter writeLog:@"分享朋友圈魔豆发放"
                             detail:@"发放成功"
                           inParams:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} outParams:@{@"message":message?:@""}];
                
            }else{
                [LogWriter writeLog:@"分享朋友圈魔豆发放"
                             detail:@"发放失败"
                           inParams:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} outParams:@{@"message":message?:@""}];
                [JKAlert showMessage:message];
            }
            [self backTouched:nil];
        } falure:^(NSError *error) {
            [LogWriter writeLog:@"分享朋友圈魔豆发放"
                         detail:@"网络请求失败"
                       inParams:nil outParams:@{@"error":error.debugDescription?:@""}];
            [self backTouched:nil];
        }];
        [OpenShare shareToWeixinTimeline:msg Success:^(OSMessage *message) {
            RLLog(@"分享到微信朋友圈成功：\n%@",message);
            [self backWithShareSuccess:YES];
        } Fail:^(OSMessage *message, NSError *error) {
            RLLog(@"分享到微信朋友圈失败：\n%@\n%@",error,message);
            [self backWithShareSuccess:NO];
            
        }];
        
    }else{
        [JKAlert showMessage:@"未安装微信"];
        [self backWithShareSuccess:NO];
    }
   
}
- (IBAction)shareWeixin:(id)sender {
    
    if ([OpenShare isWeixinInstalled]) {
        OSMessage *msg=[[OSMessage alloc]init];
        msg.title= @"摩捷出行";
        msg.desc = @"";
        msg.image = [UIImage RLImageNamed:@"RLShare_info.jpg"];
        msg.thumbnail = nil;
       
        [LogWriter writeLog:@"分享微信魔豆发放"
                     detail:@""
                   inParams:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} outParams:nil];
        [RLCommentsModel grantMagicBean:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} success:^(BOOL success, NSString *message) {
           
            if (success) {
                [LogWriter writeLog:@"分享微信魔豆发放"
                             detail:@"发放成功"
                           inParams:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} outParams:@{@"message":message?:@""}];
            }else{
                [LogWriter writeLog:@"分享朋友圈魔豆发放"
                             detail:@"发放失败"
                           inParams:@{@"aid":self.aid?:@"",@"orderNo":self.orderNo?:@""} outParams:@{@"message":message?:@""}];
                [JKAlert showMessage:message];
            }
             [self backTouched:nil];
        } falure:^(NSError *error) {
            [LogWriter writeLog:@"分享朋友圈魔豆发放"
                         detail:@"网络请求失败"
                       inParams:nil outParams:@{@"error":error.debugDescription?:@""}];
            [self backTouched:nil];
        }];
        [OpenShare shareToWeixinSession:msg Success:^(OSMessage *message) {
            RLLog(@"分享到微信成功：\n%@",message);
            [self backWithShareSuccess:YES];
        } Fail:^(OSMessage *message, NSError *error) {
            RLLog(@"分享到微信失败：\n%@\n%@",error,message);
            [self backWithShareSuccess:NO];
            
        }];
        
        
        
    }else{
        [JKAlert showMessage:@"未安装微信"];
        [self backWithShareSuccess:NO];
    }
}
+(void)shareWeixinWithUrl:(NSString *)url title:(NSString *)title desc:(NSString *)desc image:(UIImage *)image shareDone:(ShareDone)shareDone{
    if ([OpenShare isWeixinInstalled]) {
        OSMessage *msg=[[OSMessage alloc]init];
        msg.title= title;
        msg.desc = desc;
        msg.image = image;
        msg.thumbnail = nil;
        msg.link = url;
        [OpenShare shareToWeixinSession:msg Success:^(OSMessage *message) {
            RLLog(@"分享到微信成功：\n%@",message);
            shareDone(YES);
        } Fail:^(OSMessage *message, NSError *error) {
            RLLog(@"分享到微信失败：\n%@\n%@",error,message);
            shareDone(NO);
            
        }];
    }else{
        [JKAlert showMessage:@"未安装微信"];
        shareDone(NO);
    }
}
+(void)sharePengyouquanWithUrl:(NSString *)url title:(NSString *)title desc:(NSString *)desc image:(UIImage *)image shareDone:(ShareDone)shareDone{
    if ([OpenShare isWeixinInstalled]) {
        
        OSMessage *msg=[[OSMessage alloc]init];
        msg.title= title;
        msg.desc = desc;
        msg.image = image;
        msg.thumbnail = nil;
        msg.link = url;
        [OpenShare shareToWeixinTimeline:msg Success:^(OSMessage *message) {
            RLLog(@"分享到微信朋友圈成功：\n%@",message);
            shareDone(YES);
        } Fail:^(OSMessage *message, NSError *error) {
            RLLog(@"分享到微信朋友圈失败：\n%@\n%@",error,message);
            shareDone(NO);
            
        }];
    }else{
        [JKAlert showMessage:@"未安装微信"];
        shareDone(NO);
    }
}
- (IBAction)shareWeibo:(id)sender {
    if ([OpenShare isWeiboInstalled]) {
        OSMessage *msg=[[OSMessage alloc]init];
        msg.title= self.title?:@"";
        //    msg.link = self.link?:@"";
        msg.desc = self.title?:@"";
        msg.image=[UIImage imageNamed:@"AppIcon"];
        [OpenShare shareToWeibo:msg Success:^(OSMessage *message) {
            RLLog(@"分享到微博成功：\n%@",message);
            [self backWithShareSuccess:YES];
        } Fail:^(OSMessage *message, NSError *error) {
            RLLog(@"分享到微博失败：\n%@\n%@",error,message);
            [self backWithShareSuccess:NO];
            
        }];
    }else{
        [JKAlert showMessage:@"未安装微博"];
        [self backWithShareSuccess:NO];
    }
}
- (IBAction)shareQQ:(id)sender {
    if ([OpenShare isQQInstalled]) {
        OSMessage *msg=[[OSMessage alloc]init];
        msg.title= self.title?:@"";
        //    msg.link = self.link?:@"";
        msg.desc = self.title?:@"";
        msg.image=[UIImage imageNamed:@"AppIcon"];
        [OpenShare shareToQQFriends:msg Success:^(OSMessage *message) {
            RLLog(@"分享到QQ成功：\n%@",message);
            [self backWithShareSuccess:YES];
        } Fail:^(OSMessage *message, NSError *error) {
            RLLog(@"分享到QQ失败：\n%@\n%@",error,message);
            [self backWithShareSuccess:NO];
        }];
    }else{
        [JKAlert showMessage:@"未安装QQ"];
        [self backWithShareSuccess:NO];
    }
}
- (IBAction)backTouched:(id)sender {
    [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
    }];
    if(self.parentViewController.navigationController){
        [self.parentViewController.navigationController popViewControllerAnimated:YES];
    }else{
        [self.parentViewController dismissViewControllerAnimated:YES completion:nil];
    }
    
}
@end
