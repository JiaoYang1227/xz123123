//
//  RLOperationModel.h
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"

@interface RLOperationModel : RLBaseModel

+ (void)controlCar:(NSDictionary *)param
                           success:(void(^)(BOOL success,NSString *message))success
                            falure:(void(^)(NSError *error))falure;
+ (void)printLogBluetooth:(NSDictionary *)param
           success:(void(^)(BOOL success,NSString *message))success
            falure:(void(^)(NSError *error))falure;

@end
