//
//  RLOperationModel.m
//  RLLibrary
//
//  Created by sun on 2018/3/9.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLOperationModel.h"

@implementation RLOperationModel
//01，闪灯；02，鸣笛；03，打火；04，熄火；05，锁车；06，开锁；
+ (void)controlCar:(NSDictionary *)param
                           success:(void(^)(BOOL success,NSString *message))success
                            falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafePOST:URI_INTERFACES_CONTROL_CAR parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success(YES,[responseObject jk_stringForKey:@"message"]);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
+ (void)printLogBluetooth:(NSDictionary *)param
                  success:(void(^)(BOOL success,NSString *message))success
                   falure:(void(^)(NSError *error))falure{
    [RLAPIManager SafePOST:URI_INTERFACES_PRINTLOG_BLUETOOTH parameters:param success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {
            success(YES,[responseObject jk_stringForKey:@"message"]);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
@end
