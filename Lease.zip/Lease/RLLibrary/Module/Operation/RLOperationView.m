//
//  RLOperationView.m
//  RLLibrary
//
//  Created by sun on 2018/3/7.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLOperationView.h"
#import "RLOperationModel.h"
#import "JKAlert.h"
#import <SVProgressHUD.h>
#import "NSDictionary+JKSafeAccess.h"
#import "RLInclude.h"
#import <UIImage+GIF.h>
#import "RLLocationManager.h"
#import "ReturnCarModel.h"
#import <RGBleSDK/RGBleSDK.h>
#import "RLChangeOrderStatusModel.h"
#import "RLFileManager.h"
#import "DateManager.h"
#import "NSDictionary+JSONString.h"
#import "NSTimer+UsingBlock.h"
#import "RLOperationManager.h"
#import "UIViewController+JKPopup.h"
#import "LogWriter.h"
#import "RDToast.h"
#import "RLReturnCarViewController.h"
#import "RLMicro.h"
@implementation RLOperationView{
    NSMutableArray *_arrayBtn;
    NSMutableArray *_arrayLB;
    NSArray *_arrayName;
    BOOL _bluetoothSuccess;
    //    NSString *_authKey;
    NSTimer *_countDownTimer;
    NSTimer *_BluetoothCountDownTimer;
    UIButton *_btnDH;//点火
    UIButton *_btnXH;//熄火
    UIButton *_btnKS;//开锁
    UIButton *_btnSM;//锁门
    UIButton *_btnMD;//鸣笛
    UIButton *_btnSD;//闪灯
    UIButton *_btnLY;//蓝牙
    UILabel *_labLY;//蓝牙
    UIButton *_btnHC;//还车
    NSDate *_lastClickTime;
    UIImage *_hubImage;
}
-(UIImage*)loadHubImag{
    if(_hubImage==nil){
        NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
        NSData *data = [NSData dataWithContentsOfFile:path];
        _hubImage = [UIImage sd_animatedGIFWithData:data];
    }
    return _hubImage;
}
- (instancetype)initWithFrame:(CGRect)frame
                  orderNumber:(NSString *)orderNumber
                          vin:(NSString *)vin
                       userid:(NSString *)userid
             isJumpThePayment:(ISJumpThePayment)isJumpThePayment
{
    self = [super initWithFrame:frame];
    if (self) {
        _bluetoothSuccess = NO;
        [self setOrderNumber:orderNumber vin:vin userid:userid isJumpThePayment:self.jumpThePayment];
        [self buidView];
        
    }
    return self;
}
//+(void)uploadLog{
//    NSArray *arr = [RLFileManager fetchPlist];
//    if (arr.count>0) {
//        NSString *title = [NSString string];
//        title = @"iOS";
//        for (NSString *str in arr) {
//            title = [title stringByAppendingString:[NSString stringWithFormat:@"%@%@",@"\n",str]];
//        }
//        [RLOperationModel printLogBluetooth:@{@"log":title?:@""} success:^(BOOL success, NSString *message) {
//            if (success) {
//                [RLFileManager deletePlist];
//            }
//        } falure:^(NSError *error) {
//            
//        }];
//    }
//}
-(void)setOrderNumber:(NSString *)orderNumber
                  vin:(NSString *)vin
               userid:(NSString *)userid
     isJumpThePayment:(ISJumpThePayment)isJumpThePayment{
    
    self.multipleTouchEnabled = false;
    
//    [self.centralManager scanForPeripheralsWithServices:nil options:@{CBCentralManagerRestoredStateScanOptionsKey:@(YES)}];
    self.vin = vin;
    self.orderNumber = orderNumber;
    self.userid = userid;
    self.jumpThePayment = [isJumpThePayment copy];
    //!!!!!!面板可点击
    self.userInteractionEnabled = YES;
    [LogWriter uploadLog];

    
    [LogWriter writeLog:@"setOrderNumber"
                 detail:@""
               inParams:@{@"orderNumber":orderNumber?:@"",@"vin":vin?:@"",@"userid":userid?:@""} outParams:nil];
    
    if (!self.vin||[@"" isEqualToString:self.vin]||
        !self.orderNumber||[@"" isEqualToString:self.orderNumber]||
        !self.userid||[@""isEqualToString:self.userid]) {
        
        [LogWriter writeLog:@"setOrderNumber"
                     detail:@"参数有空值"
                   inParams:@{@"orderNumber":orderNumber?:@"",@"vin":vin?:@"",@"userid":userid?:@""} outParams:nil];
        
        RLLog(@"没有vin,和orderNumber,userid,请调用这个方法-(void)setOrderNumber:(NSString *)orderNumber vin:(NSString *)vin userid:(NSString *)userid");
    }
    //        if (_bluetoothSuccess !=YES) {
    [self.centralManager stopScan];
    //        }
    [_countDownTimer invalidate];
    [_BluetoothCountDownTimer invalidate];
    if ((![[RLOperationManager sharedManager].vin isEqualToString:self.vin]||![[RLOperationManager sharedManager].userid isEqualToString:self.userid])) {
        [RLOperationManager sharedManager].authKey = nil;
     
        
        [LogWriter writeLog:@"setOrderNumber"
                     detail:@"vin或者userid不匹配重新获取authkey"
                   inParams:@{@"orderNumber":orderNumber?:@"",@"vin":vin?:@"",@"userid":userid?:@""} outParams:nil];
        
    }
    if (![RLOperationManager sharedManager].authKey) {
        
        if (![@"" isEqualToString:self.vin]&&![@""isEqualToString:self.userid]) {
            [LogWriter writeLog:@"setOrderNumber"
                         detail:@"没有key轮询获取key"
                       inParams:nil outParams:nil];
            __weak typeof(self) weakSelf = self;
            _countDownTimer = [NSTimer  ub_scheduledTimerWithTimeInterval:5.0 block:^{
                [weakSelf getAuthKeyAndBluetoothLink];
                
            } repeats:YES];
            
            [[NSRunLoop currentRunLoop]addTimer:_countDownTimer forMode:NSRunLoopCommonModes];
        }
    }else{
        if (_bluetoothSuccess == YES&&[[RGBleController shareController]connectingStatus] ==RGBleStatusDisConnected) {
            __weak typeof(self) weakSelf = self;
        
            [LogWriter writeLog:@"setOrderNumber"
                         detail:@"未连接,轮询控车连接"
                       inParams:nil outParams:nil];
            
            _BluetoothCountDownTimer = [NSTimer  ub_scheduledTimerWithTimeInterval:5.0 block:^{
                [weakSelf bluetoothLink];
                
            } repeats:YES];
            
            [[NSRunLoop currentRunLoop]addTimer:_BluetoothCountDownTimer forMode:NSRunLoopCommonModes];
            
            //                    _BluetoothCountDownTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(bluetoothLink) userInfo:nil repeats:YES];
        }else{
            [LogWriter writeLog:@"setOrderNumber"
                         detail:@"centralManager stopScan"
                       inParams:nil outParams:nil];
            [self.centralManager stopScan];
        }
    }
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self buidView];
}
-(void)buidView{
    
    _arrayBtn = [NSMutableArray array];
    _arrayLB = [NSMutableArray array];
    [self CreateButton];
}
#pragma mark - 创建按钮
-(void)CreateButton{
//    _arrayName = @[@{@"id":@"02",@"name":@"鸣笛",@"imageName":@"RLOperationView_btn_whistle"},
//                   @{@"id":@"06",@"name":@"开锁",@"imageName":@"RLOperationView_btn_lock"},
//                   @{@"id":@"03",@"name":@"点火",@"imageName":@"RLOperationView_btn_ignition"},
//                   @{@"id":@"01",@"name":@"闪灯",@"imageName":@"RLOperationView_btn_flash light"},
//                   @{@"id":@"05",@"name":@"锁门",@"imageName":@"RLOperationView_btn_unlock"},
//                   @{@"id":@"04",@"name":@"熄火",@"imageName":@"RLOperationView_btn_flameout"}];
//    for (int i = 0; i < 6; i++) {
//        UIButton *btn= [[UIButton alloc]init];
//        [btn setTag:i];
//        //        [btn setTitle:[[_arrayName objectAtIndex:i] jk_stringForKey:@"name"] forState:UIControlStateNormal];
//        //        [btn setBackgroundColor:[UIColor blackColor]];
//        [btn setTitleColor:[UIColor colorWithRed:29.0/255.0 green:139.0/255.0 blue:241.0/255.0 alpha:1] forState:UIControlStateNormal];
//        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
//        [btn setImage:[UIImage RLImageNamed:[NSString stringWithFormat:@"%@_nor",[[_arrayName objectAtIndex:i] jk_stringForKey:@"imageName"]]] forState:UIControlStateNormal];
//        [btn setImage:[UIImage RLImageNamed:[NSString stringWithFormat:@"%@_pes",[[_arrayName objectAtIndex:i] jk_stringForKey:@"imageName"]]] forState:UIControlStateHighlighted];
//
//
//        [btn addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
//        [self addSubview:btn];
//        [_arrayBtn addObject:btn];
//
//        UILabel *title= [[UILabel alloc]init];
//        title.text = [[_arrayName objectAtIndex:i] jk_stringForKey:@"name"];
//        title.textAlignment = NSTextAlignmentCenter;
//        [title setFont:[UIFont systemFontOfSize:13]];
//        [self addSubview:title];
//        [_arrayLB addObject:title];
//    }
    _arrayName = @[@{@"id":@"02",@"name":@"鸣笛"},
                   @{@"id":@"06",@"name":@"开锁"},
                   @{@"id":@"03",@"name":@"点火"},
                   @{@"id":@"01",@"name":@"闪灯"},
                   @{@"id":@"05",@"name":@"锁门"},
                   @{@"id":@"04",@"name":@"熄火"}];

    _btnMD = [[UIButton alloc]init];
    [_btnMD setImage:[UIImage RLImageNamed:@"RLOperation_md.png"] forState:UIControlStateNormal];
    [_btnMD setTag:0];
    [_btnMD addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnMD];
    
    _btnKS = [[UIButton alloc]init];
    [_btnKS setImage:[UIImage RLImageNamed:@"RLOperation_ks.png"] forState:UIControlStateNormal];
    [_btnKS setTag:1];
    [_btnKS addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnKS];
    
    _btnDH = [[UIButton alloc]init];
    [_btnDH setImage:[UIImage RLImageNamed:@"RLOperation_dh.png"] forState:UIControlStateNormal];
    [_btnDH setTag:2];
    [_btnDH addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnDH];
    
    _btnSD = [[UIButton alloc]init];
    [_btnSD setImage:[UIImage RLImageNamed:@"RLOperation_sd.png"] forState:UIControlStateNormal];
    [_btnSD setTag:3];
    [_btnSD addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnSD];
    
    _btnSM = [[UIButton alloc]init];
    [_btnSM setImage:[UIImage RLImageNamed:@"RLOperation_sm.png"] forState:UIControlStateNormal];
    [_btnSM setTag:4];
    [_btnSM addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnSM];
    
    _btnXH = [[UIButton alloc]init];
    [_btnXH setImage:[UIImage RLImageNamed:@"RLOperation_xh.png"] forState:UIControlStateNormal];
    [_btnXH setTag:5];
    [_btnXH addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnXH];
    
    _btnLY = [[UIButton alloc]init];
    [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wkq.png"] forState:UIControlStateNormal];
    [_btnLY addTarget:self action:@selector(getAuthKeyAndBluetoothLink) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnLY];
    _labLY = [[UILabel alloc]init];
//    [_btnLY setBackgroundColor:[UIColor redColor]];
    _labLY.text = @"未连接";
    [_labLY setTextAlignment:NSTextAlignmentCenter];
    [_labLY setFont:[UIFont systemFontOfSize:10]];
      [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];;
    [self addSubview:_labLY];
    
    
    _btnHC = [[UIButton alloc]init];
    [_btnHC setImage:[UIImage RLImageNamed:@"RLOperation_hc.png"] forState:UIControlStateNormal];
    [_btnHC addTarget:self action:@selector(returnCar:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_btnHC];
    [self changeFrame];
}
//还车
-(void)returnCar:(UIButton *)sender{
    if (_lastClickTime&&[[NSDate date] timeIntervalSinceDate:_lastClickTime]<3) {
        RLLog(@"1111111%f",[[NSDate date] timeIntervalSinceDate:_lastClickTime]);
        _lastClickTime = [NSDate date];
        [RDToast showWithText:@"您的操作过于频繁，请稍后再试"];
        return;
    }
    _lastClickTime = [NSDate date];
     _btnHC.enabled = NO;
    [self gotoReturnCar];
}
-(void)gotoReturnCar{
        __weak typeof(self) weakSelf = self;
    
        RLReturnCarViewController *returnCar = [[RLReturnCarViewController alloc] initWithNibName:@"RLReturnCarViewController" bundle:[NSBundle RLResourceBundle]];
        returnCar.vin = self.vin;
        returnCar.userid = self.userid;
        returnCar.orderNumber = self.orderNumber;
        [returnCar setReconnectBluetooth:^{
            __strong typeof(weakSelf)  strongSelf = weakSelf;
            if(strongSelf!=nil){
                [LogWriter writeLog:@"ReturnCarReconnectBluetooth"
                             detail:@""
                           inParams:@{} outParams:nil];
                [strongSelf bluetoothLink];
            }
        }];
    
        returnCar.jumpThePayment = ^(BOOL jump, NSDictionary *location, BOOL isOrder) {
        _btnHC.enabled = YES;
        if (isOrder) {
            self.userInteractionEnabled = NO;
        }else{
            if (jump == YES) {
                self.userInteractionEnabled = NO;
            }

            if (self.jumpThePayment) {
                self.jumpThePayment(jump,location);
            }
        }
        self.jumpThePayment(jump,location);
    };

    [[UIViewController topShowViewController]presentJKPopupViewController:returnCar];
    
    
//    [[UIViewController topShowViewController]
//     presentJKPopupViewController:[RLInclude getRLReturnCarViewControllerWithVin:self.vin userid:self.userid orderNumber:self.orderNumber isJumpThePayment:^(BOOL jump,NSDictionary *location) {
//        _btnHC.enabled = YES;
//        if (jump == YES) {
//            self.userInteractionEnabled = NO;
//        }
//        if (self.jumpThePayment) {
//            self.jumpThePayment(jump,location);
//        }
//    }]];
}
#pragma mark - 按钮动作
-(void)action:(UIButton *)sender{
    if (_lastClickTime&&[[NSDate date] timeIntervalSinceDate:_lastClickTime]<3) {
        RLLog(@"1111111%f",[[NSDate date] timeIntervalSinceDate:_lastClickTime]);
            _lastClickTime = [NSDate date];
            [RDToast showWithText:@"您的操作过于频繁，请稍后再试"];
            return;
    }
    _lastClickTime = [NSDate date];

    NSString *name = [[_arrayName jk_dictionaryWithIndex:sender.tag] jk_stringForKey:@"name"];
    
    
    [LogWriter writeLog:@"控车"
                 detail:name
               inParams:@{@"authKey":[RLOperationManager sharedManager].authKey?:@"",@"orderNumber":self.orderNumber?:@"",@"vin":self.vin?:@"",@"userid":self.userid?:@""} outParams:nil];
    [self.centralManager stopScan];
  
    if ([RLOperationManager sharedManager].authKey) {
        switch ([[RGBleController shareController]connectingStatus]) {//判断蓝牙连接状态
            case RGBleStatusDisConnected://未连接
            {
                
                [LogWriter writeLog:@"获取蓝牙状态"
                             detail:@"未连接"
                           inParams:nil outParams:nil];
                
                
                [self NetworkControlCar:sender.tag];
                //                if (_authKey) {
                //                    [self bluetoothLink];
                //                }else{
                //                    [self getAuthKeyAndBluetoothLink];
                //                }
                _labLY.text=@"未连接";
                 [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
                [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
            }
                break;
            case RGBleStatusConnecting://连接中
            {
                [LogWriter writeLog:@"获取蓝牙状态"
                             detail:@"连接中"
                           inParams:nil outParams:nil];
                
                [self NetworkControlCar:sender.tag];
                _labLY.text=@"连接中";
                  [_labLY setTextColor:[UIColor colorWithRed:0/255.0 green:83/255.0 blue:153/255.0 alpha:1]];
                [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_ljz.png"] forState:UIControlStateNormal];
            }
                break;
            case RGBleStatusConnected://已连接
            {
                [LogWriter writeLog:@"获取蓝牙状态"
                             detail:@"已连接"
                           inParams:nil outParams:nil];
                [self BluetoothControlCar:sender.tag];
                _labLY.text=@"已连接";
                  [_labLY setTextColor:[UIColor colorWithRed:0/255.0 green:83/255.0 blue:153/255.0 alpha:1]];
                [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_lj.png"] forState:UIControlStateNormal];
            }
                break;
            default:
                break;
        }
    }else{
        [self NetworkControlCar:sender.tag];
        //        [self getAuthKeyAndBluetoothLink];
    }
    
}
#pragma mark - 蓝牙连接
-(void)bluetoothLink{
    [LogWriter writeLog:@"蓝牙SDK连接"
                 detail:@"connectWithTicket"
               inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:nil];
    
    _labLY.text = @"连接中";
      [_labLY setTextColor:[UIColor colorWithRed:0/255.0 green:83/255.0 blue:153/255.0 alpha:1]];
    [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_ljz.png"] forState:UIControlStateNormal];
    if (![RLOperationManager sharedManager].authKey) {
        [_BluetoothCountDownTimer invalidate];
 
        [LogWriter writeLog:@"bluetoothLink"
                     detail:@"authkey为空返回"
                   inParams:nil outParams:nil];
        
        _labLY.text = @"未连接";
         [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
        [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
        return;
    }
   
    
    [[RGBleController shareController] connectWithTicket:[RLOperationManager sharedManager].authKey?:@"" result:^(BOOL isSuccess, RGBleError *error) {
        if (isSuccess) {
            RLLog(@"蓝牙控车连接成功");
            
            [LogWriter writeLog:@"蓝牙SDK连接"
                         detail:@"连接成功"
                       inParams:nil outParams:nil];
            
            [_BluetoothCountDownTimer invalidate];
            _labLY.text=@"已连接";
               [_labLY setTextColor:[UIColor colorWithRed:0/255.0 green:83/255.0 blue:153/255.0 alpha:1]];
            [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_lj.png"] forState:UIControlStateNormal];
        }else{
            RLLog(@"蓝牙控车连接isSuccess NO");
            [LogWriter writeLog:@"蓝牙SDK连接"
                         detail:@"连接失败"
                       inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:nil];
            _labLY.text=@"未连接";
             [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
            [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
        }
        if (error) {
            RLLog(@"error --- %@", error);
            
            RLLog(@"蓝牙控车连接 error");
            [LogWriter writeLog:@"蓝牙SDK连接"
                         detail:@"连接失败error"
                       inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:@{@"error":error.debugDescription?:@""}];
            _labLY.text=@"未连接";
             [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
            [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
        }
    }];
}
-(void)showLoading:(NSString*)name isNet:(BOOL)isNet{
    NSString *msg  = [NSString stringWithFormat:@"%@%@中...",isNet?@"网络":@"蓝牙",name];
    
    [SVProgressHUD setInfoImage:[self loadHubImag]];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    SVProgressHUD.backgroundColor = [UIColor whiteColor];
    [SVProgressHUD showInfoWithStatus:msg];
    [SVProgressHUD setImageViewSize:CGSizeMake(80, 53)];
    
}
-(void)showSuccessLoading:(NSString*)name isNet:(BOOL)isNet message:(NSString*)message{
    NSString *msg = [NSString stringWithFormat:@"%@%@成功",isNet?@"网络":@"蓝牙",name];
    [SVProgressHUD setMaximumDismissTimeInterval:3];
    [SVProgressHUD setInfoImage:[self loadHubImag]];
    [SVProgressHUD showInfoWithStatus:msg];
    
    [LogWriter writeLog:[NSString stringWithFormat:@"%@控车",isNet?@"网络":@"蓝牙"]
                 detail:msg
               inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:message?@{@"message":[message description]?:@""}:nil];
}

//网络控车网络请求失败
-(void)showNetFaildLoading:(NSString*)name error:(id)error isNetError:(BOOL)isNetError{
    [SVProgressHUD dismiss];
    
    
    //                    [JKAlert showMessage:@"网络连接失败,请重试!"];
    [SVProgressHUD setMaximumDismissTimeInterval:3];
    [SVProgressHUD setInfoImage:[self loadHubImag]];
    [SVProgressHUD showInfoWithStatus:[NSString stringWithFormat:@"网络%@失败...",name]];
    
    [LogWriter writeLog:@"网络控车"
                 detail:[NSString stringWithFormat:@"%@",isNetError?@"网络请求error":@"控车返回失败"]
               inParams:nil outParams:isNetError?@{@"error":error?:@""}:@{@"message":error?:@""}];
}
//蓝牙控车失败
-(void)showFaildLoading:(NSString*)name bleError:(RGBleError*)bleError index:(NSInteger)index{
    //失败
    NSString *msg = [NSString stringWithFormat:@"蓝牙%@exeFailed失败",name];
    
    [LogWriter writeLog:@"蓝牙控车"
                 detail:msg
               inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:@{@"error":bleError.debugDescription?:@""}];
    UIImage *hubImage = [self loadHubImag];
    RLLog(@"失败：%@", bleError.debugDescription);

    if ([RLOperationManager sharedManager].background == NO) {
        [SVProgressHUD setMaximumDismissTimeInterval:3];
        [SVProgressHUD setInfoImage:hubImage];
        [SVProgressHUD showInfoWithStatus:[NSString stringWithFormat:@"蓝牙%@失败",name]];
        if ([bleError code] != RGBleErrorRequestTimeoutCode) {//请求超时,不走网络控车
            [SVProgressHUD setMaximumDismissTimeInterval:3];
            [SVProgressHUD setInfoImage:hubImage];
             [SVProgressHUD showInfoWithStatus:[NSString stringWithFormat:@"蓝牙%@失败",name]];
            [LogWriter writeLog:@"蓝牙控车"
                         detail:@"请求失败,网络控车"
                       inParams:nil outParams:@{@"error":bleError.debugDescription?:@""}];
            [self NetworkControlCar:index];
        }else{
            [SVProgressHUD setMaximumDismissTimeInterval:3];
            [SVProgressHUD setInfoImage:hubImage];
            [SVProgressHUD showInfoWithStatus:[NSString stringWithFormat:@"%@超时请稍后再试",name]];
            [LogWriter writeLog:@"蓝牙控车"
                         detail:@"RGBleError RGBleErrorRequestTimeoutCode,不走网络控车,可能是连点操作"
                       inParams:@{@"authkey":[RLOperationManager sharedManager].authKey?:@""} outParams:@{@"error":bleError.debugDescription?:@""}];
        }
        
    }else{
        [LogWriter writeLog:@"蓝牙控车"
                     detail:@"is background"
                   inParams:nil outParams:nil];
    }
}
#pragma mark - 蓝牙控车
-(void)BluetoothControlCar:(NSInteger)index{
   
    
    [RLOperationManager sharedManager].background = NO;
    
    NSString *name = [[_arrayName jk_dictionaryWithIndex:index] jk_stringForKey:@"name"];
    [LogWriter writeLog:@"蓝牙控车"
                 detail:name
               inParams:@{@"authKey":[RLOperationManager sharedManager].authKey?:@"",@"orderNumber":self.orderNumber?:@"",@"vin":self.vin?:@"",@"userid":self.userid?:@""} outParams:nil];
     [self showLoading:name  isNet:NO];
    
    switch (index) {
        case 0:
        {
            [[RGBleController shareController] searchingCarWithExeSuccess:^(id result) {
                [self showSuccessLoading:name isNet:NO message:result];
            } exeFailed:^(RGBleError *bleError) {
                [self showFaildLoading:name bleError:bleError index:index];
            }];
            
        }
            break;
        case 1:
        {
            [[RGBleController shareController] unlockingWithExeSuccess:^(id result) {
                
                [LogWriter writeLog:@"蓝牙控车"
                             detail:[NSString stringWithFormat:@"unlockingWithExeSuccess:%@",[result description]]
                           inParams:nil outParams:nil];
                
                [self showSuccessLoading:name isNet:NO  message:result];

            } exeFailed:^(RGBleError *bleError) {
                [self showFaildLoading:name bleError:bleError index:index];
            }];
            
        }
            break;
        case 2:
        {
           
            [[RGBleController shareController] ignitionWithExeSuccess:^(id result) {
                [self showSuccessLoading:name isNet:NO  message:result];
            } exeFailed:^(RGBleError *bleError) {
                [self showFaildLoading:name bleError:bleError index:index];
            }];
            
        }
            break;
        case 3:
        {
            
            [[RGBleController shareController] lightFlickerWithExeSuccess:^(id result) {
                [self showSuccessLoading:name isNet:NO  message:result];

            } exeFailed:^(RGBleError *bleError) {
                [self showFaildLoading:name bleError:bleError index:index];
            }];
            
        }
            break;
        case 4:
        {
            [[RGBleController shareController] onlockingWithExeSuccess:^(id result) {
                [self showSuccessLoading:name isNet:NO  message:result];
            } exeFailed:^(RGBleError *bleError) {
                [self showFaildLoading:name bleError:bleError index:index];
            }];
        }
            break;
        case 5:
        {
           
            [[RGBleController shareController] flameoutWithExeSuccess:^(id result) {
                [self showSuccessLoading:name isNet:NO  message:result];

            } exeFailed:^(RGBleError *bleError) {
                [self showFaildLoading:name bleError:bleError index:index];

            }];
            
        }
            break;
        default:
            break;
    }
}

#pragma mark - 网络控车
-(void)NetworkControlCar:(NSInteger)index{
 
    NSString *name = [[_arrayName jk_dictionaryWithIndex:index] jk_stringForKey:@"name"];
    NSString *type = [[_arrayName objectAtIndex:index] jk_stringForKey:@"id"];

  
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.orderNumber?:@"" forKey:@"orderNumbers"];
    [param setValue:self.vin?:@"" forKey:@"vin"];
    [param setValue:self.userid?:@"" forKey:@"userid"];
    [param setValue:@"app" forKey:@"datafrom"];
    [param setValue:type?:@"" forKey:@"type"];
    
    [LogWriter writeLog:@"网络控车"
                 detail:name
               inParams:param outParams:nil];
    
    if (index == 0||index == 1||index == 3) {//距离判断
        
        [self getDistanceBlock:^(BOOL limit50) {
            if (limit50) {
                RLLog(@"%ld",(long)index);
                
                [self showLoading:name isNet:YES];
                
                [RLOperationModel controlCar:param success:^(BOOL success,NSString *message) {
                    if(success){
                        [self showSuccessLoading:name isNet:YES message:message];
                    }else{
                        [self showNetFaildLoading:name error:message isNetError:NO];
                    }

                } falure:^(NSError *error) {
                    [self showNetFaildLoading:name error:error.debugDescription isNetError:YES];
                }];
            }else{
                [LogWriter writeLog:@"getDistanceBlock"
                             detail:@"limit50 false"
                           inParams:nil outParams:nil];
            }
        }];
    }else{
        [self showLoading:name isNet:YES];

        [RLOperationModel controlCar:param success:^(BOOL success,NSString *message) {
            if(success){
                [self showSuccessLoading:name isNet:YES message:message];
            }else{
                [self showNetFaildLoading:name error:message isNetError:NO];
            }
        } falure:^(NSError *error) {
            [self showNetFaildLoading:name error:error.debugDescription isNetError:YES];

        }];
    }
}
-(void)changeFrame{
//    float width = 0;
//    float height = 0;
//    float xSpacing = 0;
//    float ySpacing = 0;
//
//    width = self.frame.size.width*0.21;
//    height = self.frame.size.height*0.26;
//    xSpacing = (self.frame.size.width - width*3)/4.0;
//    ySpacing = self.frame.size.height*0.06;
//    for (int i = 0; i < 6; i++) {
//        UIButton *btn = [_arrayBtn objectAtIndex:i];
//        float x = xSpacing * (i % 3 + 1) + width * (i % 3);
//        float y = ySpacing  + self.frame.size.height/2 * (i / 3);
//        [btn setFrame:CGRectMake(x, y, width, height)];
//
//
//        float xLB = xSpacing * (i % 3 + 1) + width * (i % 3);
//        float yLB = y+height+5;
//        UILabel *title = [_arrayLB objectAtIndex:i];
//        [title setFrame:CGRectMake(xLB, yLB, width, self.frame.size.height*0.1)];
//        [title setCenter:CGPointMake(btn.center.x, title.center.y)];
//    }
    float Vwidth = 0;
    float Vheight = 0;
    float xSpacing = 0;
    float ySpacing = 0;
    float xMargin = 0;
    float yMargin = 0;
    
    Vwidth = self.frame.size.width;
    Vheight = self.frame.size.height;
    if (Vheight>self.frame.size.width*0.46) {
        Vheight = self.frame.size.width*0.46;
    }
    
    xSpacing = 5;//间距
    ySpacing = 5;//间距
    xMargin = 20;//距离父视图间距
    yMargin = 20;//距离父视图间距
    
    float width = (Vwidth-xMargin*2-xSpacing)/2;
    float height = (Vheight-yMargin*2-ySpacing*2)/3;
    float widthLast1 = (Vwidth-xMargin*2-xSpacing*2)/2;
    float widthLast2 = (Vwidth-widthLast1-xMargin*2-xSpacing*2)/2;
    [_btnDH setFrame:CGRectMake(xMargin, yMargin, width, height)];
    [_btnXH setFrame:CGRectMake(width+xSpacing+xMargin, yMargin, width, height)];
    [_btnKS setFrame:CGRectMake(xMargin, yMargin+ySpacing+height, width, height)];
    [_btnSM setFrame:CGRectMake(width+xSpacing+xMargin, yMargin+ySpacing+height, width, height)];
    [_btnMD setFrame:CGRectMake(xMargin, yMargin+2*ySpacing+2*height, widthLast2, height)];
    [_btnHC setFrame:CGRectMake(widthLast2+xSpacing+xMargin, yMargin+2*ySpacing+2*height, widthLast1, height)];
    [_btnSD setFrame:CGRectMake(widthLast2+xSpacing*2+xMargin+widthLast1, yMargin+2*ySpacing+2*height, widthLast2, height)];
    
    [_btnLY setFrame:CGRectMake(self.frame.size.width/2-20, yMargin+height/2, 40, 40)];
    [_labLY setFrame:CGRectMake(self.frame.size.width/2-25, yMargin+ySpacing+height, 50, 20)];
}
-(void)layoutSubviews{
    [self changeFrame];
    
}
#pragma mark - 判断距离是否在50米以内
-(void)getDistanceBlock:(void(^)(BOOL limit50))block{
    if (!self.vin||[@"" isEqualToString:self.vin]||
        !self.orderNumber||[@"" isEqualToString:self.orderNumber]||
        !self.userid||[@""isEqualToString:self.userid]) {
        RLLog(@"没有vin,和orderNumber,userid,请调用这个方法-(void)setOrderNumber:(NSString *)orderNumber vin:(NSString *)vin userid:(NSString *)userid");
        return;
    }
    
    
    NSString *path = [[NSBundle RLResourceBundle] pathForResource:@"RL_ControlCarPopupView_loading" ofType:@"gif"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    UIImage *hubImage = [UIImage sd_animatedGIFWithData:data];
    [SVProgressHUD setInfoImage:hubImage];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    SVProgressHUD.backgroundColor = [UIColor whiteColor];
    [SVProgressHUD showInfoWithStatus:@"获取位置信息..."];
    [SVProgressHUD setImageViewSize:CGSizeMake(80, 53)];
    
    NSMutableDictionary *returnCarparam = [[NSMutableDictionary alloc]init];
    [returnCarparam setValue:self.vin?:@"" forKey:@"vin"];
    [returnCarparam setValue:self.userid?:@"" forKey:@"aid"];
    [returnCarparam setValue:@"runlin" forKey:@"datafrom"];
    __block double lat1;
    __block double lng1;
    
    [LogWriter writeLog:@"实时行车数据"
                 detail:nil
               inParams:returnCarparam outParams:nil];
    [ReturnCarModel drivingData:returnCarparam success:^(NSArray *result, NSDictionary *location, NSString *message) {
        if (location) {
            [LogWriter writeLog:@"实时行车数据"
                         detail:@"成功"
                       inParams:nil outParams:location];
            
            lat1 = [[location jk_stringForKey:@"latitude"] doubleValue];
            lng1 = [[location jk_stringForKey:@"longitude"] doubleValue];
            RLLog(@"车辆位置 (%f, %f)", lat1, lng1);
            //只获取一次
            __block  BOOL isOnece = YES;
            [RLLocationManager getMoLocationWithSuccess:^(double lat, double lng){
                isOnece = NO;
                [SVProgressHUD dismiss];
                RLLog(@"手机位置 (%f, %f)", lat, lng);
                CLLocation *orig=[[CLLocation alloc] initWithLatitude:lat1  longitude:lng1];
                CLLocation* dist=[[CLLocation alloc] initWithLatitude:lat longitude:lng];
                NSString *str= [NSString stringWithFormat:@"手机位置 (%f, %f)",lat, lng];
                
                [LogWriter writeLog:@"RLLocationManager"
                             detail:str
                           inParams:nil outParams:location];
                
                CLLocationDistance kilometers=[orig distanceFromLocation:dist];
                if (kilometers<=50) {
                    block(YES);
                }else{
                    block(NO);
                    [JKAlert showMessage:@"距离过远，请离近再试"];
                }
                RLLog(@"距离:%f",kilometers);
                if (!isOnece) {
                    [RLLocationManager stop];
                }
            } Failure:^(NSError *error){
                isOnece = NO;
                RLLog(@"error = %@", error);
                if (!isOnece) {
                    [RLLocationManager stop];
                }
                block(NO);
              
               
                [LogWriter writeLog:@"RLLocationManager"
                             detail:@"手机位置请求失败"
                           inParams:nil outParams:nil];
                
                [JKAlert showMessage:@"位置请求失败!"];
                [SVProgressHUD dismiss];
            }];
        }else{
            
            [LogWriter writeLog:@"实时行车数据"
                         detail:@"location nil"
                       inParams:nil outParams:nil];
            [SVProgressHUD dismiss];
            block(NO);
        }
    } falure:^(NSError *error) {
        [LogWriter writeLog:@"实时行车数据"
                     detail:@"网络请求失败"
                   inParams:nil outParams:@{@"error":error.debugDescription?:@""}];
        
        [JKAlert showMessage:@"网络连接失败,请重试!"];
        block(NO);
        [SVProgressHUD dismiss];
    }];
    
}
#pragma mark - 蓝牙连接状态
//蓝牙
- (CBCentralManager *)centralManager
{
    if (!_centralManager)
    {
//        _centralManager = [[CBCentralManager alloc]initWithDelegate:self queue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) options:nil];
        _centralManager = _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return _centralManager;
}

// 当状态更新时调用(如果不实现会崩溃)
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
            //        case CBManagerStateUnknown:{
            //            RLLog(@"未知状态");
            //        }
            //            break;
            //        case CBManagerStateResetting:
            //        {
            //            RLLog(@"重置状态");
            //        }
            //            break;
            //        case CBManagerStateUnsupported:
            //        {
            //            RLLog(@"不支持的状态");
            //        }
            //            break;
            //        case CBManagerStateUnauthorized:
            //        {
            //            RLLog(@"未授权的状态");
            //        }
            //            break;
        case CBManagerStatePoweredOff:
        {
            RLLog(@"关闭状态");
            _bluetoothSuccess = NO;
            [LogWriter writeLog:@"蓝牙状态更新"
                         detail:@"关闭"
                       inParams:nil outParams:nil];
//            [JKAlert showMessage:@"蓝牙是关闭状态,请打开蓝牙,再进行连接"];
            [RDToast showWithText:@"蓝牙是关闭状态,请打开蓝牙,再进行连接" bottomOffset:80];
            _labLY.text=@"未开启";
             [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
            [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wkq.png"] forState:UIControlStateNormal];
        }
            break;
        case CBManagerStatePoweredOn:
        {
            RLLog(@"开启状态－可用状态");
            _bluetoothSuccess = YES;
           
            [_BluetoothCountDownTimer invalidate];
            [LogWriter writeLog:@"蓝牙状态更新"
                         detail:@"开启可用"
                       inParams:nil outParams:nil];
            if ([[RGBleController shareController]connectingStatus] == RGBleStatusDisConnected) {//判断蓝牙连接状态是未连接
                if (![RLOperationManager sharedManager].authKey) {
                    [LogWriter writeLog:@"蓝牙状态更新"
                                 detail:@"authKey为空获取authKey"
                               inParams:nil outParams:nil];
                    
                    if([[RGBleController shareController]connectingStatus] ==RGBleStatusDisConnected){
                        [_countDownTimer invalidate];
                        __weak typeof(self) weakSelf = self;
                        _countDownTimer = [NSTimer  ub_scheduledTimerWithTimeInterval:5.0 block:^{
                            [weakSelf getAuthKeyAndBluetoothLink];
                            
                        } repeats:YES];
                        
                        [[NSRunLoop currentRunLoop]addTimer:_countDownTimer forMode:NSRunLoopCommonModes];
                    }
                    
                }else{
                    [LogWriter writeLog:@"蓝牙状态更新"
                                 detail:@"轮询控车连接"
                               inParams:nil outParams:nil];
                    
                    
                    [_BluetoothCountDownTimer invalidate];
                    __weak typeof(self) weakSelf = self;
                    _BluetoothCountDownTimer = [NSTimer  ub_scheduledTimerWithTimeInterval:5.0 block:^{
                        [weakSelf bluetoothLink];
                        
                    } repeats:YES];
                    
                    [[NSRunLoop currentRunLoop]addTimer:_BluetoothCountDownTimer forMode:NSRunLoopCommonModes];
                }
                _labLY.text=@"未连接";
                 [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
                [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
            }
        }
            break;
        default:{
            [LogWriter writeLog:@"蓝牙状态更新"
                         detail:@"未开启"
                       inParams:nil outParams:nil];
            _bluetoothSuccess = NO;
            _labLY.text=@"未开启";
             [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
            [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wkq.png"] forState:UIControlStateNormal];
        }
            break;
    }
}
-(void)getAuthKeyAndBluetoothLink{
    _labLY.text = @"连接中";
      [_labLY setTextColor:[UIColor colorWithRed:0/255.0 green:83/255.0 blue:153/255.0 alpha:1]];
     [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_ljz.png"] forState:UIControlStateNormal];
    [_labLY setTextAlignment:NSTextAlignmentCenter];
    if (![RLOperationManager sharedManager].authKey) {
        if (!self.vin||[@"" isEqualToString:self.vin]||
            !self.userid||[@""isEqualToString:self.userid]) {
            [_countDownTimer invalidate];
            _labLY.text = @"未连接";
             [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
            [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
            return;
        }
        __weak typeof(self) weakSelf = self;
        NSMutableDictionary *returnCarparam = [[NSMutableDictionary alloc]init];
        [returnCarparam setValue:self.vin?:@"" forKey:@"vin"];
        [returnCarparam setValue:self.userid?:@"" forKey:@"aid"];
        
        [LogWriter writeLog:@"getAuthKey"
                     detail:@""
                   inParams:returnCarparam outParams:nil];
        
        [RLChangeOrderStatusModel getAuthKey:returnCarparam success:^(NSString *authKey, NSString *message) {
            if (authKey) {
                [[RLOperationManager sharedManager] setAuthKey: [NSString stringWithFormat:@"%@",authKey]];
                [[RLOperationManager sharedManager] setVin:self.vin?:@""];
                [[RLOperationManager sharedManager] setUserid:self.userid?:@""];
                
                RLLog(@"authKey获取成功:%@",[RLOperationManager sharedManager].authKey);
           
                [LogWriter writeLog:@"getAuthKey"
                             detail:@"网络请求成功"
                           inParams:nil outParams:@{@"authKey":authKey?:@"",@"connectingStatus":@([[RGBleController shareController]connectingStatus])}];
                
                [_countDownTimer invalidate];
                if (_bluetoothSuccess == YES&&[[RGBleController shareController]connectingStatus] == RGBleStatusDisConnected) {
                   
                    [LogWriter writeLog:@"getAuthKey"
                                 detail:@"蓝牙未连接,轮训连接蓝牙"
                               inParams:nil outParams:nil];
                    
                    [_BluetoothCountDownTimer invalidate];
                    _BluetoothCountDownTimer = [NSTimer  ub_scheduledTimerWithTimeInterval:5.0 block:^{
                        [weakSelf bluetoothLink];
                        
                    } repeats:YES];
                    
                    [[NSRunLoop currentRunLoop]addTimer:_BluetoothCountDownTimer forMode:NSRunLoopCommonModes];
                    
                    //                    _BluetoothCountDownTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(bluetoothLink) userInfo:nil repeats:YES];
                }else{
                    [self.centralManager stopScan];
                    _labLY.text = @"未连接";
                     [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
                     [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
                }
                
            }else{
                RLLog(@"%@",message);
                //                no auth(订单停止的时候)的时候停止轮询
                if ([message isEqualToString:@"no auth"]) {
                    [LogWriter writeLog:@"getAuthKey"
                                 detail:@"no auth"
                               inParams:nil outParams:nil];
                     
                  
                    [_countDownTimer invalidate];
                }
                _labLY.text = @"未连接";
                 [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
                [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
            }
            
        } falure:^(NSError *error) {
            [LogWriter writeLog:@"getAuthKey"
                         detail:@"网络请求失败"
                       inParams:nil outParams:@{@"error":error.debugDescription?:@""}];

            
            RLLog(@"%@",error);
            _labLY.text = @"未连接";
             [_labLY setTextColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
            [_btnLY setImage:[UIImage RLImageNamed:@"RLOperation_bluetooth_wlj.png"] forState:UIControlStateNormal];
        }];
    }
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    timeIntervalSinceDate
    
}
@end
