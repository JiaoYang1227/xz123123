//
//  RLOperationManager.h
//  RLLibrary
//
//  Created by sun on 2019/3/29.
//  Copyright © 2019 sun. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RLOperationManager : NSObject
+(RLOperationManager *)sharedManager;
@property(nonatomic,strong)NSString *vin;
@property(nonatomic,strong)NSString *userid;
@property(nonatomic,strong)NSString *authKey;
@property(nonatomic,assign)BOOL background;
+(void)destroyInstance;
@end

