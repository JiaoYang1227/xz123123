//
//  RLOperationManager.m
//  RLLibrary
//
//  Created by sun on 2019/3/29.
//  Copyright © 2019 sun. All rights reserved.
//

#import "RLOperationManager.h"

@implementation RLOperationManager
static RLOperationManager *_manager = nil;
+(RLOperationManager *)sharedManager{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [[RLOperationManager alloc] init];
        _manager.background = NO;
    });
    return _manager;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appWillEnterBackgroundNotification) name:@"UIApplicationDidEnterBackgroundNotification" object:nil];//进入后台
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidBecomeActiveNotification) name:@"UIApplicationDidBecomeActiveNotification" object:nil];
    }
    return self;
}
-(void)appWillEnterBackgroundNotification{
    _manager.background = YES;
}
-(void)appDidBecomeActiveNotification{
//    _manager.willActive = NO;
}
+(void)destroyInstance{
    _manager.authKey = nil;
    _manager.userid = nil;
    _manager.vin = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
