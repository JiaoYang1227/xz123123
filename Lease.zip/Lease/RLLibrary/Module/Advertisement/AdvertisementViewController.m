//
//  AdvertisementViewController.m
//  RLLibrary
//
//  Created by Cluy on 2018/5/23.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "AdvertisementViewController.h"
#import "UIViewController+JKPopup.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "AdvertisementModel.h"
#import "RLMicro.h"
@interface AdvertisementViewController ()
@property (weak, nonatomic) IBOutlet UIPageControl *scrolllerFocusPageControl;
@end

@implementation AdvertisementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self buildFocusView];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)buildFocusView{
//    self.scrollFocus.autoSwitch = YES;
    self.scrollFocus.backgroundColor = [UIColor whiteColor];

    self.scrollFocus.autoSwitch = YES;
    [self.scrollFocus didChangeJKScrollFocusItem:^(id item,NSInteger index) {
        self.scrolllerFocusPageControl.currentPage = index;
    }];
    
    [self.scrollFocus didSelectJKScrollFocusItem:^(id item, NSInteger index) {
       RLLog(@"click %ld,item:%@",index,item);
        NSString *url = [item jk_stringForKey:@"url"];
        NSString *title = [item jk_stringForKey:@"title"];
        NSString *advertid = [item jk_stringForKey:@"id"];
        if (url!=nil&&([url hasPrefix:@"http"]||[url hasPrefix:@"https"])) {
            
            [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
                if (self.advertisementDone) {
                    self.advertisementDone(url,title,advertid);
                }
            }];
//            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
        }
        [AdvertisementModel addAdvertNumberId:[item jk_stringForKey:@"id"]?:@"" Success:^(BOOL result, NSString *message) {
            
        } falure:^(NSError *error) {
            
        }];
    }];

    [self.scrollFocus downloadJKScrollFocusItem:^(id item, UIImageView *currentImageView) {
        NSString *url = [[item jk_stringForKey:@"photo"] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        [currentImageView sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage
                                                                                           imageNamed:@"RLOperationView_btn_Rectangle"]];
    }];
}
-(void)loadData{
    [AdvertisementModel getAdvertlistDatasuccess:^(NSArray *result, NSString *message) {
        self.scrollFocus.items =result;
        self.scrolllerFocusPageControl.numberOfPages = result.count;

    } falure:^(NSError *error) {

    }];
//    self.scrollFocus.items = @[@"http://t2.hddhhn.com/uploads/tu/201712/9999/eb3d6d0b81.jpg",@"http://t2.hddhhn.com/uploads/tu/201712/9999/ef7494c6d9.jpg",@"http://t2.hddhhn.com/uploads/tu/20150411/hnhbhoatphg.jpg"];
}
- (IBAction)backTouched:(id)sender {
    [self dismissJKPopupViewController:^(NSInteger jk_popTag) {
    }];
}
@end
