//
//  AdvertisementViewController.h
//  RLLibrary
//
//  Created by Cluy on 2018/5/23.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JKScrollFocus.h"
typedef void(^AdvertisementDone)(NSString *url,NSString *title,NSString *advertId);

@interface AdvertisementViewController : UIViewController
@property (weak, nonatomic) IBOutlet JKScrollFocus *scrollFocus;
@property (copy,nonatomic)AdvertisementDone advertisementDone;
@end
