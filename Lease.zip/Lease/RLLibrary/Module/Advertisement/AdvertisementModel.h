//
//  AdvertisementModel.h
//  RLLibrary
//
//  Created by Cluy on 2018/5/31.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLBaseModel.h"

@interface AdvertisementModel : RLBaseModel
+ (void)getAdvertlistDatasuccess:(void(^)(NSArray *result,NSString *message))success  falure:(void(^)(NSError *error))falure;
+ (void)addAdvertNumberId:(NSString *)AdvertId Success:(void(^)(BOOL result,NSString *message))success  falure:(void(^)(NSError *error))falure;
@end
