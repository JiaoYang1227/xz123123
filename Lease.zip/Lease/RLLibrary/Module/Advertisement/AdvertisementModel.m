//
//  AdvertisementModel.m
//  RLLibrary
//
//  Created by Cluy on 2018/5/31.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "AdvertisementModel.h"

@implementation AdvertisementModel
+ (void)getAdvertlistDatasuccess:(void(^)(NSArray *result,NSString *message))success  falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_SELECTADVERT_LIST parameters:nil success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            NSArray *result = [responseObject jk_arrayForKey:@"result"];
            success(result,nil);
        }else{
            success(nil,[responseObject jk_stringForKey:@"message"]);
        }
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
+ (void)addAdvertNumberId:(NSString *)AdvertId Success:(void(^)(BOOL result,NSString *message))success  falure:(void(^)(NSError *error))falure
{
    [RLAPIManager SafeGET:URI_INTERFACES_ADDADVERTNUMBER parameters:@{@"id":AdvertId?:@""} success:^(NSURLSessionTask *operation, id responseObject) {
        if ([@"SUCCEED" isEqualToString:[responseObject jk_stringForKey:@"status"]]) {//成功
            success(YES,nil);
        }else{
            success(NO,[responseObject jk_stringForKey:@"message"]);
        }
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        falure(error);
    }];
}
@end
