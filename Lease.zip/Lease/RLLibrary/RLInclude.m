//
//  RLInclude.m
//  Lease
//
//  Created by sun on 2018/3/5.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "RLInclude.h"

#import "RLConstant.h"
#import "RLCommentsViewController.h"
#import "RLOperationView.h"
#import "RLReturnCarViewController.h"
#import "RLCouponListViewController.h"
#import "RLAvailableCouponListViewController.h"
#import "RLPeccancyInformationListViewController.h"
#import "AdvertisementViewController.h"
#import "RLShareViewController.h"
#import "RLOperationManager.h"
#import <RGBleSDK/RGBleSDK.h>
#import "DateManager.h"
#import "RLFileManager.h"
#import "LogWriter.h"
#import "RLMicro.h"
//AppID： wxebae832f932ae7e4
//AppSecret：34dfbd93a227f4f65928c5101c1bc8fb
@implementation RLInclude
+(void)load{
    RLLog(@"润霖version:%@",[RLInclude version]);
}

+(NSString*)version{
    //自动更改 不要手动更改
    return @"Version-202003061417-iOS";
}

//分享统一采用OpenShare 获取微信分享key
+(void)setWexinKey{
    [OpenShare connectWeixinWithAppId:@"wxebae832f932ae7e4" miniAppId:@""];
}

/**
 *  评论
 *  orderNumber  订单号
 *  paymentStatus    支付状态
 *  money   支付价格
 *  rentalLocation   租车地点
 *  returnCarLocation   还车地点
 */
+ (UIViewController *)getRLCommentsViewControllerWithorderNumber:(NSString *)orderNumber
                                                          userid:(NSString *)userid
                                                   paymentStatus:(NSString *)paymentStatus
                                                           money:(NSString *)money
                                                  rentalLocation:(NSString *)rentalLocation
                                              returnCarLocation :(NSString *)returnCarLocation
                                              JumpTODetailedCost:(JumpTODetailedCost)jump{
    RLCommentsViewController *order = [[RLCommentsViewController alloc] initWithNibName:@"RLCommentsViewController" bundle:[NSBundle RLResourceBundle]];
    order.orderNumber = orderNumber;
    order.userid = userid;
    order.paymentStatus = paymentStatus;
    order.money = money;
    order.rentalLocation = rentalLocation;
    order.returnCarLocation = returnCarLocation;
    order.jumpThePayment = jump;
    return order;
}
/**
 *  还车操作弹窗
 */
//+ (UIViewController *)getRLReturnCarViewControllerWithVin:(NSString *)vin
//                                                   userid:(NSString *)userid
//                                              orderNumber:(NSString *)orderNumber
//                                         isJumpThePayment:(ISJumpThePayment)isJumpThePayment{
//    RLReturnCarViewController *returnCar = [[RLReturnCarViewController alloc] initWithNibName:@"RLReturnCarViewController" bundle:[NSBundle RLResourceBundle]];
//    returnCar.vin = vin;
//    returnCar.userid = userid;
//    returnCar.orderNumber = orderNumber;
//    returnCar.jumpThePayment = ^(BOOL jump,NSDictionary *location){
//        isJumpThePayment(jump,location);
//    };
//    return returnCar;
//}
+(RLOperationView *)getRLOperationView{
    RLOperationView *view = [[RLOperationView alloc]initWithFrame:CGRectMake(0, 0, 300, 50)];
    return view;
}

/**
 查询优惠券列表
 
 @param userid 用户aid
 @return 查询优惠券列表界面
 */
+(UIViewController *)getRLCouponListViewControllerWithUserid:(NSString *)userid{
    RLCouponListViewController *couponList = [[RLCouponListViewController alloc] initWithNibName:@"RLCouponListViewController" bundle:[NSBundle RLResourceBundle]];
    couponList.aid = userid;
    return couponList;
}
/**
 查询可使用优惠券列表
 
 @param userid 用户aid
 @param endtime 订单结束时间 201911221747 格式yyyy-dd HH:mm:ss
 @param price 订单价格
 @return 查询优惠券列表界面
 */
+(UIViewController *)getRLAvailableCouponListViewControllerWithUserid:(NSString *)userid
                                                             endtime:(NSString *)endtime
                                                                price:(NSString *)price
                                                         choosedCoupon:(ChoosedCoupon)choosedCoupon{
    RLAvailableCouponListViewController *couponList = [[RLAvailableCouponListViewController alloc] initWithNibName:@"RLAvailableCouponListViewController" bundle:[NSBundle RLResourceBundle]];
    couponList.aid = userid;
    couponList.starTime = endtime;
    couponList.price = price;
    couponList.choosedCoupon = ^(BOOL ISUsed,NSDictionary *couponDic){
        choosedCoupon(ISUsed,couponDic);
    };
    return couponList;
}
/**
 获取违章查询页面
 @param userid 用户aid
 @return  获取违章查询页面
 */
+(UIViewController *)getPeccancyInformationListViewControllerWithUserid:(NSString *)userid{
    RLPeccancyInformationListViewController *controller = [[RLPeccancyInformationListViewController alloc] initWithNibName:@"RLPeccancyInformationListViewController" bundle:[NSBundle RLResourceBundle]];
    controller.aid = userid;
    return controller;
}
//广告页面
+(UIViewController *)getRLAdvertisementViewControllerWithAdvertisementDone:(AdvertisementDone)advertisementDone{
    AdvertisementViewController *controller = [[AdvertisementViewController alloc] initWithNibName:@"AdvertisementViewController" bundle:[NSBundle RLResourceBundle]];
    controller.advertisementDone = ^(NSString *url,NSString *title,NSString *advertId){
        advertisementDone(url,title,advertId);
    };
    return controller;
}
//评论分享页面
+(UIViewController *)getRLCommentShareViewControllerwithaid:(NSString *)aid orderNo:(NSString *)orderNo ShareDone:(ShareDone)shareDone{
    RLShareViewController *controller = [[RLShareViewController alloc] initWithNibName:@"RLShareViewController" bundle:[NSBundle RLResourceBundle]];
    controller.aid = aid;
    controller.orderNo = orderNo;
    controller.shareDone = ^(BOOL success) {
        shareDone(success);
    };
    return controller;
}
/**
 待支付状态调用此方法
 断开蓝牙连接,清除authKey
 */
+(void)terminationControlCar{
    [RLOperationManager destroyInstance];
    [[RGBleController shareController] disConnect];
    
    [LogWriter writeLog:@"断开蓝牙连接"
                 detail:@"清除authKey"
               inParams:@{@"connectingStatus":@([[RGBleController shareController]connectingStatus])} outParams:nil];
    
    [LogWriter uploadLog];
}
@end

@implementation NSBundle (RL)
+(NSBundle *)RLResourceBundle
{
    static dispatch_once_t onceToken;
    static NSBundle *RLLibraryResourceBundle = nil;
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"RLResources" withExtension:@"bundle"];
    //RLLog(@"load boudle%@",url);
    dispatch_once(&onceToken,^{
        RLLibraryResourceBundle = [NSBundle bundleWithURL:url];
    });
    
    return RLLibraryResourceBundle;
}

@end


@implementation UIImage (RL)

+ (UIImage*)RLImageNamed:(NSString*)imgName {
    UIImage *imageFromMainBundle = [UIImage imageNamed:imgName];
    if (imageFromMainBundle) {
        return imageFromMainBundle;
    }
    UIImage *imageFromMyLibraryBundle = [UIImage imageNamed:imgName inBundle:[NSBundle RLResourceBundle] compatibleWithTraitCollection:nil];

    return imageFromMyLibraryBundle;
}

@end
