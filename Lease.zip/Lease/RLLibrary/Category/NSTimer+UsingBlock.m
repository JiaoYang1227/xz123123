//
//  NSTimer+UsingBlock.m
//  AudiTraining
//
//  Created by runlin on 2018/9/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "NSTimer+UsingBlock.h"

@implementation NSTimer (UsingBlock)
+ (NSTimer *)ub_scheduledTimerWithTimeInterval:(NSTimeInterval)ti
                                         block:(void(^)(void))block
                                       repeats:(BOOL)repeats{
    return [self scheduledTimerWithTimeInterval:ti target:self selector:@selector(ub_blockInvoke:) userInfo:[block copy] repeats:repeats];
    
}
+ (void)ub_blockInvoke:(NSTimer *)timer{
    void(^block)(void) = timer.userInfo;
    if (block)
    {
        block();
    }
}


@end
