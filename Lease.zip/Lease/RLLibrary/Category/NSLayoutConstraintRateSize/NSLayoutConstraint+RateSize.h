//
//  NSLayoutConstraint+RateSize.h
//  LayoutConstraintDemo
//
//  Created by runlin on 2018/2/24.
//  Copyright © 2018年 runlin. All rights reserved.
//

#import <UIKit/UIKit.h>
IB_DESIGNABLE
@interface NSLayoutConstraint (RateSize)

@property (nonatomic, assign) IBInspectable BOOL adaptive;

@end
