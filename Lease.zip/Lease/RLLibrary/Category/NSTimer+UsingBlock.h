//
//  NSTimer+UsingBlock.h
//  AudiTraining
//
//  Created by runlin on 2018/9/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSTimer (UsingBlock)
+ (NSTimer *)ub_scheduledTimerWithTimeInterval:(NSTimeInterval)ti
                                         block:(void(^)(void))block
                                       repeats:(BOOL)repeats;
@end
