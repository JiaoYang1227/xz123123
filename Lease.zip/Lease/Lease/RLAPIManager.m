//
//  APIManager.m
//  AudiTraining
//
//  Created by Jakey on 16/4/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "RLAPIManager.h"
#import "AFSecurityPolicy.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "RLConstants.h"
#import "NSDictionary+JSONString.h"
#import "NSString+Hash.h"
static dispatch_once_t onceToken;
static RLAPIManager *_sharedManager = nil;

@implementation RLAPIManager
+ (instancetype)sharedManager {
    
    dispatch_once(&onceToken, ^{
        //设置服务器根地址
        _sharedManager = [[RLAPIManager alloc] initWithBaseURL:[NSURL URLWithString:[URI_SERVER_ADDRESS stringByAppendingString:URI_INTERFACE_ROOT]]];
        [_sharedManager setSecurityPolicy:[AFSecurityPolicy policyWithPinningMode:AFSSLPinningModePublicKey]];
        //发送json数据
        _sharedManager.requestSerializer = [AFHTTPRequestSerializer serializer];
        //响应json数据
        _sharedManager.responseSerializer  = [AFJSONResponseSerializer serializer];
        [[AFNetworkActivityIndicatorManager sharedManager] setEnabled:YES];

//        //设置头
//        NSString *key = [[NSString stringWithFormat:@"%@%@",KEY_API_HEAD_IP,KEY_API_HEAD_KEY] md5String];
//        [_sharedManager.requestSerializer setValue:key forHTTPHeaderField:@"secretkey"];
//        [_sharedManager.requestSerializer setValue:KEY_API_HEAD_IP forHTTPHeaderField:@"ip"];
//        [_sharedManager.requestSerializer setValue:KEY_API_HEAD_NAME forHTTPHeaderField:@"name"];
        
        _sharedManager.responseSerializer.acceptableContentTypes =  [_sharedManager.responseSerializer.acceptableContentTypes setByAddingObjectsFromSet:[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", @"text/plain",@"application/atom+xml",@"application/xml",@"text/xml",nil]];
        
    });
    
    return _sharedManager;
}


+ (NSURLSessionDataTask *)SafePOST:(NSString *)URLString
                        parameters:(id)parameters
                           success:(void (^)(NSURLSessionDataTask * task, id responseObject))success
                           failure:(void (^)(NSURLSessionDataTask * task, NSError *error))failure{
    RLAPIManager *manager = [RLAPIManager sharedManager];
    //todo 统一封装请求参数
    NSLog(@"client request POST interface:%@",URLString);
    NSLog(@"client request POST JSON:\n%@",[parameters?:@{} JSONStringValue]);
    
    return [manager POST:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        NSLog(@"server respone  JSON:\n%@",[responseObject JSONStringValue]);

        //todo 统一处理响应数据
        success(task,responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error respone :\n%@",[error debugDescription]);
         if(error.code == NSURLErrorCancelled)
        {
            NSLog(@"请求被取消");
        }
        //todo 统一处理错误
        failure(task,error);
    }];
}
+ (NSURLSessionDataTask *)SafeGET:(NSString *)URLString
                       parameters:(id)parameters
                          success:(void (^)(NSURLSessionDataTask * task, id responseObject))success
                          failure:(void (^)(NSURLSessionDataTask * task, NSError *error))failure{
    RLAPIManager *manager = [RLAPIManager sharedManager];
    NSLog(@"client request POST interface:%@",URLString);
    NSLog(@"client request POST JSON:\n%@",[parameters?:@{} JSONStringValue]);
    
    return [manager GET:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        NSLog(@"server respone  JSON:\n%@",[responseObject JSONStringValue]);
        //todo
        success(task,responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //todo
        if(error.code == NSURLErrorCancelled)
        {
            NSLog(@"请求被取消");
        }
        failure(task,error);
    }];
}

@end
