//
//  ViewController.m
//  Lease
//
//  Created by sun on 2018/3/6.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "ViewController.h"
#import "RLInclude.h"

@interface ViewController ()

@end

@implementation ViewController
//评价
- (IBAction)comment:(id)sender {
        [self presentViewController:[RLInclude getRLCommentsViewControllerWithorderNumber:@"123456"] animated:YES completion:nil];
    
}
- (IBAction)returnCar:(id)sender {
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
