//
//  FuckViewController.h
//  Lease
//
//  Created by sun on 2018/3/12.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FuckViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *orderTextField1;
@property (weak, nonatomic) IBOutlet UITextField *orderTextField2;

- (IBAction)touched:(id)sender;
@end
