//
//  FuckViewController.m
//  Lease
//
//  Created by sun on 2018/3/12.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "FuckViewController.h"
#import "RLInclude.h"
#import "RLOperationView.h"
#import "RLVehicleInformationView.h"
#import "RLChangeOrderStatusView.h"
#import "RLReturnCarView.h"
#import "UIViewController+JKPopup.h"
#import "RLAvailableCouponListViewController.h"
#import "RLConstant.h"
#import "RLShareViewController.h"
#import "TestViewController.h"
#import <RLLibrary/DateManager.h>
#import <RLLibrary/JKAlert.h>
#import <RLLibrary/RLChangeOrderStatusModel.h>

#import "ControlViewController.h"
#import "ReturnCarModel.h"
@interface FuckViewController (){
    
    __weak IBOutlet RLOperationView *_operation;
    
    __weak IBOutlet RLChangeOrderStatusView *_changeOrder;
    __weak IBOutlet RLReturnCarView *_returnCar;
    
}

@end

@implementation FuckViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self checkDot:NO];
    
    NSLog(@"网络环境%ld ip %@",[[RLNetWorkEnviromentNumber sharedManager]netWorkEnviromentNumber],URI_SERVER_ADDRESS);
//    [_vehucle setOrderNumber:@"DD2018032301285772506" vin:@"LFV2B20S1H5048419" phone:@"15040446696" userid:@"102719"];
//    [_vehucle setOrderNumber:@"DD2018032301285772506" vin:@"LFV2B20S1H5048419" phone:@"15040446696" userid:@"102719"];
//    [_vehucle setOrderNumber:@"DD2018032301285772506" vin:@"LFV2B20S1H5048419" phone:@"15040446696" userid:@"103102719026"];
//    [_vehucle setOrderNumber:@"DD2018032301285772506" vin:@"LFV2B20S1H5048419" phone:@"15040446696" userid:@"102719"];
//    [_changeOrder setOrderNumber:@"DD2018032301285772506" vin:@"LFV2B20S1H5048419" phone:@"13818183704" userid:@"102719"];
//    _changeOrder.shouldReloadParent = ^(id dataInfo,BOOL success){
//        NSLog(@"%@,%ld",dataInfo,(long)success);
//    };
////    [_returnCar setVin:@"LFV2B20S1H5048419" userid:@"102719"];
    [_operation setOrderNumber:@"011191023130300001" vin:@"LFVNB9AU9K5840072" userid:@"4613514" isJumpThePayment:^(BOOL jump, NSDictionary *location) {
        NSLog(@"%d,%@",jump,location);
    }];
//
//
//    [_vehucle setOrderNumber:@"011180703150012466" vin:@"LFV2B20S1H5048873" phone:@"18640922510" userid:@"6841"];
//    _vehucle.retentionTimeOut = ^ (id dataInfo){
//        NSLog(@"%@",dataInfo);
//    };
//    [_changeOrder setOrderNumber:@"DD2018032809333788188" vin:@"LFV2B20S1H5048419" phone:@"13818183704" userid:@"103001"];
//    _changeOrder.shouldReloadParent = ^(id dataInfo,BOOL success){
//        NSLog(@"%@,%ld",dataInfo,(long)success);
//    };
//    [_returnCar setVin:@"LFV2A23C6J3033181" userid:@"37" isJumpThePayment:^(BOOL jump,NSDictionary *location) {
//        if (jump) {
//            NSLog(@"还车支付%@",location);
//        }else{
//            NSLog(@"还车返回%@",location);
//        }
//    }];
//    [_operation setOrderNumber:@"DD2018032809333788188" vin:@"LFV2B25GXE5081791" userid:@"1625382"];
//    _vehucle.retentionTimeOut = ^ (id dataInfo){
//        NSLog(@"%@",dataInfo);
//    };
//
//    RLChangeOrderStatusView *rl = [[RLChangeOrderStatusView alloc]initWithFrame:CGRectMake(0, 0, 320, 200) orderNumber:@"" vin:@"" phone:@"" userid:@""];
//    [rl setOrderNumber:@"123456" vin:@"CCCqCCCCCCCCCCCCC" phone:@"17620131435" userid:@"8"];
//    
//    [self.view addSubview:rl];
//    
//    RLVehicleInformationView *rlv = [[RLVehicleInformationView alloc]initWithFrame:CGRectMake(0, 200, 320, 200) orderNumber:@"" vin:@"" phone:@"" userid:@""];
//    [rlv setOrderNumber:@"123456" vin:@"CCCqCCCCCCCCCCCCC" phone:@"17620131435" userid:@"8"];
//    [self.view addSubview:rlv];

     UIBarButtonItem *controlButton = [[UIBarButtonItem alloc] initWithTitle:@"纯控车" style:UIBarButtonItemStylePlain target:self action:@selector(controlTouched:)];
    
     UIBarButtonItem *countButton = [[UIBarButtonItem alloc] initWithTitle:@"15" style:UIBarButtonItemStylePlain target:self action:@selector(countTouched:)];
    self.navigationItem.rightBarButtonItems  =@[controlButton,countButton];
}
//是否在网点
-(void)checkDot:(BOOL) Bluetooth{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:@"LFV2B2A14J5530975" forKey:@"vin"];
    [dic setObject:@"network" forKey:@"type"];
    [dic setValue:@"125.2787" forKey:@"longitude"];
    [dic setValue:@"43.86889" forKey:@"latitude"];
    
    
    
    [ReturnCarModel checkDot:dic success:^(id respoe,BOOL success, double returnCost, NSString *message) {
  
        NSLog(@"checkDot");
    } falure:^(NSError *error) {
        NSLog(@"checkDot");

        
    }];
}
-(void)controlTouched:(id)button{
    ControlViewController *next = [[ControlViewController alloc] initWithNibName:@"ControlViewController" bundle:nil];
    [self.navigationController pushViewController:next animated:YES];
}
-(void)countTouched:(id)button{
    TestViewController *test = [[TestViewController alloc]init];
    [self.navigationController pushViewController:test animated:YES];
}
- (IBAction)one:(id)sender {
//    [_changeOrder setOrderNumber:[DateManager stringConvert_YMDHMS_FromDate:[NSDate date]] vin:self.orderTextField1.text?:@"" phone:@"13818183704" userid:@"1090895"];
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.orderTextField1.text?:@"" forKey:@"vin"];
    [param setValue:@"4826238" forKey:@"aid"];
    [param setValue:@"13818183704" forKey:@"phone"];
    [RLChangeOrderStatusModel auth:param success:^(BOOL success,NSString *message) {
        if (success) {
            [JKAlert showMessage:@"授权下发成功"];
            [_operation setOrderNumber:[DateManager stringConvert_YMDHMS_FromDate:[NSDate date]] vin:self.orderTextField1.text?:@"" userid:@"4826238" isJumpThePayment:^(BOOL jump, NSDictionary *location) {
                
            }];
        }else{
            [JKAlert showMessage:message];
        }
       
    } falure:^(NSError *error) {
        [JKAlert showMessage:@"网络连接失败,请重试!"];
    }];
}
- (IBAction)end1:(id)sender {
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.orderTextField1.text?:@"" forKey:@"vin"];
    [param setValue:@"4606980" forKey:@"aid"];
    [RLChangeOrderStatusModel revokeAuth:param success:^(BOOL success, NSString *message) {
        if (success) {
            [RLInclude terminationControlCar];
            [JKAlert showMessage:@"去权成功,结束订单"];
        }else{
            [JKAlert showMessage:message];
        }
    } falure:^(NSError *error) {
        
    }];
    
}
- (IBAction)two:(id)sender {
//    [_changeOrder setOrderNumber:[DateManager stringConvert_YMDHMS_FromDate:[NSDate date]] vin:self.orderTextField2.text?:@"" phone:@"13818183704" userid:@"1090895"];
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.orderTextField2.text?:@"" forKey:@"vin"];
    [param setValue:@"4606980" forKey:@"aid"];
    [param setValue:@"13818183704" forKey:@"phone"];
    [RLChangeOrderStatusModel auth:param success:^(BOOL success,NSString *message) {
        if (success) {
            [JKAlert showMessage:@"授权下发成功"];
            [_operation setOrderNumber:[DateManager stringConvert_YMDHMS_FromDate:[NSDate date]] vin:self.orderTextField2.text?:@"" userid:@"1090895" isJumpThePayment:^(BOOL jump, NSDictionary *location) {
                
            }];
        }else{
            [JKAlert showMessage:message];
        }
        
    } falure:^(NSError *error) {
        [JKAlert showMessage:@"网络连接失败,请重试!"];
    }];
}

- (IBAction)end2:(id)sender {
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:self.orderTextField2.text?:@"" forKey:@"vin"];
    [param setValue:@"4606980" forKey:@"aid"];
    [RLChangeOrderStatusModel revokeAuth:param success:^(BOOL success, NSString *message) {
        if (success) {
            [RLInclude terminationControlCar];
            [JKAlert showMessage:@"去权成功,结束订单"];
        }else{
            [JKAlert showMessage:message];
        }
    } falure:^(NSError *error) {
        
    }];
    [RLInclude terminationControlCar];
    [JKAlert showMessage:@"结束订单"];
}
- (IBAction)aaa:(id)sender {
//    [RLShareViewController shareWeixinWithUrl:@"https://www.baidu.com" title:@"摩羯出行" desc:@"123"  image:[UIImage RLImageNamed:@"RLShare_info.jpg"] shareDone:^(BOOL success) {
//
//    }];
//    [self presentJKPopupViewController:[RLInclude getRLCommentShareViewControllerwithaid:@"12121" orderNo:@"1212" ShareDone:^(BOOL success) {
//        //                [self back:nil];
//    }]];

}
//优惠券
- (IBAction)YHJTouched:(id)sender {
    [self presentViewController:[RLInclude getRLCouponListViewControllerWithUserid:@"106463"] animated:YES completion:nil];
}
- (IBAction)KSYYHJ:(id)sender {
    RLAvailableCouponListViewController *couponList =[RLInclude getRLAvailableCouponListViewControllerWithUserid:@"1886940" endtime:@"2018-06-12 13:10:50" price:@"0" choosedCoupon:^(BOOL ISUsed, NSDictionary *couponDic) {
        NSLog(@"%ld,%@",ISUsed,couponDic);
    }];

    
    [self presentViewController:couponList animated:YES completion:nil];
    
}
//评价
- (IBAction)commentTouched:(id)sender {
//    UIViewController *v1 = [[UIViewController alloc]init];
    UIViewController *v = [RLInclude getRLCommentsViewControllerWithorderNumber:@"DD2018060916224653000" userid:@"43" paymentStatus:@"已支付" money:@"200" rentalLocation:@"虹桥停车场" returnCarLocation:@"华鑫天地停车场" JumpTODetailedCost:^(UIViewController *VC) {
    }];
    [self.navigationController pushViewController:v animated:YES];
//    [self presentViewController:v animated:YES completion:nil];
}
- (IBAction)returnCarTouched:(id)sender {
//    [[UIViewController topShowViewController] presentJKPopupViewController:[RLInclude getRLReturnCarViewControllerWithVin:@"LFV2B20S1H5048419" userid:@"102719" orderNumber:@""  isJumpThePayment:^(BOOL jump,NSDictionary *location) {
//        if (jump) {
//            NSLog(@"还车支付");
//        }else{
//            NSLog(@"还车返回");
//        }
//    }]];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//违章
- (IBAction)peccancyInformation:(id)sender {
   [self presentViewController:[RLInclude getPeccancyInformationListViewControllerWithUserid:@"1046303"] animated:YES completion:nil];
}

- (IBAction)touched:(id)sender {
     NSArray *all =  [NSBundle allBundles];
    
    
    NSString *libraryPath = [[NSBundle mainBundle] pathForResource:@"RLLibrary" ofType:@"framework"];
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[libraryPath stringByAppendingString:@"info.plist"]];
    

    NSLog(@"touched");
}
@end
