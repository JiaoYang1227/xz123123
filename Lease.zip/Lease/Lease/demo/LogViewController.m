//
//  LogViewController.m
//  Lease
//
//  Created by Jakey on 2019/4/17.
//  Copyright © 2019 sun. All rights reserved.
//

#import "LogViewController.h"
#import "RDToast.h"
@interface LogViewController ()

@end

@implementation LogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"Log查看";
    self.textView.text = self.logString;
    
    UIBarButtonItem *copyButton = [[UIBarButtonItem alloc] initWithTitle:@"拷贝" style:UIBarButtonItemStylePlain target:self action:@selector(copyTouched:)];
    self.navigationItem.rightBarButtonItems  =@[copyButton];
}
-(void)copyTouched:(id)button{
    UIPasteboard * pastboard = [UIPasteboard generalPasteboard];
    pastboard.string = self.logString;
    
    [RDToast showWithText:@"已复制到剪贴板"];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
