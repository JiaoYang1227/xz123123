//
//  RDToast.h
//  RDToast
//
//  Created by Jakey on 14-10-27.
//  Copyright (c) 2014年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define RDToast_DEFAULT_DISPLAY_DURATION 3.0f
#define RDToast_Version_7 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f)
/**
 *  弱提示
 */
@interface RDToast : NSObject
///默认屏幕中间位置显示弱提示， 2.0f秒消失
+ (void)showWithText:(NSString *) text_;
///默认屏幕中间位置显示弱提示， duration_秒消失
+ (void)showWithText:(NSString *) text_
            duration:(CGFloat)duration_;
///屏幕中间位置偏移topOffset_，显示弱提示，2.0f秒消失
+ (void)showWithText:(NSString *) text_
           topOffset:(CGFloat) topOffset_;
///屏幕中间位置偏移topOffset_，显示弱提示，duration_秒消失
+ (void)showWithText:(NSString *) text_
           topOffset:(CGFloat) topOffset
            duration:(CGFloat) duration_;
///屏幕下方位置偏移bottomOffset_，显示弱提示，2.0f秒消失
+ (void)showWithText:(NSString *) text_
        bottomOffset:(CGFloat) bottomOffset_;
///屏幕下方位置偏移bottomOffset_，显示弱提示，duration_秒消失
+ (void)showWithText:(NSString *) text_
        bottomOffset:(CGFloat) bottomOffset_
            duration:(CGFloat) duration_;

@end
