//
//  ControlViewController.h
//  Lease
//
//  Created by Jakey on 2019/4/16.
//  Copyright © 2019 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

@interface ControlViewController : UIViewController<CBCentralManagerDelegate>
@property (weak, nonatomic) IBOutlet UIView *controlView;
@property (weak, nonatomic) IBOutlet UILabel *blueStateLabel;
@property (weak, nonatomic) IBOutlet UILabel *carStateLabel;
@property (weak, nonatomic) IBOutlet UILabel *controlStateLabel;




// 中心管理者(管理设备的扫描和连接)
@property (nonatomic, strong) CBCentralManager *centralManager;

//1
@property (weak, nonatomic) IBOutlet UIView *panel1;
@property (weak, nonatomic) IBOutlet UITextField *carVin1;
- (IBAction)authOrder1Touched:(id)sender;
- (IBAction)authKey1Touched:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *authKey1;
- (IBAction)connetCar1Touched:(id)sender;
- (IBAction)close1OrderTouched:(id)sender;

- (IBAction)disconnetCar1Touched:(id)sender;

//2
@property (weak, nonatomic) IBOutlet UIView *panel2;
@property (weak, nonatomic) IBOutlet UITextField *carVin2;
- (IBAction)authOrder2Touched:(id)sender;
- (IBAction)authKey2Touched:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *authKey2;
- (IBAction)connetCar2Touched:(id)sender;
- (IBAction)close2OrderTouched:(id)sender;
- (IBAction)disconnetCar2Touched:(id)sender;


@end

NS_ASSUME_NONNULL_END
