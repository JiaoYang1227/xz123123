//
//  ControlViewController.m
//  Lease
//
//  Created by Jakey on 2019/4/16.
//  Copyright © 2019 sun. All rights reserved.
//

#import "ControlViewController.h"
#import <RLLibrary/DateManager.h>
#import <RLLibrary/JKAlert.h>
#import <RLLibrary/RLChangeOrderStatusModel.h>
#import "RLInclude.h"

#import <RGBleSDK/RGBleSDK.h>

#import "RDToast.h"
#import "LogViewController.h"
#define USER_ID @"1090895"
@interface ControlViewController ()
{
    NSMutableArray *_arrayBtn;
    NSMutableArray *_arrayLB;
    NSArray *_arrayName;
    
    NSMutableString *_logString;
}
@end

@implementation ControlViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    self.title = @"纯控车测试";
    [self centralManager];
    [self buidView];
    
    [self log:@"进入页面" detail:@"初始化蓝牙扫描" ext:nil];
}
-(void)buidView{
    
    _arrayBtn = [NSMutableArray array];
    _arrayLB = [NSMutableArray array];
    [self CreateButton];
}
#pragma mark - 创建按钮
-(void)CreateButton{
    _arrayName = @[@{@"id":@"02",@"name":@"鸣笛",@"imageName":@"RLOperationView_btn_whistle"},
                   @{@"id":@"06",@"name":@"开锁",@"imageName":@"RLOperationView_btn_lock"},
                   @{@"id":@"03",@"name":@"点火",@"imageName":@"RLOperationView_btn_ignition"},
                   @{@"id":@"01",@"name":@"闪灯",@"imageName":@"RLOperationView_btn_flash light"},
                   @{@"id":@"05",@"name":@"锁门",@"imageName":@"RLOperationView_btn_unlock"},
                   @{@"id":@"04",@"name":@"熄火",@"imageName":@"RLOperationView_btn_flameout"}];
    for (int i = 0; i < 6; i++) {
        UIButton *btn= [[UIButton alloc]init];
        [btn setTag:i];
        //        [btn setTitle:[[_arrayName objectAtIndex:i] jk_stringForKey:@"name"] forState:UIControlStateNormal];
        //        [btn setBackgroundColor:[UIColor blackColor]];
        [btn setTitleColor:[UIColor colorWithRed:29.0/255.0 green:139.0/255.0 blue:241.0/255.0 alpha:1] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
        [btn setImage:[UIImage RLImageNamed:[NSString stringWithFormat:@"%@_nor",[[_arrayName objectAtIndex:i] jk_stringForKey:@"imageName"]]] forState:UIControlStateNormal];
        [btn setImage:[UIImage RLImageNamed:[NSString stringWithFormat:@"%@_pes",[[_arrayName objectAtIndex:i] jk_stringForKey:@"imageName"]]] forState:UIControlStateHighlighted];
        
        
        [btn addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
        [self.controlView addSubview:btn];
        [_arrayBtn addObject:btn];
        
        UILabel *title= [[UILabel alloc]init];
        title.text = [[_arrayName objectAtIndex:i] jk_stringForKey:@"name"];
        title.textAlignment = NSTextAlignmentCenter;
        [title setFont:[UIFont systemFontOfSize:13]];
        [self.controlView addSubview:title];
        [_arrayLB addObject:title];
    }
    [self changeFrame];
    
    UIBarButtonItem *logButton = [[UIBarButtonItem alloc] initWithTitle:@"Log查看" style:UIBarButtonItemStylePlain target:self action:@selector(logTouched:)];
    UIBarButtonItem *cleanButton = [[UIBarButtonItem alloc] initWithTitle:@"清空Log" style:UIBarButtonItemStylePlain target:self action:@selector(cleanButtonTouched:)];

    self.navigationItem.rightBarButtonItems  =@[cleanButton,logButton];

}
-(void)cleanButtonTouched:(id)button{
    _logString = nil;
    [self log:@"清空log" detail:@"" ext:nil];

}

-(void)logTouched:(id)button{
  
    LogViewController *next = [[LogViewController alloc] initWithNibName:@"LogViewController" bundle:nil];
    next.logString = _logString;
    [self.navigationController pushViewController:next animated:YES];
}
-(void)changeFrame{
    float width = 0;
    float height = 0;
    float xSpacing = 0;
    float ySpacing = 0;
    
    width = self.controlView.frame.size.width*0.21;
    height = self.controlView.frame.size.height*0.26;
    xSpacing = (self.controlView.frame.size.width - width*3)/4.0;
    ySpacing = self.controlView.frame.size.height*0.06;
    for (int i = 0; i < 6; i++) {
        UIButton *btn = [_arrayBtn objectAtIndex:i];
        float x = xSpacing * (i % 3 + 1) + width * (i % 3);
        float y = ySpacing  + self.controlView.frame.size.height/2 * (i / 3);
        [btn setFrame:CGRectMake(x, y, width, height)];
        
        
        float xLB = xSpacing * (i % 3 + 1) + width * (i % 3);
        float yLB = y+height+5;
        UILabel *title = [_arrayLB objectAtIndex:i];
        [title setFrame:CGRectMake(xLB, yLB, width, self.controlView.frame.size.height*0.1)];
        [title setCenter:CGPointMake(btn.center.x, title.center.y)];
    }
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self changeFrame];

}

#pragma mark - 蓝牙链接状态
//蓝牙
- (CBCentralManager *)centralManager
{
    if (!_centralManager)
    {
        _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return _centralManager;
}
#pragma mark - 蓝牙状态更新

// 当状态更新时调用(如果不实现会崩溃)
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    NSString *msg = @"";
    switch (central.state) {
        case CBManagerStatePoweredOff:
        {
            msg = @"关闭";
        }
            break;
        case CBManagerStatePoweredOn:{
            msg = @"打开";
        }
            break;
        case CBManagerStateUnknown:{
            msg = @"未知";
        }
            break;
        case CBManagerStateResetting:
        {
            msg = @"重置";
        }
            break;
        case CBManagerStateUnsupported:
        {
            msg = @"不支持";

        }
            break;
        case CBManagerStateUnauthorized:
        {
            msg = @"未授权";

        }
            break;
    }
    [RDToast showWithText:[NSString stringWithFormat:@"蓝牙状态:%@",msg]];
    self.blueStateLabel.text = [NSString stringWithFormat:@"蓝牙状态:%@",msg];
    
    [self log:@"蓝牙状态变更回调" detail:msg ext:nil];
}

#pragma mark - 获取authkey

-(void)getAuthKey:(UITextField*)vinTextField authKeyText:(UITextView*)authKeyTextView{
    
//        __weak typeof(self) weakSelf = self;
        NSMutableDictionary *returnCarparam = [[NSMutableDictionary alloc]init];
        [returnCarparam setValue:vinTextField.text?:@"" forKey:@"vin"];
        [returnCarparam setValue:USER_ID forKey:@"aid"];
    
        [self log:@"网络获取authkey" detail:@"getAuthKey" ext:returnCarparam];

        [RLChangeOrderStatusModel getAuthKey:returnCarparam success:^(NSString *authKey, NSString *message) {
            if (authKey) {
                [RDToast showWithText:@"获取authKey成功"];
                authKeyTextView.text = authKey;
                [self log:@"网络获取authkey" detail:@"网络返回authKey成功" ext:authKey];
            }else{
                [JKAlert showMessage:[NSString stringWithFormat:@"获取AuthKey失败:%@",message]];
                [self log:@"网络获取authkey" detail:@"网络返回成功,authKey为空" ext:nil];
            }
            
        } falure:^(NSError *error) {
            [JKAlert showMessage:@"获取AuthKey失败"];
            [self log:@"网络获取authkey请求失败" detail:error.debugDescription ext:nil];

        }];
}
-(void)authVin:(UITextField*)vinTextField
   authKeyText:(UITextView*)authKeyTextView{
    
    //    [_changeOrder setOrderNumber:[DateManager stringConvert_YMDHMS_FromDate:[NSDate date]] vin:self.orderTextField1.text?:@"" phone:@"13818183704" userid:@"1090895"];
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:vinTextField.text?:@"" forKey:@"vin"];
    [param setValue:@"1090895" forKey:@"aid"];
    [param setValue:@"13818183704" forKey:@"phone"];
    
    [self log:@"请求授权下发接口" detail:@"auth开始" ext:param];

    [RLChangeOrderStatusModel auth:param success:^(BOOL success,NSString *message) {
        if (success) {
            [self log:@"请求授权下发接口" detail:@"授权下发网络返回 success YES" ext:message];
        }else{
            [self log:@"请求授权下发接口" detail:@"授权下发网络返回 success NO" ext:message];
        }
        
    } falure:^(NSError *error) {
        [self log:@"请求授权下发接口" detail:@"网络连接失败" ext:error.debugDescription];
        [JKAlert showMessage:@"网络连接失败,请重试!"];
    }];
}
- (void)revokeAuth:(UITextField*)vinTextField
           authKeyText:(UITextView*)authKeyTextView {
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:vinTextField.text?:@"" forKey:@"vin"];
    [param setValue:@"1090895" forKey:@"aid"];
    
    [self log:@"revokeAuth网络请求" detail:vinTextField.text ext:param];

    [RLChangeOrderStatusModel revokeAuth:param success:^(BOOL success, NSString *message) {
        if (success) {
            [self log:@"revokeAuth网络请求" detail:@"success YES" ext:message];
            [RDToast showWithText:@"去权成功"];
        }else{
            [RDToast showWithText:message];
            [self log:@"revokeAuth网络请求" detail:@"success NO" ext:message];

        }
    } falure:^(NSError *error) {
        [self log:@"revokeAuth网络请求失败" detail:@"falure" ext:error.debugDescription];
    }];
    
}
#pragma mark - 蓝牙连接车辆
-(void)connectCar:(UITextView*)authKeyTextView vinTextField:(UITextField*)vinTextField{
    [self log:@"蓝牙连接车辆" detail:vinTextField.text ext:authKeyTextView.text?:@""];

    
    [[RGBleController shareController] connectWithTicket:authKeyTextView.text?:@"" result:^(BOOL isSuccess, RGBleError *error) {
        if (isSuccess) {
            [RDToast showWithText:[NSString stringWithFormat:@"蓝牙控车链接成功,VIN:%@",vinTextField.text]];
            
            [self log:@"蓝牙连接车辆" detail:@"链接回调 isSuccess YES" ext:nil];

        }else{
            [RDToast showWithText:[NSString stringWithFormat:@"蓝牙控车链接isSuccess NO,VIN:%@",vinTextField.text]];
            [self log:@"蓝牙连接车辆" detail:@"链接回调 isSuccess NO" ext:nil];

        }
        if (error) {
            NSLog(@"error --- %@", error);
            [RDToast showWithText:[NSString stringWithFormat:@"蓝牙控车链接 error:%@,VIN:%@",error,vinTextField.text]];
            [self log:@"蓝牙连接车辆" detail:@"error" ext:error.debugDescription];
        }
    }];
}



#pragma mark - 控车按钮动作
-(void)action:(UIButton *)sender{
    NSString *msg = [self getSDKBlueToothStatus];

   
    [RDToast showWithText:[NSString stringWithFormat:@"SDK蓝牙状态:%@",msg]];
    self.carStateLabel.text = [NSString stringWithFormat:@"SDK蓝牙状态:%@",msg];
    
    [self log:@"控车按钮动作" detail:@"检查SDK蓝牙状态" ext:msg];

    if([[RGBleController shareController]connectingStatus] == RGBleStatusConnected){
        [self log:@"控车按钮动作" detail:@"SDK连接成功,进行蓝牙控车" ext:@""];
        [self BluetoothControlCar:sender.tag];
    }
}

-(NSString*)getSDKBlueToothStatus{
    NSString *msg;
    switch ([[RGBleController shareController]connectingStatus]) {//判断蓝牙连接状态
        case RGBleStatusDisConnected://未连接
        {
            msg= @"未连接";
        }
            break;
        case RGBleStatusConnecting://连接中
        {
            msg= @"连接中";
        }
            break;
        case RGBleStatusConnected://已连接
        {
            msg= @"已连接";
        }
            break;
        default:
            break;
            
    }
    return msg;
}
#pragma mark - 蓝牙控车
-(void)BluetoothControlCar:(NSInteger)index{
    NSString *opration = [[_arrayName jk_dictionaryWithIndex:index] jk_stringForKey:@"name"];
    
    [RDToast showWithText:[NSString stringWithFormat:@"蓝牙:%@ 开始",opration]];
    
    [self log:@"蓝牙控车" detail:opration ext:@""];

    __weak typeof(self) weakSelf = self;
    switch (index) {
        case 0:
        {
          
            [[RGBleController shareController] searchingCarWithExeSuccess:^(id result) {
                [weakSelf ExeSuccess:result opration:opration];
            } exeFailed:^(RGBleError *bleError) {
                [weakSelf ExeFailed:bleError opration:opration];
            }];
        }
            break;
        case 1:
        {
        
            [[RGBleController shareController] unlockingWithExeSuccess:^(id result) {
                [weakSelf ExeSuccess:result opration:opration];
            } exeFailed:^(RGBleError *bleError) {
                [weakSelf ExeFailed:bleError opration:opration];
            }];
        }
            break;
        case 2:
        {
            
            [[RGBleController shareController] ignitionWithExeSuccess:^(id result) {
                [weakSelf ExeSuccess:result opration:opration];
            } exeFailed:^(RGBleError *bleError) {
                [weakSelf ExeFailed:bleError opration:opration];
            }];
            
        }
            break;
        case 3:
        {
           
            [[RGBleController shareController] lightFlickerWithExeSuccess:^(id result) {
                [weakSelf ExeSuccess:result opration:opration];
            } exeFailed:^(RGBleError *bleError) {
                [weakSelf ExeFailed:bleError opration:opration];
            }];
            
        }
            break;
        case 4:
        {
            
            [[RGBleController shareController] onlockingWithExeSuccess:^(id result) {
                [weakSelf ExeSuccess:result opration:opration];
            } exeFailed:^(RGBleError *bleError) {
                [weakSelf ExeFailed:bleError opration:opration];
            }];
            
        }
            break;
        case 5:
        {
            
            [[RGBleController shareController] flameoutWithExeSuccess:^(id result) {
                [weakSelf ExeSuccess:result opration:opration];
            } exeFailed:^(RGBleError *bleError) {
                [weakSelf ExeFailed:bleError opration:opration];
            }];
            
        }
            break;
        default:
            break;
    }
    [self log:[NSString stringWithFormat:@"蓝牙控车结束"] detail:opration ext:nil];
    
}
-(void)ExeSuccess:(id)result opration:(NSString*)opration{
    NSString *msg = [NSString stringWithFormat:@"蓝牙:%@ 结束:%@",opration,result];
    
    [RDToast showWithText:msg];
    [self log:[NSString stringWithFormat:@"蓝牙:%@ 成功",opration] detail:@"searchingCarWithExeSuccess" ext:result];
    
    self.controlStateLabel.text = [NSString stringWithFormat:@"控车结果:%@ 成功",opration];
}
-(void)ExeFailed:(RGBleError *)bleError opration:(NSString*)opration{
    self.controlStateLabel.text = [NSString stringWithFormat:@"控车结果:%@ 失败",opration];
    
    [self log:[NSString stringWithFormat:@"蓝牙:%@ 失败",opration] detail:@"exeFailed" ext:bleError.debugDescription];
    
    [RDToast showWithText:[NSString stringWithFormat:@"蓝牙:%@ 失败:%@",opration,bleError]];
}
#pragma mark -- 车辆1

//che1
- (IBAction)authOrder1Touched:(id)sender {
    [self log:@"点击VIN 1授权" detail:self.carVin1.text ext:nil];

    [self authVin:self.carVin1 authKeyText:self.authKey1];
}

- (IBAction)authKey1Touched:(id)sender {
    [self log:@"获取auth key 1" detail:self.carVin1.text ext:nil];

    [self getAuthKey:self.carVin1 authKeyText:self.authKey1];
}
- (IBAction)connetCar1Touched:(id)sender {
    [self log:@"点击蓝牙连接车辆1" detail:self.carVin1.text ext:nil];
    [self connectCar:self.authKey1 vinTextField:self.carVin1];
}

- (IBAction)close1OrderTouched:(id)sender {
    [self log:@"点击VIN 去权1" detail:self.carVin1.text ext:nil];
    [self revokeAuth:self.carVin1 authKeyText:self.authKey1];
}
- (IBAction)disconnetCar1Touched:(id)sender{
    [self log:@"点击蓝牙控车断开1" detail:self.carVin1.text ext:nil];

    [[RGBleController shareController] disConnect];
    [self log:@"蓝牙控车断开1 后SDK蓝牙状态" detail:[NSString stringWithFormat:@"%ld",(long)[RGBleController shareController].connectingStatus] ext:nil];
}

#pragma mark -- 车辆2
//che2
- (IBAction)authOrder2Touched:(id)sender {
    [self log:@"点击VIN 2授权" detail:self.carVin2.text ext:nil];
    [self authVin:self.carVin2 authKeyText:self.authKey2];
}

- (IBAction)authKey2Touched:(id)sender {
    [self log:@"获取auth key 2" detail:self.carVin2.text ext:nil];
    
    [self getAuthKey:self.carVin2 authKeyText:self.authKey2];
}
- (IBAction)connetCar2Touched:(id)sender {
    [self log:@"点击蓝牙连接车辆2" detail:self.carVin2.text ext:nil];
    [self connectCar:self.authKey2 vinTextField:self.carVin2];
}

- (IBAction)close2OrderTouched:(id)sender {
    [self log:@"点击VIN 去权2" detail:self.carVin2.text ext:nil];
    [self revokeAuth:self.carVin2 authKeyText:self.authKey2];
}
- (IBAction)disconnetCar2Touched:(id)sender{
    [self log:@"点击蓝牙控车断开2" detail:self.carVin2.text ext:nil];

    [[RGBleController shareController] disConnect];
    [self log:@"蓝牙控车断开2 后SDK蓝牙状态" detail:[NSString stringWithFormat:@"%ld",[RGBleController shareController].connectingStatus] ext:nil];

}

- (void)log:(NSString*)opration
          detail:(NSString*)detail
       ext:(id)ext{
    if(!_logString){
        _logString = [NSMutableString string];
    }
     NSString *log = [NSString stringWithFormat:@"LogDate:%@\r\nOpration:%@\r\nDetail:%@\r\nExt:%@\r\n\n",[DateManager date_YMDHMS_WithTimeIntervalSince1970:[[DateManager nowTimeStampString] longLongValue]],opration?:@"",detail?:@"",ext?:@""];
    [_logString appendString:log];
    
}
@end
