//
//  TestViewController.m
//  Lease
//
//  Created by sun on 2018/6/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "TestViewController.h"
#import "RLOperationView.h"
#import "RLVehicleInformationView.h"
@interface TestViewController (){
    __weak IBOutlet RLOperationView *_operation;
}

@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    RLVehicleInformationView *rlv = [[RLVehicleInformationView alloc]initWithFrame:CGRectMake(0, 200, 320, 200) orderNumber:@"" vin:@"" phone:@"" userid:@""];
    [rlv setOrderNumber:@"123456" vin:@"CCCqCCCCCCCCCCCCC" phone:@"17620131435" userid:@"8"];
    
    rlv.retentionTimeOut = ^ (id dataInfo){
        NSLog(@"%@",dataInfo);
    };
    [self.view addSubview:rlv];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
