//
//  AppDelegate.m
//  TestGui
//
//  Created by 占 on 2018/2/1.
//  Copyright © 2018年 tima. All rights reserved.
//

#import "AppDelegate.h"

//#import <TMRCSFramework/TM.h>
//#import <TMRCSFramework/TMHeader.h>

#import <AFNetworking/AFNetworking.h>

#import "FuckViewController.h"
#import "RLInclude.h"
#import "UIViewController+JKPopup.h"
#import "OpenShareHeader.h"
#import "RLNetWorkEnviromentNumber.h"
#import "CBTracking.h"
#import "ControlViewController.h"
#import <RLLibrary/LogWriter.h>
@interface AppDelegate ()


@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
//    self.window = [TMZAppDelegate shareInstance].window;
//    [TMZAppDelegate shareInstance].delegate = self;
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
     [RLInclude setWexinKey];
//   [OpenShare connectQQWithAppId:@""];
//   [OpenShare connectWeiboWithAppKey:@""];
   [[RLNetWorkEnviromentNumber sharedManager]setNetWorkEnviromentNumber:RLNetWorkEnviromentUAT];
    //   [[RLInclude alloc]init].netWorkEnviromentNumber = 1;

    [self loginSuccess];
//
//    [LogWriter writeLog:@"test1" detail:@"" inParams:nil outParams:nil];
//    [LogWriter writeLog:@"test2" detail:@"" inParams:nil outParams:nil];
//    [LogWriter writeLog:@"test3" detail:@"" inParams:nil outParams:nil];
//    [LogWriter writeLog:@"test4" detail:@"" inParams:nil outParams:nil];
//
//    [LogWriter uploadLog];
//    [LogWriter writeLog:@"test5" detail:@"" inParams:nil outParams:nil];
//    [LogWriter writeLog:@"test6" detail:@"" inParams:nil outParams:nil];
//    [LogWriter writeLog:@"test7" detail:@"" inParams:nil outParams:nil];
//    [LogWriter writeLog:@"test8" detail:@"" inParams:nil outParams:nil];

    return  YES;
//    return [[TMZAppDelegate shareInstance] application:application didFinishLaunchingWithOptions:launchOptions];
}

-(void)loginSuccess
{
    FuckViewController *root = [[FuckViewController alloc] init];
    
//    ControlViewController *root = [[ControlViewController alloc] initWithNibName:@"ControlViewController" bundle:nil];
    
//    JustATestVC *justTestVC = [[JustATestVC alloc] init];
    // 在首页弹出广告页面
    [root presentJKPopupViewController:[RLInclude getRLAdvertisementViewControllerWithAdvertisementDone:^(NSString *url,NSString *title,NSString *advertId) {
        NSLog(@"11111111:%@,%@,%@",url,title,advertId);
    }]];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:root];
//    [nav setNavigationBarHidden:YES];
    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];
    
}


- (void)applicationWillResignActive:(UIApplication *)application {
//    [[TMZAppDelegate shareInstance] applicationWillResignActive:application];
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
//    [[TMZAppDelegate shareInstance] applicationDidEnterBackground:application];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
//    [[TMZAppDelegate shareInstance] applicationWillEnterForeground:application];
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
//    [[TMZAppDelegate shareInstance] applicationDidBecomeActive:application];
}


- (void)applicationWillTerminate:(UIApplication *)application {
//    [[TMZAppDelegate shareInstance] applicationWillTerminate:application];
}
-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    //第二步：添加回调
    if ([OpenShare handleOpenURL:url]) {
        return YES;
    }
    //这里可以写上其他OpenShare不支持的客户端的回调，比如支付宝等。
    return YES;
}

@end

